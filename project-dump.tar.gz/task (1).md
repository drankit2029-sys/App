# TakeOne Studio — 52-FX Verification Status & Round 2 Follow-Up `task.md`

> **Verification Summary (Commit `d83a660`)**:
> - **Completed & Verified (`[x]`)**: 29 production processor/UI files and 6 test files updated; 25 new interaction/mode unit tests in `FxInteractionAndModeTest.java` passing across all 6 CI shards.
> - **Remaining for Round 2 (`[ ]`)**: 5 targeted follow-up items below (the 4 open items noted in `TASK_REPORT.txt` + 4 remaining `defaultRaw` / mode-bleed bugs caught during post-commit verification).

## Round 1 — Completed & Verified Items (`d83a660`)

- [x] **Phase 1 (Mode Applicability & Disabling)**:
  - `AudioProcessor.isParamApplicable(String)` added alongside `isParamApplicable(String, Map<String, Integer>)`.
  - Implemented and verified on `AudioGeneratorTool`, `TimelineUtilityProcessor`, `TruncateSilenceProcessor`, `ClassicFiltersProcessor`, `SpectralEditProcessor`, `FreeverbReverbProcessor`, `VocoderProcessor`, `AmplifyProcessor`, and `GraphicEqProcessor`.
  - `StudioFragment` dims (`alpha = 0.35f`) and disables non-applicable controls in both FX rack rendering paths.
- [x] **Phase 2 (Default-Value Gates & Silent Mode Hijacks Removed)**:
  - Fixed `SlopeFilterProcessor`, `AudioGeneratorTool`, `TimelineUtilityProcessor`, `TruncateSilenceProcessor`, `GraphicEqProcessor`, `ParametricEq6BandProcessor`, `ShelfFilterProcessor`, `SpectralEditProcessor`, `ClassicFiltersProcessor`, `FreeverbReverbProcessor`, and the 8 `0%`-primary-amount processors (`ChorusFlanger`, `Phaser`, `DistortionWaveshaper`, `MultibandCompressor`, `ProCompressor`, `ProDeEsser`, `ProTone`, `Tremolo`).
- [x] **Phase 3A (DSP-Side Coupling for Redundant Controls)**:
  - Implemented in `ChangeTempoProcessor`, `ChangeSpeedAndPitchProcessor`, `AmplifyProcessor`, and `NotchFilterProcessor`.
- [x] **Phase 4A (Core DSP, State, Look-Ahead & Compression Fixes)**:
  - Fixed `VocoderProcessor` persistent filterbank/envelope state + pure white noise carrier, `BrickwallLimiterProcessor` 3 ms look-ahead delay line, `EchoProcessor` & `MultiDelayProcessor` zero-time reflection removal, `CompressorProcessor` upward compression positive boost & noise-floor hold, and `StereoImagingProcessor` honest mono/stereo behavior.
- [x] **Phase 5A (Targeted Interaction & Mode Test Suite)**:
  - Added `FxInteractionAndModeTest.java` (25 tests) and updated legacy expectations in `DspBugFixesTest`, `FxDivergenceGuardTest`, `Stage3DeepAuditFixTest`, `Stage3PostAuditFixTest`, and `Stage7TimeToolsTest`.

## Round 2 — Remaining Open Items & Newly Caught Edge Cases (To Implement Next)

### 1. Fix the 4 Remaining `defaultRaw` / Mode-Bleed Bugs Found in Post-Verification Audit
- [x] **`FadeProcessor.java` (`fade`, lines 204–213 & 245–252) — Fade Out Turns Into Fade In When Start/End Gain Touched**:
  - **Bug**: `startGain` (`fade_start`) defaults to `0%` and `endGain` (`fade_end`) defaults to `100%`. In `Fade Out (typeIdx == 1)` and `Studio Fade Out (typeIdx == 2)`, lines 209–212 check:
    ```java
    if (!fadeIn && gStart < 0.01f && gEnd > 0.99f) {
        gStart = 1.0f;
        gEnd = 0.0f;
    }
    ```
    As soon as the user adjusts `Start Gain` from `0%` to `5%` (or `End Gain` from `100%` to `95%`), that condition becomes `false` and `Fade Out` / `Studio Fade Out` suddenly turns into a **Fade In** (`5% -> 100%` or `0% -> 95%`)! Also lines 206–208 inject a fake `gStart = 0.85f` when `gStart == 1.0f && gEnd == 1.0f`.
  - **Fix**:
    1. Implement `isParamApplicable` on `FadeProcessor` so `"fade_start"` and `"fade_end"` are only applicable in `Adjustable Fade (typeIdx == 3)` (`return (!"fade_start".equals(paramId) && !"fade_end".equals(paramId)) || typeIdx == 3;`).
    2. In `Fade In (typeIdx == 0)`, always ramp `0.0f -> 1.0f`. In `Fade Out (typeIdx == 1)` and `Studio Fade Out (typeIdx == 2)`, always ramp `1.0f -> 0.0f`. Only read `startGain` and `endGain` in `Adjustable Fade (typeIdx == 3)`, and remove the fake `g0 = 0.85f` override when `g0 == 1.0f && g1 == 1.0f`.
- [x] **`AudioGeneratorTool.java` (`generator`, line 309) — Disabled `gen_start` Bleeds Into Rhythm Track**:
  - **Bug**: `isParamApplicable(3, "gen_start")` returns `false` in `Rhythm Track (3)` mode, yet `renderRhythmChunk()` (line 309) executes:
    ```java
    double pingHz = startFreq.getCurrentRaw() != startFreq.defaultRaw ? startFreq.getCurrentRaw() : 880.0;
    ```
    If the user changes `Start Frequency` in `Tone & Chirp (0)` mode and switches to `Rhythm Track (3)`, the disabled `Start Frequency` slider still alters the rhythm click pitch!
  - **Fix**: Set `double pingHz = 880.0;` unconditionally in `renderRhythmChunk()`.
- [x] **`PlosiveBreathSuppressorProcessor.java` (`plosive`, lines 62–78) — Leftover `0%` Primary Override**:
  - **Bug**: Line 77 has `float sens = rawSens > 0 ? (rawSens / 100.0f) : (plosiveCutoff.getCurrentRaw() != plosiveCutoff.defaultRaw ? 0.35f : 0.0f);`. When `Plosive Reduction` (`plosiveSens`) is `0%`, moving `Plosive Cutoff` secretly turns on `35%` plosive suppression!
  - **Fix**: Set `float sens = rawSens / 100.0f;` and in `isAudible()` remove `|| plosiveCutoff.getCurrentRaw() != plosiveCutoff.defaultRaw`.
- [x] **`LoudnessNormalizationProcessor.java` (line 224) & `TruncateSilenceProcessor.java` (lines 168–169) — Leftover `!= defaultRaw` Tweaks**:
  - **Bug 1 (`LoudnessNormalizationProcessor.java:224`)**: `if (ceiling.getCurrentRaw() != ceiling.defaultRaw) gainDb += (ceiling.getFloat() - (-1.0)) * 0.20;` shifts program loudness even when the audio peak is far below the ceiling. Remove lines 224–228 so `gainDb` targets `target.getFloat() - (lufs + dualOffset)` cleanly and `ceiling` acts strictly as the true-peak ceiling.
  - **Bug 2 (`TruncateSilenceProcessor.java:168–169`)**: `if (rawMinMs != minDuration.defaultRaw && frames < minSilent * 2)` artificially changes `targetKeep` by `(rawMinMs - minDuration.defaultRaw) / 50`. Remove lines 168–171.

### 2. Complete `StudioFragment.java` Two-Way UI Sync for Redundant Controls (Phase 3 UI Side)
- [x] **File**: `app/src/main/java/com/takeone/studio/StudioFragment.java` (inside both `syncPrimaryLinks`/`applyExtra` around lines 4390–4708 and `ctl`/`syncSecondaryLinks` around lines 5200–5388)
  - **`CHANGE_TEMPO` (`tempo`)**:
    - Primary dial is `tempo_percent` (`slot.value`, scaled by `10`, range `-750..3000`). Secondary dials are `tempo_bpmfrom` (`30..300`) and `tempo_bpmto` (`30..300`).
    - When `slot.value` (`tempo_percent`) is scrubbed by the user: read `int from = slot.extraParams.getOrDefault("tempo_bpmfrom", 120);`, compute `int to = Math.max(30, Math.min(300, (int) Math.round(from * (1.0 + (slot.value / 10.0) / 100.0))));`, and store `slot.extraParams.put("tempo_bpmto", to);`.
    - When `tempo_bpmfrom` or `tempo_bpmto` is scrubbed by the user: read `from` and `to`, compute `int pctRaw = Math.max(-750, Math.min(3000, (int) Math.round(((to - from) * 1000.0) / Math.max(1, from))));`, and set `slot.value = pctRaw;`.
  - **`CHANGE_SPEED_PITCH` (`speedpitch`)**:
    - Primary dial is `speed_mult` (`slot.value`, scaled by `100`, range `25..400`, default `100` = `1.00x`). Secondary dial is `speed_percent` (scaled by `10`, range `-750..3000`, default `0` = `0.0%`).
    - When `slot.value` (`speed_mult`) is scrubbed: set `slot.extraParams.put("speed_percent", (slot.value - 100) * 10);`.
    - When `speed_percent` is scrubbed: set `slot.value = Math.max(25, Math.min(400, 100 + Math.round(value / 10.0f)));`.

### 3. Add Streaming Overlap-Add State to `StftProcessor.java` (Phase 4.2)
  - **Status:** Addressed for offline renders via `requiresFullBuffer` + a single full-selection STFT pass (no chunk boundaries), with a 40,000-frame file-path equivalence test. True streaming overlap-add for realtime preview remains open; spectral effects are now offline-only.
- [ ] **File**: `app/src/main/java/com/takeone/studio/StftProcessor.java`, `SpectralEditProcessor.java`, `SpectralNoiseReductionProcessor.java`
  - **Root Cause**: `StftProcessor.processSingleBlock()` pads each chunk with `pad = fftSize` zeros at the start and end of every `4096`-frame block. When `EditEngine` or `LivePreviewDsp` calls `processInPlace()` on consecutive `4096`-frame chunks, each chunk boundary gets zero-padded in isolation instead of overlapping with the neighboring chunk's samples.
  - **Fix**:
    1. Hold a single `StftProcessor` instance as a field on `SpectralEditProcessor` and `SpectralNoiseReductionProcessor` (reset in `reset()`).
    2. In `StftProcessor`, keep a per-channel tail buffer of the last `fftSize` input frames (`prevIn[ch][fftSize]`) and overlap-add tail (`overlapTail[ch][fftSize]`) across consecutive `process()` calls (or only use `processSingleBlock` with zero-padding when `reset()` was just called for a standalone buffer), so chunked streaming produces seamless overlap-add across chunk boundaries.

### 4. Expand `FxInteractionAndModeTest.java` to Loop Over All 52 Effects Automatically
- [x] **File**: `app/src/test/java/com/takeone/studio/FxInteractionAndModeTest.java`
  - Add a parameterized or loop-based test `all52EffectsDisabledParamsAreCompletelyInert()` that iterates over every `DspChain.EffectType` (`52` effects), checks every `ENUM` and `BOOLEAN` parameter state, and verifies for every parameter `p` where `!proc.isParamApplicable(p.id, values)` that setting `p` to `minRaw` vs `maxRaw` yields bit-for-bit identical output (`assertArrayEquals(..., 0f)`).
  - Include tests for the 4 Round-2 fixes above (`FadeProcessor` Fade-Out start/end gain invariance, `AudioGeneratorTool` Rhythm Track `gen_start` invariance, `PlosiveBreathSuppressorProcessor` `0%` audibility, and `StudioFragment` Tempo/Speed slider sync).
