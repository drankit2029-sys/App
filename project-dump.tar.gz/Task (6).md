# AI Agent Task — Fix Studio In-Place Replace Mode & Verify Part D (`task.md`)

## Status Overview — Verification of `project.tar.gz` (Part D)
All **4 Part D fixes (`D.1` – `D.4`)** from the previous audit were verified in `project.tar.gz`:
- [x] **D.1 (`StudioFragment.java:6143–6149`)**: `commitDspFx()` now rolls back `uj.undo(raw)` alongside `waveform.discardTopUndoPeaks()` even when the first offline processor fails (`newTotal < 0`). Verified by `FxCommitAndCrossfadeTest.firstOfflineFailureWithInPlaceTailRollsBackUndoJournal()`.
- [x] **D.2 (`HardwareApiManager.java:434–443 & 574–682`)**: `readBackSsboOnGlThread()` now returns `boolean` and falls back to CPU on `mapped == null` or `glUnmapBuffer` failure, and `complexMultiplyInPlace()` keeps `n < 65536` (`FilterCurveEqProcessor`) on the CPU without stalling the real-time audio thread.
- [x] **D.3 (`WsolaTimePitchProcessor.java`, `ChangePitchProcessor.java`, `FxParamMatrixDumpTest.java`)**: Removed the `0.985f` `hqTrim` attenuation and the `0.0 st` `+1.5 dB` high-shelf hack, fixed `ChangePitchProcessor.isAudible()` at `0.0 st`, and updated `FxParamMatrixDumpTest` to test `pitch_formant` at `+4.0 st`. Verified by `changePitchAtZeroSemitonesIsBitExactBypassRegardlessOfPreserveFormants()` and `wsolaTimeStretchPreservesUnityGainWhenHqSpeechIsOff()`.
- [x] **D.4 (`TruncateSilenceProcessor.java`)**: Added raised-cosine splice crossfading (`fadeFrames <= 64`) to both `processOfflineRegion()` and `processOfflineRangeToFile()`. Verified by `truncateSilenceCrossfadesSpliceBoundaryWithoutStepDiscontinuity()`.

---

## Part E — Root Cause Analysis & Fixes for the Studio "Replace" Button

### Why Replace Mode Stopped Working (Root Cause Summary)
Two recent changes for 60 FPS VSYNC live append scrolling broke mid-take Replace mode:
1. **`RecordingEngine.liveInterpolatedFrames()` (`RecordingEngine.java:188–202`) returned `totalFrames` (`dataBytes / (ch * 4L)`) instead of `cursorFrame` whenever `cursorFrame < base`**:
   ```java
   long base = dataBytes / (Math.max(1, channels) * 4L);
   if (state != State.RECORDING || lastChunkElapsedNanos <= 0L
           || cursorFrame < base) {
       return base;
   }
   ```
   - During in-place Replace mode, `cursorFrame` is mid-take (`cursorFrame < base`, where `base` is `totalFrames` at the end of the recording).
   - Because `cursorFrame < base` was `true`, `engine.liveInterpolatedFrames()` immediately returned **`base` (`totalFrames`, the end of the recording)** on the very first VSYNC frame (`StudioFragment.waveFrameCallback`, line `244`).
   - `waveFrameCallback` passed `cur = totalFrames` into `waveform.updateLiveFromFrames(peak, cur, replaceTargetEndFrame)`.
   - Inside `WaveformView.updateLiveFromFrames()`, the Replace branch condition `if (replaceEndFrame > 0 && curFrames < replaceEndFrame && count > 0)` evaluated to **`false`** (`totalFrames < totalFrames` is false!), so it skipped the in-place Replace branch and set `playheadPos = count` — **instantly snapping the waveform playhead to the end of the recording**.
   - On every subsequent VSYNC frame while `cursorFrame < totalFrames`, `liveInterpolatedFrames()` kept returning `totalFrames`, which equaled `lastPushedCursorFrame` (`if (cur > 0 && cur != lastPushedCursorFrame)` was always `false`), so **`waveform.updateLiveFromFrames()` was never called again for the entire Replace pass** and none of the waveform bars were replaced, while `timerText` (`engine.cursorMs()`) counted up from `cursorFrame`.
   - When the user pressed Pause (`pauseTake()`), `waveform.setPlayheadFraction(target / (float) total)` moved the playhead from the end of the recording back to `cursorFrame`, revealing the un-replaced waveform bars.
2. **`WaveformView.onDraw()` (`WaveformView.java:1874–1879`) hid all bars ahead of the playhead during live Replace**:
   ```java
   if (isLive && savedReplaceTailPeaks == null) {
       kEnd = Math.min(kEnd, (long) Math.floor(headPos / bucketsPerBar));
   }
   ```
   Because `savedReplaceTailPeaks` is `null` during in-place Replace mode, setting `isLive = true` clamped `kEnd` to `headPos / bucketsPerBar`, hiding all upcoming bars of the existing recording to the right of the center playhead during Replace and making them pop back into view on Pause.
3. **Mic Warmup & Pause Seam Synchronization (`RecordingEngine.java:710, 832, 1112–1273`, `StudioFragment.java:2253–2288`)**:
   - `startCapture()` and `resumeCapture()` set `lastChunkElapsedNanos = SystemClock.elapsedRealtimeNanos()` immediately before `capLoop()` finished `micWarmupActive`, causing VSYNC interpolation to advance before the mics finished warming up.
   - In `capLoop()`, `lastChunkElapsedNanos` was updated at line `1223` *outside* `synchronized (lock)` before `cursorFrame += frames` at line `1264`, allowing a race where `liveInterpolatedFrames()` saw a reset `lastChunkElapsedNanos` with a stale `cursorFrame`.
   - In `StudioFragment.pauseTake()`, `long pausedAtFrame = engine.cursorFrames();` was read *before* `engine.pauseCapture()` joined `capThread`, so `engine.seekCursorFrame(target)` rewound `cursorFrame` behind the last chunk written by `capThread` and behind the 240-frame fade-in applied by `crossfadeOutOnPauseLocked()`.

---

### E.1. Fix `RecordingEngine.liveInterpolatedFrames()` & Mic Warmup Lockstep (`RecordingEngine.java`)
- **File**: `app/src/main/java/com/takeone/studio/RecordingEngine.java`
- **Changes**:
  1. Add a package-private field `private int punchInFadeOffset = 0;` alongside `punchInFadeBuf` (line `98`) and reset `punchInFadeOffset = 0;` wherever `punchInFadeBuf = null;` is set.
  2. Replace `liveInterpolatedFrames()` (lines `188–202`) so it interpolates from `cursorFrame` (which is the mid-take playhead during Replace and equals `totalFrames` when appending) and stays stationary (`lastChunkElapsedNanos == 0L`) while the mics are warming up:
     ```java
     public long liveInterpolatedFrames() {
         synchronized (lock) {
             long base = cursorFrame;
             if (state != State.RECORDING || lastChunkElapsedNanos <= 0L) {
                 return base;
             }
             long elapsedNs = Math.max(0L,
                     android.os.SystemClock.elapsedRealtimeNanos()
                             - lastChunkElapsedNanos);
             long extraFrames = (elapsedNs * SAMPLE_RATE) / 1_000_000_000L;
             long maxExtra = Math.max(1L, SAMPLE_RATE / 50L);
             long interp = base + Math.min(extraFrames, maxExtra);
             if (punchOutFrame > 0 && interp > punchOutFrame) {
                 interp = punchOutFrame;
             }
             return interp;
         }
     }
     ```
  3. In `startCapture()` (around line `710`) and `resumeCapture()` (around line `832`), initialize:
     ```java
     lastChunkElapsedNanos = 0L;
     lastSmoothedPeak = 0f;
     level = 0f;
     ```
     so `liveInterpolatedFrames()` waits at `cursorFrame` until `micWarmupActive` finishes in `capLoop()`.
  4. In `capLoop()` (lines `1223–1273`):
     - Blend `punchInFadeBuf` using `punchInFadeOffset` so that even if the first post-warmup read has `frames < 240`, the 240-frame punch-in crossfade completes across consecutive reads without dropping the remaining fade samples:
       ```java
       if (punchInFadeBuf != null) {
           int totalFadeFrames = punchInFadeBuf.length / outCh;
           int remFade = totalFadeFrames - punchInFadeOffset;
           int fadeN = Math.min(remFade, frames);
           if (fadeN > 0) {
               bb.position(0);
               java.nio.FloatBuffer fb = bb.asFloatBuffer();
               for (int f = 0; f < fadeN; f++) {
                   int fadeIdx = punchInFadeOffset + f;
                   float wIn = (fadeIdx + 0.5f) / totalFadeFrames;
                   float wOut = 1.0f - wIn;
                   for (int c = 0; c < outCh; c++) {
                       int bufIdx = f * outCh + c;
                       int srcIdx = fadeIdx * outCh + c;
                       fb.put(bufIdx, punchInFadeBuf[srcIdx] * wOut
                               + fb.get(bufIdx) * wIn);
                   }
               }
               punchInFadeOffset += fadeN;
           }
           if (punchInFadeOffset >= totalFadeFrames) {
               punchInFadeBuf = null;
               punchInFadeOffset = 0;
           }
       }
       ```
     - Move `lastChunkElapsedNanos = android.os.SystemClock.elapsedRealtimeNanos();` inside `synchronized (lock)` right after `cursorFrame += frames;` (lines `1260–1273`) so `(cursorFrame, lastChunkElapsedNanos)` updates atomically:
       ```java
       synchronized (lock) {
           if (raf != null && capRun) {
               try {
                   raf.write(out, 0, bytes);
                   cursorFrame += frames;
                   long endBytes = cursorFrame * outCh * 4L;
                   if (endBytes > dataBytes) dataBytes = endBytes;
                   lastChunkElapsedNanos =
                           android.os.SystemClock.elapsedRealtimeNanos();
               } catch (Exception e) {
                   break;
               }
           } else {
               break;
           }
       }
       ```

---

### E.2. Fix `WaveformView` In-Place Replace Rendering & Bucket Peak Morphing (`WaveformView.java`)
- **File**: `app/src/main/java/com/takeone/studio/WaveformView.java`
- **Changes**:
  1. Add `private boolean replacingInPlace = false;` and `private float lastMorphPeak = 0f;` next to `lastMorphIdx` (around line `97`), along with:
     ```java
     public synchronized void setReplacingInPlace(boolean replacing) {
         if (this.replacingInPlace != replacing) {
             this.replacingInPlace = replacing;
             if (!replacing) {
                 lastMorphIdx = -1;
                 lastMorphPeak = 0f;
                 morphAlpha = 0f;
             }
             postInvalidateOnAnimation();
         }
     }
     ```
  2. In `updateLiveFromFrames(float v, long curFrames, long replaceEndFrame)` (lines `1154–1201`):
     - When `replaceEndFrame > 0 && curFrames < replaceEndFrame && count > 0`:
       Set `replacingInPlace = true;`, track `lastMorphPeak` as the max peak observed within the current bucket `idx` (filling any skipped intermediate buckets if `lastMorphIdx >= 0 && idx > lastMorphIdx + 1`), and blend `history[idx]` toward `lastMorphPeak`:
       ```java
       if (replaceEndFrame > 0 && curFrames < replaceEndFrame && count > 0) {
           // In-place Replace before the original end of the take:
           replacingInPlace = true;
           float exactPos = Math.max(0f,
                   Math.min(count, (curFrames / (float) replaceEndFrame) * count));
           int idx = Math.min(count - 1, Math.max(0, (int) Math.floor(exactPos)));
           if (idx != lastMorphIdx) {
               if (lastMorphIdx >= 0 && idx > lastMorphIdx + 1) {
                   for (int skip = lastMorphIdx + 1; skip < idx && skip < count; skip++) {
                       history[skip] = clampedV;
                   }
               }
               lastMorphIdx = idx;
               lastMorphPeak = clampedV;
               morphAlpha = 0.62f;
           } else {
               if (clampedV > lastMorphPeak) {
                   lastMorphPeak = clampedV;
               }
               morphAlpha = Math.min(1.0f, morphAlpha + 0.20f);
           }
           history[idx] = history[idx] * (1.0f - morphAlpha) + lastMorphPeak * morphAlpha;
           playheadPos = exactPos;
           playheadIndex = Math.round(playheadPos);
           postInvalidateOnAnimation();
           return;
       }
       replacingInPlace = false;
       ```
  3. In `setLive(boolean live)` (line `1271`) and `clear()` (line `1326`):
     Reset `replacingInPlace = false;` and `lastMorphPeak = 0f;` when `!live` or `clear()` is called.
  4. In `onDraw(Canvas canvas)` (lines `1820–1880`):
     Read `boolean repInPlace = replacingInPlace;` inside the `synchronized (this)` block, and only clamp `kEnd` when appending (`!repInPlace && savedReplaceTailPeaks == null`):
     ```java
     if (isLive && !repInPlace && savedReplaceTailPeaks == null) {
         // Live append capture only has buckets up to the interpolated head;
         // never draw bars ahead of the centre playhead.
         kEnd = Math.min(kEnd,
                 (long) Math.floor(headPos / bucketsPerBar));
     }
     ```
     This keeps all upcoming bars of the existing recording to the right of the center playhead visible in dimmed translucent red during Replace mode while they are progressively overwritten.

---

### E.3. Fix Replace Mode Lifecycle, Button Disabling While Recording, and Seamless Post-Pause Playback (`StudioFragment.java`)
- **File**: `app/src/main/java/com/takeone/studio/StudioFragment.java`
- **Changes**:
  1. **Arm / Disarm Replace Button (`btnPreviewPlay.setOnClickListener`, lines `452–471`)**:
     - When `replaceModeArmed` is toggled ON (`true`): keep selection cleared and locked, release warm speaker, and call `engine.warmUpMic(requireContext(), preset.audioSource, engine.channels);`.
     - When `replaceModeArmed` is toggled OFF (`false`): unlock selection, warm up speaker (`RawFloatPlayer.warmUpSpeaker(engine.channels)`), keep `engine.cursorFrames()` parked at the current playhead (`userScrolledWhilePaused = engine.cursorFrames() < engine.totalFrames() - 480`), and morph the main FAB icon back to Play (`ic_play`) via `syncStudioFabIcon()` so pressing Resume immediately plays seamlessly from that point forward of the previous recording.
  2. **Start In-Place Replace (`startOrResumeCapture()`, lines `2173–2214`)**:
     - When `replaceModeArmed && curFrames < totalFrames - 480`:
       Call `waveform.setReplacingInPlace(true);` right after setting `replacePassStartFrame = curFrames;` and `replaceTargetEndFrame = totalFrames;`.
     - In the `else` branches (appending at end or fresh session):
       Call `if (waveform != null) waveform.setReplacingInPlace(false);`.
  3. **Auto-Transition From Replace to Append at End of Take (`tick`, lines `2685–2695`)**:
     - When `replaceModeArmed` reaches `replaceTargetEndFrame` (`cur >= replaceTargetEndFrame || cur >= total`):
       Also call `if (waveform != null) waveform.setReplacingInPlace(false);`.
  4. **Pause During Replace Mode (`pauseTake()`, lines `2252–2288`)**:
     - Call `engine.pauseCapture();` **before** reading `long pausedAtFrame = engine.cursorFrames();` so `pausedAtFrame` reflects the exact frame after `capThread` finishes its final chunk and after `crossfadeOutOnPauseLocked()` has faded in the surviving audio at `cursorFrame`.
     - Clear `if (waveform != null) waveform.setReplacingInPlace(false);`.
     - Set `userScrolledWhilePaused = (target < total - 480);` (instead of unconditionally `false`) so that when the user pauses mid-take and turns the `Replace` button off, the playhead and timer stay at `target` and pressing Resume plays seamlessly from `target` through the remaining previous recording.
  5. **Disable Replace Button While Recording (`paintEditorStrip()`, lines `3261–3277`)**:
     - Change `boolean tapAllowed = !proUnlocked || replaceEnabled;` to:
       ```java
       boolean tapAllowed = canEdit && (!proUnlocked || replaceEnabled);
       ```
       so pressing `Replace` is completely disabled while recording (`!canEdit`) until the user pauses.

---

## Verification Test Checklist
Add regression tests in `PunchInTest.java` and `WaveformTimelineTest.java`:
- [x] **`PunchInTest.liveInterpolatedFramesStartsAtMidTakeCursorDuringReplace`**: Attach a 48,000-frame WAV, seek to frame `12,000` (`cursorFrame < totalFrames`), set `state = State.RECORDING`, and verify that `liveInterpolatedFrames()` returns `12,000` (not `48,000` / `totalFrames`) during mic warmup (`lastChunkElapsedNanos == 0L`) and interpolates forward from `12,000` once `lastChunkElapsedNanos` is set.
- [x] **`WaveformTimelineTest.inPlaceReplaceReplacesMidTakeBarsAndKeepsFutureBarsVisible`**: Load a 100-bar waveform (`240,000` frames) with initial peak `0.5f`, seek playhead to `0.5f` (bar `50`, frame `120,000`), set `setReplacingInPlace(true)` and `setLive(true)`, feed `updateLiveFromFrames(0.9f, 120_000L + f * 800L, 240_000L)` across bars `50..59`, and verify:
  1. Playhead advances smoothly from `0.50f` to `0.60f` without ever snapping to `1.0f` (`count`).
  2. Bars `50..59` are replaced with `~0.9f` (and replacing with `0.0f` reduces them toward `0.0f`), while bars `0..49` and `60..99` remain at `0.5f`.
  3. On `setLive(false)` and `setReplacingInPlace(false)`, the playhead remains at `0.60f` and the replaced bars `50..59` retain their new values.