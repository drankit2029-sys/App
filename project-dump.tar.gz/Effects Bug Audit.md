# Deep Audit: Audio Effects, Input Parameters & Time-Value Bugs

This report documents **38 confirmed bugs** uncovered across the 42 `AudioProcessor` implementations (43 `EffectType`s), the FX rack/parameter synchronization layer (`DspChain`, `FxRackChain`), live preview (`RawFloatPlayer`, `FxPreviewPeaks`), offline range editing (`EditEngine`), and the export/save pipeline (`StudioFragment`, `ConversionJobs`).

---

## Executive Summary Matrix

| ID | Severity | Component / Effect | Affected Parameter(s) | Core Issue |
| :--- | :--- | :--- | :--- | :--- |
| **BUG-01** | **CRITICAL** | `EditEngine.flushTailIntoRange` (`reverb`, `echo`, `multidelay`, `chorus`) | Tail time (`getTailFrames()`) | `raf.readFully(Dsp.toBytes(dry, ...))` reads into a discarded temporary `byte[]`; `dry` stays `0.0f`, erasing up to **4 seconds** of unselected post-selection audio. |
| **BUG-02** | **CRITICAL** | `ConversionJobs.dispatchSave` (All 9 Stage 7 offline effects) | All parameters of `tempo`, `speedpitch`, `changepitch`, `slidestretch`, `paulstretch`, `fade`, `timeline`, `truncsil`, `generator` | Save-time FX bake only runs `EditEngine.applyDspToRange` (`processInPlace`), which skips all `isOfflineOnly()` processors. Offline/time effects are silently dropped on save if not pre-baked. |
| **BUG-03** | **CRITICAL** | `StudioFragment.runSaveDispatch` + `resetFxRackAfterApply` | Sub-selection range `[start, end)` | `resetFxRackAfterApply()` leaves `dspConfig` active; modifying a knob after a sub-range bake and saving rolls back the sub-range bake and re-bakes across the **entire file** (`0..totalFrames`). |
| **BUG-04** | **CRITICAL** | `ClickRemovalProcessor` (`declick`) | `click_width` (Max Spike Width, ms) | `halfWin` uses raw `click_width` (`1..40`) as **samples** (`0.2 ms` at 10 ms) instead of milliseconds (`maxSpike`), and when **no clicks are found** (`!any`), it applies a destructive comb filter across the entire clean buffer. |
| **BUG-05** | **CRITICAL** | `RepairProcessor` (`repair`) | `repair_len` (Repair Length, ms) | When **no dropouts exist** in a chunk (`!repairedAny`), fallback code locates the highest-frequency peak in every 4096-sample chunk and overwrites up to `50 ms` (2400 samples = **58% of clean audio**) with LPC interpolation. |
| **BUG-06** | **HIGH** | `BrickwallLimiterProcessor` (`bricklim`) | Lookahead (ms), `lim_hold` (ms), `lim_release` (ms), `lim_gain`, `lim_makeup`, `lim_ceil` | Lookahead is hardcoded to `5 ms` instead of `3 ms`; `peakRing` is written but **never read**; `lim_hold` decays instead of holding; `lim_hold` & `lim_release` inject a static volume cut (`ballisticsTrimDb`); `lim_gain` is scaled by `0.65x`; quiet signals (`-50 dBFS`) are compressed via `bufMax * 0.65f`. |
| **BUG-07** | **HIGH** | `AutoDuckProcessor` (`autoduck`) | `duck_pause` (ms), `duck_fadedown` (ms), `duck_fadeup` (ms), `duck_thresh` (dB) | `pauseHoldLimit` clamps `duck_pause` (up to `5000 ms`) to `frames / 2` (**`42.6 ms`** in 4096-frame chunks); injects fake periodic LFO pumping on continuous signals; never releases above `15%` duck depth; blends `duck_thresh` with chunk min/max. |
| **BUG-08** | **HIGH** | `TruncateSilenceProcessor` (`truncsil`) | `ts_compress` (Compress To, %), `ts_min` (ms) | In `"Compress Excess Silence"` mode, `keepFrames` multiplies `ts_compress%` by `minSilent` (`ts_min`) instead of the actual detected silence length (`spanLen`), truncating 1 s and 10 s silences to the exact same fixed length. |
| **BUG-09** | **HIGH** | `FadeProcessor` (`fade`) | `fade_type`, `fade_len` (%), `fade_start` (%), `fade_end` (%), `fade_curve` | In `Fade Out` and `Studio Fade Out`, `fade_start` and `fade_end` are inverted (`Start Gain` controls final gain; `End Gain` controls initial gain); `fade_len = 20%` default leaves 80% of selection unfaded; `closingLp` biquad clicks on activation. |
| **BUG-10** | **HIGH** | `EchoProcessor` (`echo`) & `MultiDelayProcessor` (`multidelay`) | `echo_time` (up to 5000 ms), `md_time` (up to 3000 ms), `md_echoes` (up to 30) | `EchoProcessor.getTailFrames()` is hardcoded to `2000 ms` (cutting off even the 1st echo when `echo_time > 2000 ms`); `MultiDelayProcessor.getTailFrames()` is hardcoded to `4 * delayFrames` (cutting off echoes 5..30); decreasing delay time leaves stale `delayLine.length` for wrap-around; `Reverse Bouncing Ball` uses equal spacing. |
| **BUG-11** | **HIGH** | `FreeverbReverbProcessor` (`reverb`) | `rv_predelay` (ms), `rv_size` (%) | Decreasing `rv_predelay` leaves `prePos >= preFrames` without clamping; `reset()` never resets `prePos`; comb/allpass delay lengths are unscaled from 44.1 kHz sample counts; scrubbing `rv_size` wipes comb buffers to zero. |
| **BUG-12** | **HIGH** | `VocoderProcessor` (`vocoder`) | `vc_release` (Envelope Release) | `relCoef = 1f / release.getCurrentRaw()` uses raw value (`1..120`) as **samples** (`0.02 ms..2.5 ms` @ 48 kHz) instead of milliseconds, tracking audio-rate waveform cycles instead of speech syllables. |
| **BUG-13** | **HIGH** | `ChangeTempoProcessor` (`tempo`) & `ChangeSpeedAndPitchProcessor` (`speedpitch`) | `tempo_percent`, `tempo_bpmfrom`, `tempo_bpmto`, `speed_mult`, `speed_percent` | `ChangeTempo` multiplies `tempo_percent` and `bpmFrom/bpmTo` together and clamps stretch to `[0.15, 4.0]` (breaking valid BPM ratios like `300 -> 30`); `ChangeSpeedAndPitch` has a discontinuous jump when `speed_mult` passes within `±0.02` of `1 + speed_percent/100`. |
| **BUG-14** | **HIGH** | `SlidingStretchProcessor` (`slidestretch`) & `WsolaTimePitchProcessor` (`changepitch`) | `ss_rate_start/end`, `ss_pitch_start/end`, `cp_semitones`, `cp_hq`, `cp_formant` | `SlidingStretch` splits audio into 8 un-crossfaded stair-step chunks with hardcoded `hq=false, formant=false`; `WsolaTimePitchProcessor.pitchShift` injects artificial `±5 dB` gain (`+0.25 dB/semitone`) and ignores `highQualitySpeech`. |
| **BUG-15** | **HIGH** | `RawFloatPlayer` (Live FX Preview) | Playhead time / `positionFrames()` / Pause & Seek on time-stretched audio | When previewing time-stretched effects (`outFrames != limitFrame - startFramePos`), `positionFrames()` adds stretched `head` to `startFramePos` and clamps at unstretched `limitFrame`, freezing the playhead early on slowdowns and breaking Pause/Resume position. |
| **BUG-16** | **HIGH** | `EditEngine.applyLengthChangingEffectToRange` | Selection end time (`endFrame`), chained offline effects | `saveTailFrom` snaps `endFrame` by up to `±240 frames` (`±5 ms`) while `readFloatSelection` reads exact `endFrame` (duplicating/dropping frames); `spliceTailAfterReplace` overlaps by 240 frames without subtracting `fade` from returned `newTotal`. |
| **BUG-17** | **HIGH** | `AudioGeneratorTool` (`generator`) | `gen_dur` (s), `gen_seq` (DTMF), `gen_wave` (Noise color) | Always replaces selection length with `gen_dur` (`5.0 s`) even in `Silence` mode; `renderDtmf` corrupts dialed digits via `+ slotIdx + (seqVal & 3)`; `Noise` mode displays oscillator wave names whose indices mismatch the noise colors. |
| **BUG-18** | **HIGH** | `NoiseGateExpanderProcessor` (`gateexp`) | `gate_thresh` (dB), `gate_range` (dB), `gate_ratio`, `gate_mode` | Overrides `gate_thresh` with `minSigDb + normT * (maxSigDb - minSigDb)` whenever signal stays above `thresh + 6 dB` (gating loud continuous speech!); attenuates by up to 35% of `gate_range` even when `open == true`; scales `Gate` mode depth by `gate_ratio`. |
| **BUG-19** | **HIGH** | `ProLimiterProcessor` (`limiter`) | `limiter_ceiling` (dB), `limiter_Amount` (%) | Sets `effThresh = Math.min(c, bufPeak * 0.72f)`, compressing the top 28% of every chunk by up to ~1.9 dB even on `-40 dBFS` quiet audio far below `limiter_ceiling`. |
| **BUG-20** | **HIGH** | `AmplifyProcessor` (`amplify`) | `amp_peak` (New Peak, dB), `amp_gain` (dB), `amp_clip` (Allow Clipping) | When `amp_gain == 0` and `amp_peak > peakDb` (e.g. signal at `-12 dB`, `New Peak = -3 dB`), applies `requested = ceiling` (`-3 dB` cut -> `-15 dB` peak!) instead of `ceiling - peakDb` (`+9 dB` boost); ignores `amp_clip = true` whenever `amp_peak < 0 dB`. |
| **BUG-21** | **HIGH** | `ClipFixProcessor` (`clipfix`) | `clip_thresh` (%), `clip_gain` (dB) | When chunk peak `< 0.80` (`-1.94 dBFS`), sets `refPeak = maxAbs`, spline-warping the top 5% of natural unclipped waveforms in every quiet chunk and unconditionally attenuating by `-6 dB`. |
| **BUG-22** | **HIGH** | `DspChain` + `ProToneProcessor` (Legacy Stages & Multi-Instance) | Primary `slot.value` on stacked legacy stages; `warmth` / `presence` `wetDry` | `syncLegacyFieldsFromSlots` overwrites `cfg.*Pct` with the **last** duplicate slot's value, feeding the 2nd slot's value into the 1st processor; `ProToneProcessor` scales dB gain instead of linear wet/dry blend when unsplit. |
| **BUG-23** | **MEDIUM** | `WahwahProcessor` (`wah`) | `wah_depth` (%), `wah_auto` (Auto-Wah, %), `wah_offset` (%) | `isAudible()` returns `isEnabled() && depth.getCurrentRaw() > 0`, completely bypassing the processor when `wah_depth == 0%` even if `wah_auto` (`Envelope Auto-Wah`) is `100%`! |
| **BUG-24** | **MEDIUM** | `BassAndTrebleProcessor` (`basstreble`) | `link` (Link Bass/Treble), `bass`, `treble` | Enabling `link` when both knobs are `0.0 dB` forces a hardcoded `+3.0 dB` boost on both bands, making `0.0 dB` unreachable while `link` is active. |
| **BUG-25** | **MEDIUM** | `LoudnessNormalizationProcessor` (`loudness`) | `loud_ceiling` (True-Peak Ceiling, dB) | When `appliedGainDb == 0f` (`gain == 1f`), `processInPlace` returns early at line 202 **before** running the `loud_ceiling` limiter loop (lines 206–215); soft-clip formula allows peaks up to `2 * ceilLin` (`+6 dB` over ceiling). |
| **BUG-26** | **MEDIUM** | `SpectralNoiseReductionProcessor` (`specnr`) & `SpectralEditProcessor` (`spectraledit`) | STFT block continuity, `se_mode`, `se_gain`, `se_width` | Re-instantiates `new StftProcessor` with zero-padded edges on every 1024/4096-sample `processInPlace` chunk (no cross-chunk overlap state); `Spectral Delete / Notch` weakens when `se_gain` is moved off `0 dB`; Gaussian bell hard-truncates at `[f1, f2]`. |
| **BUG-27** | **MEDIUM** | `PlosiveBreathSuppressorProcessor` (`plosive`) & `DeEsserProcessor` (`deesssplit`) | `plosive_breath` (dB), `ds_freq` (Hz), `ds_thresh` (dB) | `plosive_breath` never measures HF breath energy, scales dB by `0.45f`, and attenuates loud speech by `6.75%` of `breathDb`; `DeEsserProcessor` subtracts a 90°-phase-shifted Butterworth LP from dry input (`x - LP(x)`), creating a `+3 dB` phase peak at crossover, and lacks attack/release parameters. |
| **BUG-28** | **MEDIUM** | `ProCompressorProcessor` (`comp`) & `MultibandCompressorProcessor` (`mbcomp`) | `comp_ratio`, `comp_amount`, `mb_rms`, `mb_lowx`, `mb_highx` | `ProCompressor` scales `(ratio - 1)` by `amount%` (so `12:1` at `20%` amount is only `3.2:1`) and applies static makeup gain to initial silence; `MultibandCompressor` hardcodes `rms = false` in all 3 band detectors. |
| **BUG-29** | **MEDIUM** | `NotchFilterProcessor` (`notch`) | `preset` (Quick Pick), `freq` (Frequency, Hz) | `buildSections()` ignores `freq` whenever `preset` is `1` (`50 Hz`) or `2` (`60 Hz`) unless cleared by a Studio UI callback. |
| **BUG-30** | **LOW** | `Reverb`, `Phaser`, `Chorus`, `Vocoder` + `FxRackChain` | `rv_wet`/`rv_dry`, `ph_mix`, `ch_mix`, `vc_orig` vs. `slot.wetDry` | Processors implement internal wet/dry mix parameters while `handlesOwnWetDryMix()` returns `false`, causing `FxRackChain` to apply a second dry blend on top of the internal mix. |
| **BUG-31** | **LOW** | `TeleValue` (Double-Tap Numeric Input) & `FxPreviewPeaks` | Step quantization (`FxParameter.step`), non-stretching offline waveform preview | Double-tap keyboard input in `TeleValue.commitTyped()` bypasses `FxParameter.clampRaw()` step rounding; `FxPreviewPeaks` marks non-length-changing offline effects (`fade`, `changepitch`, `timeline` invert/reverse) as `lengthChanged = true`. |

---

## Detailed Bug Analysis & Technical Breakdown

### Part 1: Time, Duration, Delay, Hold, Attack/Release & Tempo Parameter Bugs

#### 1. `EditEngine.flushTailIntoRange` — Discarded Read Buffer Wipes Up to 4 Seconds of Audio After Selection (`BUG-01`)
* **Location**: `app/src/main/java/com/example/audiorecorder/EditEngine.java` (lines 727–757)
* **Affected Effects**: Any processor returning `getTailFrames() > 0`:
  * `FreeverbReverbProcessor` (`4.0 s` = 192,000 frames)
  * `EchoProcessor` (`2.0 s` = 96,000 frames)
  * `MultiDelayProcessor` (`4 * delayFrames`)
  * `ChorusFlangerProcessor` (`0.1 s` = 4,800 frames)
* **Root Cause**:
  ```java
  float[] dry = new float[blockFrames * ch];
  float[] wet = new float[blockFrames * ch];
  while (pos < limit) {
      int want = (int) Math.min(blockFrames, limit - pos);
      raf.seek(info.dataStart + pos * frameBytes);
      raf.readFully(Dsp.toBytes(dry, 0, want * ch)); // <-- CRITICAL BUG!
      System.arraycopy(dry, 0, wet, 0, want * ch);
      chain.processInPlace(wet, want);
  ```
  `Dsp.toBytes(dry, 0, want * ch)` allocates a **brand-new `byte[]`** from the zero-initialized `dry` array, passes that temporary `byte[]` into `raf.readFully(...)`, and **immediately discards the `byte[]`** without ever converting bytes back into `dry` (`Dsp.toFloats`)!
* **Impact**: `dry` remains all `0.0f`. `wet` receives `0.0f`, `chain.processInPlace(wet, want)` flushes the decaying tail over silence, and `raf.write(Dsp.toBytes(wet, 0, want * ch))` **overwrites `[endFrame, endFrame + tailFrames)` in the recording with silence + decaying reverb/echo tail**, completely erasing up to 4 seconds of the user's unselected audio immediately following the selection!
* **Fix**: Read into a `byte[] ioBuf = new byte[want * frameBytes]; raf.readFully(ioBuf); Dsp.toFloats(ioBuf, dry, want * ch);`. Furthermore, rather than running the full `chain.processInPlace(wet, want)` on the post-selection audio and crossfading (which also applies any non-tail gain/EQ/distortion in the chain to `[endFrame, endFrame + tailFrames)` with a linear fade!), feed `0.0f` into `chain.processInPlace(tailBuf, want)` (subtracting dry if `wetDry < 1`) and **add** the decaying tail onto the untouched `dry` samples in `[endFrame, endFrame + tailFrames)`.

---

#### 2. `BrickwallLimiterProcessor` (`bricklim`) — Lookahead Time Mismatch (`3 ms` vs `5 ms`), Dead `peakRing`, and Static Gain Penalty from `Hold` & `Release` (`BUG-06`)
* **Location**: `app/src/main/java/com/example/audiorecorder/fx/BrickwallLimiterProcessor.java` (lines 28, 72–79, 134–204)
* **Affected Parameters**:
  * Lookahead window (documented as `3 ms`)
  * `lim_hold` (`Hold`, `1..50 ms`, default `10 ms`)
  * `lim_release` (`Release`, `10..500 ms`, default `80 ms`)
  * `lim_gain` (`Input Gain`, `0..30 dB`)
  * `lim_ceil` (`Ceiling`, `-20..0 dB`)
  * `lim_makeup` (`Auto Makeup`, boolean)
* **Root Causes**:
  1. **Lookahead time mismatch**: `EffectType.BRICKWALL_LIMITER_STAGE4` and the class Javadoc state `"3 ms look-ahead limiter"`, and line 28 initializes `lookFrames = 144` (3 ms @ 48 kHz), but `prepare()` (line 73) and `processInPlace()` (line 125) overwrite `lookFrames = Math.max(1, (int) (sampleRate * 0.005))` (`5 ms` = 240 frames).
  2. **Dead `peakRing` sliding window**: Lines 177–178 write `peakRing[peakPos] = envPeak; peakPos = (peakPos + 1) % lookFrames;`, but **`peakRing` is never read anywhere in the class**! Instead, `windowPeakState` decays exponentially with a `12 ms` time constant (`0.012 * sampleRate`).
  3. **`lim_hold` does not hold**: When `holdCounter > 0` (lines 189–192), instead of keeping `gainDb` constant for `holdFrames`, it executes `gainDb = Math.max(requiredDb, gainDb * (1f - relCoef * 0.08f));`, decaying the gain reduction on every sample during the hold phase.
  4. **`lim_hold` and `lim_release` apply an artificial static volume cut**: Lines 199–201 compute:
     ```java
     float ballisticsTrimDb = (holdMs * 0.012f + relMs * 0.0025f) * (gainDb / (gainDb + 3.0f));
     float g = Dsp.dbToLin(-(gainDb + ballisticsTrimDb));
     ```
     Increasing `Hold` or `Release` time permanently reduces output gain by up to `1.85 dB` even on steady-state tones!
  5. **`lim_gain` (`Input Gain`) is silently scaled down by `0.65x`**: Line 136 computes `float drive = Dsp.dbToLin(inGainDb * 0.65f);` — setting `+10 dB` Input Gain only applies `+6.5 dB`.
  6. **`lim_makeup` (`Auto Makeup`) is scaled by `0.45x` and applied pre-detector**: Line 137 computes `mg = Dsp.dbToLin(Math.max(0f, -ceilDb) * 0.45f)` and multiplies the input before limiting (`buf * drive * mg`), pushing the signal into the ceiling rather than making up post-ceiling level.
  7. **Quiet signals far below `lim_ceil` are compressed**: Line 150 sets `softKneeThresh = Math.min(ceilLin * 0.85f, Math.max(1e-4f, bufMax * 0.65f))`. Because `bufMax * 0.65f` scales with the current chunk's peak, even a `-50 dBFS` signal with a `0.0 dBFS` ceiling has its top 35% compressed (`requiredDb = kneeOver * 0.35f`)!

---

#### 3. `AutoDuckProcessor` (`autoduck`) — `Max Pause` (`duck_pause`) Clamped to `42.6 ms`, Fake Periodic Pumping on Continuous Speech, and Incomplete `Fade Up` (`BUG-07`)
* **Location**: `app/src/main/java/com/example/audiorecorder/fx/AutoDuckProcessor.java` (lines 67–164)
* **Affected Parameters**:
  * `duck_pause` (`Max Pause`, `0..5000 ms`, default `1000 ms`)
  * `duck_fadedown` (`Fade Down`, `10..2000 ms`, default `200 ms`)
  * `duck_fadeup` (`Fade Up`, `10..2000 ms`, default `200 ms`)
  * `duck_thresh` (`Threshold`, `-60..-6 dB`, default `-30 dB`)
  * `duck_amount` (`Duck Amount`, `-48..0 dB`, default `-12 dB`)
* **Root Causes**:
  1. **`duck_pause` clamped to half of chunk size (`42.6 ms`)**:
     Line 118 computes `int pauseHoldLimit = Math.max(block, Math.min(pauseFrames, frames / 2));`. During offline bakes (`EditEngine` uses `blockFrames = 4096`) and live playback (`RawFloatPlayer` uses `1024` frames), `frames / 2` is `2048` frames (`42.6 ms`) or `512` frames (`10.6 ms`). Any `Max Pause` setting above `42.6 ms` (including the default `1000 ms` and up to `5000 ms`) is clamped to `42.6 ms`!
  2. **Fake LFO cycling on continuous speech**:
     Lines 133–138 check `if (silenceFrames > pauseHoldLimit || (maxBlockDb - minBlockDb) <= 6f)` while `speaking == true` and toggle `target` periodically every `cyclePeriod = pauseHoldLimit + (fadeDownSec + fadeUpSec) * sampleRate * 0.5f` between `duck * 0.35f * depthScale` and `duck * (0.45f + 0.55f * depthScale)`. Consequently, a steady voice or tone with `<= 6 dB` dynamic range within a chunk is rhythmically pumped up and down at a period driven by `duck_pause`, `duck_fadedown`, and `duck_fadeup`!
  3. **Never releases back to `0 dB` (`Fade Up` never reaches unity)**:
     On line 142, when `!speaking` and `silenceFrames >= pauseFrames`, `target` is set to `duck * 0.15f * depthScale` instead of `0f`.
  4. **`duck_thresh` overridden by local chunk levels**:
     Lines 111–115 replace the user's `thresh` (`duck_thresh`) with `effectiveThresh = 0.55f * thresh + 0.45f * adaptiveThresh` where `adaptiveThresh` is the midpoint of the current chunk's min/max dB.

---

#### 4. `TruncateSilenceProcessor` (`truncsil`) — `"Compress Excess Silence"` (`ts_compress`) Uses `minSilent` (`ts_min`) Instead of Actual Silence Duration (`BUG-08`)
* **Location**: `app/src/main/java/com/example/audiorecorder/fx/TruncateSilenceProcessor.java` (lines 76–130)
* **Affected Parameters**:
  * `ts_action` (`Action`: `"Truncate Detected Silence"` vs `"Compress Excess Silence"`)
  * `ts_compress` (`Compress To`, `1..99 %`, default `50 %`)
  * `ts_min` (`Min Silence`, `1..5000 ms`, default `500 ms`)
* **Root Cause**:
  ```java
  boolean compress = action.getCurrentRaw() == 1;
  int keepFrames = compress
          ? Math.max(1, (int) (minSilent * compressTo.getCurrentRaw() / 100f))
          : Math.max(1, (int) (truncateTo.getCurrentRaw() * 0.001f * sampleRate));
  ```
  And in Pass 2 & Pass 3 (lines 116, 125):
  ```java
  int keep = Math.min(spanLen, keepFrames);
  ```
  When `Action` is `"Compress Excess Silence"`, instead of compressing each detected silent span proportional to its actual duration (`spanLen * (compressTo / 100f)` or `minSilent + (spanLen - minSilent) * (compressTo / 100f)`), `keepFrames` is computed as a fixed fraction of `minSilent` (`ts_min`)!
* **Impact**: A 1-second silence and a 10-second silence are both cut to the exact same fixed duration (`ts_min * ts_compress%`), making `"Compress Excess Silence"` completely ignore the actual length of each silent pause.

---

#### 5. `FadeProcessor` (`fade`) — Inverted `Start Gain` / `End Gain` on Fade Out, Partial-Selection `20%` Default Length, and Filter Transient Click (`BUG-09`)
* **Location**: `app/src/main/java/com/example/audiorecorder/fx/FadeProcessor.java` (lines 38–42, 74–166)
* **Affected Parameters**:
  * `fade_type` (`Fade In`, `Fade Out`, `Studio Fade Out`, `Adjustable Fade`)
  * `fade_len` (`Fade Length`, `1..100 %`, default `20 %`)
  * `fade_start` (`Start Gain`, `0..100 %`, default `0 %`)
  * `fade_end` (`End Gain`, `0..100 %`, default `100 %`)
  * `fade_curve` (`Linear`, `Exponential`, `Logarithmic`, `S-Curve`, `Cosine`)
* **Root Causes**:
  1. **`Start Gain` and `End Gain` are backwards in `Fade Out` and `Studio Fade Out`**:
     In `applyRamp(..., fadeIn = false)` (lines 150–159):
     ```java
     if (f < start) {
         g = gEnd;
     } else {
         float u = (float) (f - start) / Math.max(1, fadeFrames - 1);
         float shaped = shapeCurve(1f - u);
         g = gStart + (gEnd - gStart) * shaped;
     }
     ```
     Because `shaped` goes from `1.0` (at fade start) down to `0.0` (at fade end), the gain at the **start** of the fade-out is `gEnd` (`End Gain`), and the gain at the **end** of the fade-out is `gStart` (`Start Gain`)! If a user selects `Fade Out` and sets `Start Gain = 80%`, `End Gain = 20%`, the audio starts at `20%` and fades **up** to `80%`!
  2. **`fade_len` defaults to `20%` of the selection**:
     When a user highlights a 2-second region to apply a `Fade In` or `Adjustable Fade`, only the first `0.4 s` (`20%`) is faded while the remaining `1.6 s` (`80%`) plays at constant `End Gain`.
  3. **`Adjustable Fade` vs `Fade Out` position inconsistency**:
     `Fade Out` and `Studio Fade Out` place the `fade_len` window at the **end** of the selection (`[frames - fadeFrames, frames)`), whereas `Adjustable Fade` (even when `g0 > g1`, i.e. a fade-out!) places the `fade_len` window at the **beginning** of the selection (`[0, fadeFrames)`).
  4. **`Studio Fade Out` biquad transient click**:
     In `Studio Fade Out` (lines 97–115), `closingLp.processSample()` is only called when `u > 0f` (`f > frames - fadeFrames`). At `f = frames - fadeFrames + 1`, `closingLp` engages with zeroed state (`z1 = 0, z2 = 0`) on a full-amplitude signal (`g ≈ 1.0`), producing a step discontinuity at the fade boundary.

---

#### 6. `ClickRemovalProcessor` (`declick`) — `click_width` (ms) Treated as Samples (`48x` Too Small) & Destructive Comb Filter When No Clicks Are Found (`BUG-04`)
* **Location**: `app/src/main/java/com/example/audiorecorder/fx/ClickRemovalProcessor.java` (lines 51–87)
* **Affected Parameters**:
  * `click_width` (`Max Spike Width`, `1..40 ms`, default `10 ms`)
  * `click_thresh` (`Threshold`, `1..100`, default `50`)
* **Root Causes**:
  1. **Milliseconds used directly as sample count**:
     ```java
     int maxSpike = Math.max(1, (int) (maxWidth.getCurrentRaw() * 0.001f * sampleRate));
     int halfWin = Math.max(1, Math.min(64, maxWidth.getCurrentRaw()));
     ```
     `maxSpike` converts `click_width` from milliseconds to samples (`480` samples at `10 ms` @ 48 kHz), **but `maxSpike` is never used!** Instead, `halfWin` uses `maxWidth.getCurrentRaw()` directly as **samples** (`10 samples` = `0.208 ms` at 48 kHz, capped at `64 samples` = `1.33 ms`)!
  2. **Destructive comb filter on clean audio when `!any`**:
     Lines 75–85:
     ```java
     if (!any) {
         // Subtle high-frequency transient smoothing when no hard spikes cross threshold
         float alpha = Math.min(0.35f, (100 - threshold.getCurrentRaw()) / 250f);
         for (int f2 = halfWin; f2 < frames - halfWin; f2++) {
             for (int c = 0; c < ch; c++) {
                 float nbr = 0.5f * (buf[(f2 - halfWin) * ch + c] + buf[(f2 + halfWin) * ch + c]);
                 buf[f2 * ch + c] = buf[f2 * ch + c] * (1f - alpha) + nbr * alpha;
             }
         }
     }
     ```
     Whenever a 4096-sample chunk has **zero clicks**, it blends every sample with the average of samples `±halfWin` away (`x[n - D]` and `x[n + D]`). That is a linear-phase cosine comb filter with transfer function $H(\omega) = (1 - \alpha) + \alpha \cos(\omega D)$, cutting deep notches across the frequency spectrum (e.g., at `2.4 kHz, 7.2 kHz, 12 kHz...` for `halfWin = 5`) and switching on and off per 4096-sample chunk depending on whether a single click was detected in that chunk!

---

#### 7. `EchoProcessor` (`echo`) & `MultiDelayProcessor` (`multidelay`) — Truncated `getTailFrames()`, Unshrunk Delay Buffer Wrap-Around, and Broken Bouncing-Ball Timing (`BUG-10`)
* **Location**:
  * `app/src/main/java/com/example/audiorecorder/fx/EchoProcessor.java` (lines 59–62)
  * `app/src/main/java/com/example/audiorecorder/fx/MultiDelayProcessor.java` (lines 66–150)
* **Affected Parameters**:
  * `echo_time` (`Delay Time`, `10..5000 ms`), `echo_decay` (`Decay`, `1..95 %`)
  * `md_time` (`Delay Time`, `10..3000 ms`), `md_echoes` (`Number of Echoes`, `1..30`), `md_type` (`Delay Type`)
* **Root Causes**:
  1. **`EchoProcessor.getTailFrames()` hardcoded to `2.0 s`**:
     `echo_time` supports up to `5000 ms` (`5.0 s`), yet `getTailFrames()` returns `(int) (sampleRate * 2.0)`. Any `echo_time > 2000 ms` has its very first echo cut off at selection end, and shorter delays with high `echo_decay` (e.g. `1000 ms` with `90%` decay) are truncated after 2 repeats.
  2. **`MultiDelayProcessor.getTailFrames()` hardcoded to `4` echoes**:
     `md_echoes` supports up to `30` echoes (default `5`), but `getTailFrames()` returns `delayFrames * 4`, truncating echoes `5..30`.
  3. **`MultiDelayProcessor.rebuild()` never shrinks `delayLine` when `md_time` or `md_echoes` decreases**:
     Line 75 only reallocates `if (delayLine.length < need * channels)`. Meanwhile, `processInPlace()` computes `maxFrames = delayLine.length / ch` and wraps `writePos = (writePos + 1) % (delayLine.length / ch)` using the old, larger array length, reading stale samples when grown without clearing.
  4. **`Reverse Bouncing Ball` (`md_type == 2`) uses equal tap intervals**:
     Despite the comment `"Reverse bouncing ball: expanding intervals with rising level"`, line 106 sets `offset = delayFrames * k` (identical equal spacing to `Regular Multi-Tap`), instead of expanding intervals.
  5. **`Bouncing Ball` (`md_type == 1`) feeds multi-tap sum back into the single delay line**:
     Line 143 writes `delayLine[writePos * ch + c] = in + wet * regen;`. Because `wet` is already the sum of `taps` non-uniformly spaced taps (`1 - 0.82^k`), feeding `wet * regen` back into the delay line creates dense chaotic cross-modulation between incommensurate tap delays whenever `md_feedback > 0`.

---

#### 8. `FreeverbReverbProcessor` (`reverb`) — `rv_predelay` Ring-Buffer Index Out-of-Sync, Unscaled 44.1 kHz Comb/Allpass Tunings, and State Wipe on Scrub (`BUG-11`)
* **Location**: `app/src/main/java/com/example/audiorecorder/fx/FreeverbReverbProcessor.java` (lines 17–25, 84–141, 179–185)
* **Affected Parameters**:
  * `rv_predelay` (`Pre-Delay`, `0..200 ms`, default `15 ms`)
  * `rv_size` (`Room Size`, `0..100 %`, default `60 %`)
* **Root Causes**:
  1. **`prePos` not reset or modulo-clamped when `rv_predelay` changes or `reset()` is called**:
     In `rebuild()` (lines 118–121), when `preFrames` changes, `prePos` is left untouched. If `preFrames` is reduced so `prePos >= preFrames`, line 137 (`preBuffer[prePos * 2]`) reads/writes out of the active `[0, preFrames)` window (or throws `ArrayIndexOutOfBoundsException` if `preBuffer` was ever sized smaller), and `reset()` (lines 84–96) forgets `prePos = 0;` and never clears `preBuffer`.
  2. **Comb and allpass delay lengths not scaled by `sampleRate / 44100.0`**:
     `COMB_TUNING = {1116, 1188, ...}` and `ALLPASS_TUNING = {556, 441, ...}` are in 44.1 kHz samples. At 48 kHz (or 96 kHz), `rebuild()` uses raw sample counts without multiplying by `sampleRate / 44100.0`, shifting room modes upward in pitch and shortening reverb decay time proportionally.
  3. **`Comb.resize()` zeroes the entire comb delay line whenever `rv_size` changes by 1%**:
     Lines 180–184 reallocate `buf = new float[len]` and reset `pos = 0; store = 0f;` on every `processInPlace` block while scrubbing `Room Size`, causing audible dropouts/clicks during live parameter adjustment.

---

#### 9. `VocoderProcessor` (`vocoder`) — `Envelope Release` (`vc_release`) Uses Raw Samples (`0.4 ms..2.5 ms`) Instead of Milliseconds (`BUG-12`)
* **Location**: `app/src/main/java/com/example/audiorecorder/fx/VocoderProcessor.java` (lines 48–50, 109, 128–129)
* **Affected Parameter**: `vc_release` (`Envelope Release`, `1..120`, default `20`)
* **Root Cause**:
  ```java
  float relCoef = 1f / Math.max(1, release.getCurrentRaw());
  ...
  envelopes[b] += (e - envelopes[b]) * relCoef;
  ```
  `relCoef` is applied once **per sample** at 48 kHz. At the default `vc_release = 20`, the time constant is `20 samples` = **`0.417 ms`** (cutoff frequency `~380 Hz`), and even at the maximum `vc_release = 120`, it is only `120 samples` = **`2.5 ms`**.
* **Impact**: A vocoder band envelope follower requires a `10..150 ms` release time constant (`1f - (float) Math.exp(-1.0 / (releaseMs * 0.001 * sampleRate))`) to track speech syllables smoothly. At `0.4 ms`, the envelope tracks individual fundamental pitch periods of the voice, causing heavy waveform-rate ring modulation distortion.

---

#### 10. `ChangeTempoProcessor` (`tempo`) & `ChangeSpeedAndPitchProcessor` (`speedpitch`) — Parameter Compounding, Hard `[0.15, 4.0]` Clamping, and Discontinuous Heuristic (`BUG-13`)
* **Location**:
  * `app/src/main/java/com/example/audiorecorder/fx/ChangeTempoProcessor.java` (lines 67–78)
  * `app/src/main/java/com/example/audiorecorder/fx/ChangeSpeedAndPitchProcessor.java` (lines 61–76)
* **Affected Parameters**:
  * `tempo_percent` (`-80..+400 %`), `tempo_bpmfrom` (`30..300 BPM`), `tempo_bpmto` (`30..300 BPM`)
  * `speed_mult` (`0.25x..4.00x`), `speed_percent` (`-75..+300 %`)
* **Root Causes**:
  1. **`ChangeTempoProcessor` multiplies `tempo_percent` and `bpmFrom / bpmTo` together**:
     If `tempo_percent` is non-zero AND `bpmFrom != bpmTo`, `stretchFactor()` multiplies both ratios together rather than linking them or using the most recently adjusted parameter.
  2. **`ChangeTempoProcessor` clamps `stretchFactor()` to `[0.15, 4.0]`**:
     `tempo_percent = -80%` requests a `5.0x` stretch (`1 / 0.20 = 5.0`), and `bpmFrom = 300, bpmTo = 30` requests a `10.0x` stretch (`300 / 30 = 10.0`), or `bpmFrom = 30, bpmTo = 300` requests `0.10x`. All values outside `[0.15, 4.0]` are silently clamped, so `tempo_percent` below `-75%` (`-75%..-80%`) has **zero effect**!
  3. **`ChangeSpeedAndPitchProcessor.speedFactor()` discontinuous jump**:
     ```java
     if (Math.abs(s - pctFactor) < 0.02) {
         factor = pctFactor;
     } else if (Math.abs(s - 1.0) > 1e-4 && Math.abs(pct) > 1e-4) {
         factor = s * pctFactor;
     }
     ```
     If `speed_percent` is `+50%` (`pctFactor = 1.50`) and the user drags `speed_mult` (`s`) across `1.50x`, at `s = 1.47x` the speed is `1.47 * 1.50 = 2.205x`, at `s = 1.49x` it suddenly drops to `1.50x`, and at `s = 1.53x` it jumps back to `1.53 * 1.50 = 2.295x`!

---

#### 11. `SlidingStretchProcessor` (`slidestretch`) & `WsolaTimePitchProcessor` (`changepitch`) — Un-Crossfaded 8-Step Staircase, Ignored `hq`/`formant` Flags, and Artificial Pitch Gain (`BUG-14`)
* **Location**:
  * `app/src/main/java/com/example/audiorecorder/fx/SlidingStretchProcessor.java` (lines 67–115)
  * `app/src/main/java/com/example/audiorecorder/fx/WsolaTimePitchProcessor.java` (lines 45, 146, 167–174)
* **Affected Parameters**:
  * `ss_rate_start`, `ss_rate_end`, `ss_pitch_start`, `ss_pitch_end`, `ss_cents_start`, `ss_cents_end`
  * `cp_semitones`, `cp_cents`, `cp_hq` (`High-Quality Speech`), `cp_formant` (`Preserve Formants`)
* **Root Causes**:
  1. **8-chunk staircase with no overlap/crossfade in `SlidingStretchProcessor`**:
     `processOfflineRegion` slices the input into `segments = 8` disjoint slices, runs a constant `pitchShift` and `timeStretch` on each slice independently, and concatenates them with `System.arraycopy` (`outPos += segFrames`). Because WSOLA and linear resampling shift phase across each slice, concatenating 8 independent slices without overlap-add produces 7 audible clicks/glitches and staircase pitch/tempo steps.
  2. **Artificial `±5.0 dB` gain offset in `WsolaTimePitchProcessor.pitchShift()`**:
     Lines 169–170:
     ```java
     double pitchGainDb = Math.max(-5.0, Math.min(5.0, semitones * 0.25));
     float normGain = (float) (Math.sqrt(inSum / outSum) * Dsp.dbToLin(pitchGainDb));
     ```
     Pitch-shifting up by `+20 semitones` boosts volume by `+5 dB` (potentially clipping near-0 dBFS audio), and shifting down by `-20 semitones` cuts volume by `-5 dB`.
  3. **`highQualitySpeech` (`cp_hq`) ignored inside `pitchShift()`**:
     `ChangePitchProcessor` passes `hq.getBoolean()` into `WsolaTimePitchProcessor.pitchShift(..., highQualitySpeech, preserveFormants)`, which on line 146 calls the 4-argument overload `timeStretch(input, frames, channels, alpha)` that hardcodes `highQualitySpeech = false`! Only the post-resample tilt filter checks `highQualitySpeech`, while the actual WSOLA window size (`16 ms` vs `28 ms`) completely ignores `cp_hq`!

---

### Part 2: Ignored, Clobbered, or Mis-Wired Effect Parameters

#### 12. `AudioGeneratorTool` (`generator`) — Scrambled DTMF Digits (`gen_seq`), Mismatched Noise Waveform Labels (`gen_wave`), and Selection-Overwriting `Silence` Duration (`BUG-17`)
* **Location**: `app/src/main/java/com/example/audiorecorder/fx/AudioGeneratorTool.java` (lines 62–72, 128–198)
* **Affected Parameters**:
  * `gen_type` (`Tone`, `Chirp`, `Silence`, `Noise`, `DTMF`, `Pluck`)
  * `gen_dur` (`Duration`, `0.05..60.0 s`, default `5.0 s`)
  * `gen_seq` (`DTMF Sequence`, `0..9999`)
  * `gen_wave` (`Waveform`: `Sine`, `Square`, `Sawtooth`, `Triangle`, `Square No-Alias`)
* **Root Causes**:
  1. **`renderDtmf` intentionally scrambles the user's dialed digits**:
     Lines 184–189:
     ```java
     int dChar = digitsStr.charAt(slotIdx) - '0';
     int digit = ((dChar >= 0 && dChar <= 9 ? dChar : 0) + slotIdx + (seqVal & 3)) & 0x0F;
     int row = (digit / 4) & 3;
     int col = digit & 3;
     ```
     Adding `+ slotIdx + (seqVal & 3)` and mapping `0..9` sequentially onto the 4x4 `(row, col)` matrix (where row 0 col 3 is `'A'` = 697+1633 Hz and digit `'0'` is mapped to row 0 col 0 = `'1'`) means dialing `"123"` or `"5"` never produces the standard ITU-T Q.23 DTMF tones for those digits!
  2. **`Noise` waveform labels vs implementation mismatch**:
     When `gen_type` is `"Noise"`, `gen_wave` still displays oscillator labels `{"Sine", "Square", "Sawtooth", "Triangle", "Square No-Alias"}`. Even worse, the comment at lines 130–131 says `"square stands for white, triangle for pink and sawtooth for brown"`, while the code maps `0 (Sine) -> White`, `1 (Square) -> Pink`, `2 (Sawtooth) -> Brown`, `3 (Triangle) -> Blue`, `4 (Square No-Alias) -> Velvet`.
  3. **`Silence` and other generator modes ignore active selection length**:
     When a user selects a region on the waveform (e.g. `0.35 s` to silence a word) and applies `Generator -> Silence`, `processOfflineRegion` ignores `frames` (the selection length) and replaces the selection with `gen_dur` (`5.0 seconds` by default) of silence!

---

#### 13. `NoiseGateExpanderProcessor` (`gateexp`) — User `Threshold` (`gate_thresh`) Overridden on Loud Signals & Gate Attenuates While Open (`BUG-18`)
* **Location**: `app/src/main/java/com/example/audiorecorder/fx/NoiseGateExpanderProcessor.java` (lines 114–165)
* **Affected Parameters**:
  * `gate_thresh` (`Threshold`, `-96..-6 dB`, default `-42 dB`)
  * `gate_range` (`Level Reduction`, `-100..0 dB`, default `-24 dB`)
  * `gate_ratio` (`Expander Ratio`, `1.2..10.0 :1`)
  * `gate_mode` (`Gate` vs `Downward Expander`)
* **Root Causes**:
  1. **Adaptive threshold overrides `gate_thresh` when signal is entirely above threshold**:
     ```java
     float normT = (thresh - (-96f)) / 90f;
     float effThresh = (minSigDb > thresh + 6f)
             ? (minSigDb + normT * Math.max(6f, maxSigDb - minSigDb))
             : thresh;
     ```
     If a chunk contains continuous speech ranging from `-25 dBFS` (`minSigDb`) to `-10 dBFS` (`maxSigDb`) and the user sets `gate_thresh = -42 dB` (so the gate should remain 100% open!), `minSigDb > thresh + 6f` (`-25 > -36`) is **true**, so `effThresh` is forced up to `-25 + 0.6 * 15 = -16 dBFS`! The gate then closes and chatters right in the middle of loud speech that is 26 dB above the user's threshold!
  2. **Gate attenuates up to `35%` of `gate_range` while `open == true` and scales `Gate` depth by `gate_ratio`**:
     ```java
     if (open) {
         float margin = Math.max(0f, (effThresh + kneeSpan) - detectDb);
         target = margin > 0f ? (rangeDb * Math.min(0.35f, margin / (kneeSpan * 3f))) : 0f;
     } else {
         float under = Math.max(0f, (effThresh - hyst * 0.25f) - detectDb);
         float ratioFactor = Math.min(1f, (under + 1f) * (expRatio / 10f));
         target = rangeDb * (0.55f + 0.45f * ratioFactor);
     }
     ```
     Even when `open == true` (including during `Hold` and `Hysteresis`!), any signal within `kneeSpan` above `effThresh` (or below `effThresh` during hold/hysteresis) is attenuated by up to `0.35 * rangeDb` (up to `-35 dB`!). And when closed (`!open`), `"Gate"` mode only reaches `55%..100%` of `gate_range` depending on `gate_ratio` (`Expander Ratio`), which shouldn't affect `"Gate"` mode at all!

---

#### 14. `ProLimiterProcessor` (`limiter`) — Compresses Quiet Signals Far Below `limiter_ceiling` (`BUG-19`)
* **Location**: `app/src/main/java/com/example/audiorecorder/fx/ProLimiterProcessor.java` (lines 119–159)
* **Affected Parameters**: `limiter_ceiling` (`Ceiling`, `-6.0..-0.1 dB`), `limiter_Amount` (`Drive`, `0..100 %`)
* **Root Cause**:
  ```java
  final float effThresh = Math.min(c, Math.max(1e-4f, bufPeak * 0.72f));
  ...
  } else if (peak > effThresh && effThresh > 1e-5f) {
      float ratio = effThresh / peak;
      desired = 0.75f + 0.25f * ratio;
  }
  ```
  Because `effThresh` is set to `bufPeak * 0.72f` (where `bufPeak` is the maximum sample of the current chunk), **every signal regardless of how quiet it is** (even `-45 dBFS` room tone when `Ceiling` is `-0.2 dBFS`!) exceeds `bufPeak * 0.72f` on the top 28% of its waveform and undergoes up to `~1.9 dB` of dynamic gain reduction per chunk!

---

#### 15. `AmplifyProcessor` (`amplify`) — `New Peak` (`amp_peak`) Attenuates Instead of Boosting When `amp_gain == 0`, and Ignores `Allow Clipping` (`BUG-20`)
* **Location**: `app/src/main/java/com/example/audiorecorder/fx/AmplifyProcessor.java` (lines 52–69)
* **Affected Parameters**: `amp_gain` (`Amplification`, `-50..+50 dB`), `amp_peak` (`New Peak`, `-50..+12 dB`), `amp_clip` (`Allow Clipping`)
* **Root Causes**:
  ```java
  float requested = gain.getFloat();
  float ceiling = newPeak.getFloat();
  float maxAllowed = ceiling - peakDb;
  if (Math.abs(requested) <= 0.01f && Math.abs(ceiling) > 0.01f) {
      if (ceiling < peakDb) {
          requested = maxAllowed;
      } else {
          requested = ceiling; // <-- BUG 1!
      }
  } else if (Math.abs(ceiling) > 0.01f && ceiling < 0f) {
      requested = Math.min(requested, maxAllowed); // <-- BUG 2!
  }
  if (!allowClip.getBoolean() && requested > maxAllowed) {
      requested = maxAllowed;
  }
  ```
  1. **Bug 1**: If the input audio peaks at `-12 dBFS` (`peakDb = -12`), `amp_gain` is left at `0.0 dB`, and the user sets `New Peak = -3.0 dBFS` (`ceiling = -3`), then `ceiling < peakDb` (`-3 < -12`) is `false`, so `requested` is set to `ceiling` (`-3.0 dB`) instead of `maxAllowed` (`-3 - (-12) = +9.0 dB`)! The audio is attenuated to `-15 dBFS` instead of amplified to `-3 dBFS`!
  2. **Bug 2**: When `amp_gain` is non-zero (e.g. `+15 dB`), `amp_peak` is `< 0f` (e.g. `-1.0 dB`), and the user explicitly enables `Allow Clipping = true`, the `else if (Math.abs(ceiling) > 0.01f && ceiling < 0f)` branch unconditionally clamps `requested = Math.min(requested, maxAllowed)` **without checking `!allowClip.getBoolean()`**!

---

#### 16. `ClipFixProcessor` (`clipfix`) & `RepairProcessor` (`repair`) — Corrupt Unclipped / Clean Audio (`BUG-21`, `BUG-05`)
* **Locations**:
  * `app/src/main/java/com/example/audiorecorder/fx/ClipFixProcessor.java` (lines 54–103)
  * `app/src/main/java/com/example/audiorecorder/fx/RepairProcessor.java` (lines 166–180)
* **Root Causes**:
  1. **`ClipFixProcessor` sets `refPeak = maxAbs` whenever `maxAbs < 0.80f`**:
     On any normal, unclipped take whose peak is below `-1.94 dBFS` (`0.80`), `clipLevel = (threshold / 100f) * maxAbs`. In every 1024- or 4096-sample chunk, the top `100% - clip_thresh%` (e.g. top 5% at default `95%`) of natural waveform peaks are falsely flagged as clipped plateaus and replaced with cubic spline arcs, followed by a mandatory `headroom` attenuation (default `-6 dB`)!
  2. **`RepairProcessor` overwrites up to 58% of every clean chunk when `!repairedAny`**:
     In `RepairProcessor.processInPlace()` (lines 166–180), if no silent dropouts exist in the current 4096-sample block (`!repairedAny`), it finds the single sample with the largest second derivative `|x[i] - 0.5*(x[i-1] + x[i+1])|` and replaces a window of length `maxFrames` (up to `50 ms` = `2400 samples` out of `4096`) around it with a 12th-order LPC synthesis!

---

#### 17. `WahwahProcessor` (`wah`), `BassAndTrebleProcessor` (`basstreble`), and `NotchFilterProcessor` (`notch`) — Parameter Logic Traps (`BUG-23`, `BUG-24`, `BUG-29`)
* **Locations**:
  * `WahwahProcessor.java` (lines 62–65):
    ```java
    @Override
    public boolean isAudible() {
        return isEnabled() && depth.getCurrentRaw() > 0;
    }
    ```
    If the user sets `wah_depth` (`LFO Depth`) to `0%` in order to use **Auto-Wah** (`wah_auto > 0%`, envelope follower mode) or a static resonant filter (`wah_offset`), `isAudible()` returns `false` and `FxRackChain` completely bypasses `WahwahProcessor`!
  * `BassAndTrebleProcessor.java` (lines 67–79) & `StudioFragment.java` (lines 1766–1768, 2180–2182):
    When `link` (`Link Bass/Treble`) is enabled and both `bass` and `treble` are `0.0 dB`, `buildSections()` forces `b = 3.0; t = 3.0;` (`+3.0 dB` boost on both bands), and `StudioFragment` overwrites the user's `0.0 dB` knob values with `+3.0 dB`. Setting `0.0 dB` with `Link` enabled is impossible.
  * `NotchFilterProcessor.java` (lines 65–76):
    When `preset` (`Quick Pick`) is `1` (`50 Hz hum`) or `2` (`60 Hz hum`), `buildSections()` hardcodes `f = 50.0` or `60.0` and ignores `freq.getFloat()`.

---

#### 18. `LoudnessNormalizationProcessor` (`loudness`) — Early Return Skips `True-Peak Ceiling` (`loud_ceiling`) and Soft-Clip Exceeds Ceiling by Up to `+6 dB` (`BUG-25`)
* **Location**: `app/src/main/java/com/example/audiorecorder/fx/LoudnessNormalizationProcessor.java` (lines 193–215)
* **Affected Parameters**: `loud_ceiling` (`True-Peak Ceiling`, `-9.0..0.0 dB`, default `-1.0 dB`), `loud_target` (`Target Loudness`)
* **Root Causes**:
  1. **Early return skips ceiling**:
     ```java
     float gain = Dsp.dbToLin(gainDb);
     if (gain == 1f) return; // <-- Returns before applying loud_ceiling!
     ```
     If the audio is already at the target LUFS/RMS (`appliedGainDb == 0f`), `processInPlace()` returns at line 202 and **never executes the `loud_ceiling` limiter loop** (lines 206–215), leaving peaks above `loud_ceiling` untouched!
  2. **Soft-clip formula exceeds `ceilLin` instead of bounding at `ceilLin`**:
     Line 212 computes `float s = ceilLin + over / (1f + over / ceilLin);`. When `a > ceilLin` (`over = a - ceilLin > 0`), `s` is strictly **greater** than `ceilLin` (approaching `2 * ceilLin`, or `+6 dB` above `loud_ceiling`)! A true ceiling must never exceed `ceilLin`.

---

#### 19. `SpectralNoiseReductionProcessor` (`specnr`) & `SpectralEditProcessor` (`spectraledit`) — Per-Chunk STFT Re-Instantiation & `Spectral Delete` Gain Inversion (`BUG-26`)
* **Locations**:
  * `SpectralNoiseReductionProcessor.java` (lines 166–220)
  * `SpectralEditProcessor.java` (lines 71–103)
  * `StftProcessor.java` (lines 68–107)
* **Root Causes**:
  1. **Stateless chunked STFT**: Both processors allocate a new `StftProcessor(FFT_SIZE, HOP_SIZE)` on every `processInPlace` call (`1024` frames in live playback, `4096` frames in offline bake). Because `StftProcessor.process()` pads each chunk with zeros on both sides without carrying overlap-add buffers across calls, any spectral modification creates time-aliased circular-convolution tails that are abruptly cut off at every 1024/4096-sample boundary (`46.8 Hz` / `11.7 Hz` frame-rate modulation).
  2. **`SpectralEditProcessor` (`se_mode == 2`, `"Spectral Delete / Notch"`)**:
     Line 93: `float targetDb = modeIdx == 2 ? (Math.abs(g) > 0.1f ? -Math.abs(g) : -24f) : g;`. At default `se_gain = 0.0 dB`, `"Spectral Delete / Notch"` only attenuates by `-24 dB` (not a full notch), and moving `se_gain` to `-1.0 dB` or `+1.0 dB` **weakens** the notch from `-24 dB` to `-1 dB`!
  3. **Brickwall Gaussian truncation in `Spectral Parametric EQ` (`se_mode == 0`)**:
     At `hz = f1` and `hz = f2`, `d = ±0.5`, so `weight = exp(-0.25) = 0.7788`, which is abruptly zeroed outside `[f1, f2]`, creating sharp spectral steps at `f1` and `f2`.

---

#### 20. `PlosiveBreathSuppressorProcessor` (`plosive`), `DeEsserProcessor` (`deesssplit`), `ProCompressorProcessor` (`comp`), & `MultibandCompressorProcessor` (`mbcomp`) (`BUG-27`, `BUG-28`)
* **Locations & Root Causes**:
  * **`PlosiveBreathSuppressorProcessor.java` (lines 99–103)**: `plosive_breath` (`Breath Attenuation`) never measures high-frequency breath energy, scales the user's dB setting by `0.45f` max, and keeps `breathWeight >= 0.15f` even during loud speech (`midDb > -12 dBFS`), permanently attenuating the entire full-band signal by `0.0675 * plosive_breath` dB!
  * **`DeEsserProcessor.java` (lines 71–116)**: Subtracts a 2nd-order Butterworth low-pass (`splitLow`) from the dry input (`high = buf - lowBand`). Because a 2nd-order Butterworth LP has a `-90°` phase shift at `ds_freq`, `1 - LP(s)` is **not** a complementary high-pass filter — it has a `+3 dB` resonant peak near `ds_freq` and leaks phase-shifted low frequencies into the "high" band. It also has no attack/release parameters, ramping linearly over 64 samples (`1.33 ms`).
  * **`ProCompressorProcessor.java` (lines 136–157)**:
    * Scales `(ratio - 1)` by `amount = amt.getCurrentRaw() / 100f` (`effRatio = 1f + (ratio - 1f) * amount`), so the user's `comp_ratio` (`Ratio`) setting is silently weakened whenever `Compression % < 100%`.
    * Applies static makeup gain `makeupDb = -threshDb * slope * 0.5f` immediately on initial silence (`gainCur` ramps from `1.0` to `fastDbToLin(makeupDb)` in the first 16 samples before any voice arrives).
  * **`MultibandCompressorProcessor.java` (lines 171–173)**: Hardcodes `rms = false` in `envLow.detect`, `envMid.detect`, and `envHigh.detect`, and clamps `hx = Math.max(lx + 50f, highXover.getCurrentRaw())` internally without syncing the UI parameter when `mb_lowx >= mb_highx - 50`.

---

### Part 3: Pipeline, Save-Time Bake, Sub-Selection, Multi-Instance & Preview Bugs

#### 21. `ConversionJobs.dispatchSave()` Drops All 9 Stage 7 Offline / Time / Duration Effects on Save (`BUG-02`)
* **Location**: `app/src/main/java/com/example/audiorecorder/ConversionJobs.java` (lines 572–589, 621–636)
* **Affected Effects**: `tempo`, `speedpitch`, `changepitch`, `slidestretch`, `paulstretch`, `fade`, `timeline`, `truncsil`, `generator`
* **Root Cause**:
  When `needsFxBake` is `true` at save time, `ConversionJobs.dispatchSave()` creates `DspChain chain = new DspChain(info.channels, cfg)` and calls `EditEngine.applyDspToRange(raw, 0, totalFrames, chain, null)`.
  * `EditEngine.applyDspToRange` only calls `chain.processInPlace(...)` -> `FxRackChain.processInPlace(...)`.
  * `FxRackChain.processInPlace()` (line 266) has `if (!p.isEnabled() || p.isOfflineOnly()) continue;`!
  * Unlike `StudioFragment.commitDspFx()`, `ConversionJobs.dispatchSave()` **never checks `chain.offlineProcessors()` and never calls `EditEngine.applyLengthChangingEffectToRange()`**!
* **Impact**: Any unbaked offline/time effect in the rack is **100% skipped and absent from the saved file**.

---

#### 22. `StudioFragment.runSaveDispatch()` + `resetFxRackAfterApply()` Destroys Sub-Selection FX Bakes and Re-Bakes Over the Full File (`BUG-03`)
* **Location**: `app/src/main/java/com/example/audiorecorder/StudioFragment.java` (lines 1104–1117, 1791–1797, 2497–2531)
* **Root Cause**:
  1. When the user selects a sub-range `[fxApplyTargetStart, fxApplyTargetEnd)` and commits FX (pressing Stop in FX mode), `commitDspFx()` bakes the effect into the sub-selection of `currentRawFile`, sets `dspBakedToRaw = true; dspSubRangeBaked = true;`, and calls `resetFxRackAfterApply()`.
  2. Despite the comment in `commitDspFx()` stating `"the raw file and waveform now carry the processed audio, so start a fresh, blank rack"`, `resetFxRackAfterApply()` **leaves all `dspConfig.slots` enabled (`dspConfig.isActive() == true`)**!
  3. If the user subsequently touches any FX knob (or toggles a slot), `onSlotMutated` sets `lastEditWasSubRangeBake = true; dspBakedToRaw = false;`.
  4. When the user saves (`runSaveDispatch()`, lines 1104–1117), it sees `lastEditWasSubRangeBake && dspConfig.isActive()`, **pops the undo stack** (discarding the sub-range bake!), marks `needsFxBake = true`, and passes `dspConfig` to `ConversionJobs.dispatchSave()`, which bakes the rack across **`[0, totalFrames)` (the entire recording)** instead of the user's sub-selection!

---

#### 23. `DspChain` Multi-Instance Legacy Stage Overwrite & `ProToneProcessor` Split vs. Unsplit Wet/Dry Mismatch (`BUG-22`)
* **Location**: `app/src/main/java/com/example/audiorecorder/DspChain.java` (lines 382–442, 672–778) and `ProToneProcessor.java` (lines 111–201)
* **Root Causes**:
  1. **Duplicate legacy stage primary `value` overwrite**:
     `Config.addOrFocusSlot()` appends duplicate `EffectSlot`s even for the 8 legacy stages. In `DspChain.ensureRackSlots()`, the first legacy slot binds to the canonical processor (`instanceKey == null`) and the second binds to a new instance (`instanceKey = "slot:..."`). However, `Config.syncLegacyFieldsFromSlots()` iterates over `slots` and overwrites `cfg.compPct` (and `noisePct`, `deEssPct`, `hpfCutoffHz`, `warmthPct`, `presencePct`, `gatePct`, `limiterPct`) with the **last** enabled slot's value! Then `rack.applyLegacyConfig(cfg)` writes that last slot's value into the **first** canonical processor (`instanceKey == null`), so both instances run with the 2nd slot's primary value!
  2. **`ProToneProcessor` (`Warmth` / `Presence`) wet/dry mix scales dB instead of linear sample mix**:
     `ProToneProcessor.handlesOwnWetDryMix()` returns `true` whenever `warmthSlotMix < 0.999f || presenceSlotMix < 0.999f`. Instead of mixing dry and wet audio linearly (`(1 - mix) * dry + mix * wet`), `updateTargets()` multiplies the shelf filter's **dB gain** by `wMix` and `pMix` (`9f * wMix` dB), producing a completely different frequency/phase response from linear wet/dry mixing (and differing from `processWarmthOnly` / `processPresenceOnly` when the two stages are separated in the rack!).

---

#### 24. `RawFloatPlayer` — Live Preview Playhead & Pause/Resume Broken on Time-Stretched Audio (`BUG-15`)
* **Location**: `app/src/main/java/com/example/audiorecorder/RawFloatPlayer.java` (lines 201–215, 302–342)
* **Root Cause**:
  When playing an offline-rendered buffer `offlineBuf` whose length `outFrames` differs from the source selection `limitFrame - startFramePos`:
  ```java
  public long positionFrames() {
      ...
      long head = track.getPlaybackHeadPosition() & 0xFFFFFFFFL;
      long limit = stopAtFrame > 0 ? stopAtFrame : totalFrames;
      return Math.min(limit, startFramePos + head);
  }
  ```
  `head` advances in **stretched output frames** (`0..outFrames`), whereas `limit` (`stopAtFrame`) is in **unstretched source frames** (`limitFrame`).
  * When an effect stretches audio longer (`outFrames > limitFrame - startFramePos`, e.g. `Change Tempo -50%`, `Paulstretch`, `Timeline Repeat`), `startFramePos + head` hits `limit` partway through playback: the UI playhead freezes at the end of the selection while audio keeps playing, and pressing **Pause** records `framePos = limitFrame`, losing the playback position!
  * When an effect shortens audio (`outFrames < limitFrame - startFramePos`, e.g. `Change Tempo +100%`, `Truncate Silence`), `startFramePos + head` stops short of `limitFrame` and jumps at playback completion.

---

#### 25. `EditEngine.applyLengthChangingEffectToRange` — Zero-Crossing Snap Drops/Duplicates Up to 240 Frames & Misreports `newTotal` (`BUG-16`)
* **Location**: `app/src/main/java/com/example/audiorecorder/EditEngine.java` (lines 460–517, 672–720)
* **Root Cause**:
  1. Line 470 reads the selected region `[startFrame, endFrame)` using the exact `endFrame`.
  2. Line 494 calls `saveTailFrom(raw, endFrame, tailTmp)`, which calls `Dsp.snapToZeroCrossing(..., endFrame, ..., 240)` and shifts the tail start by up to `±240 frames` (`±5 ms`), either duplicating or deleting up to 240 frames at `endFrame`!
  3. Line 502 calls `spliceTailAfterReplace(raw, startFrame + newFrames, tailTmp)`, which overlaps the first `fade` (`240`) frames of `tailTmp` over the last `240` frames of `rendered` (`replaceEndFrame - fade`), making the actual file length `startFrame + newFrames + tailFrames - fade`.
  4. Line 505 returns `long newTotal = startFrame + newFrames + tailFrames;` (off by `+fade` frames), which `StudioFragment.commitDspFx()` uses to compute `regionEnd` for the next offline processor in the chain!

---

#### 26. Double Wet/Dry Mixing (`BUG-30`) & `TeleValue` Keyboard Step Bypass / `FxPreviewPeaks` Flag (`BUG-31`)
* **Double Wet/Dry Mix (`BUG-30`)**:
  `FreeverbReverbProcessor` (`rv_wet`, `rv_dry`, `rv_wetonly`), `PhaserProcessor` (`ph_mix`), `ChorusFlangerProcessor` (`ch_mix`), and `VocoderProcessor` (`vc_orig`) each have internal dry/wet mix controls, while `handlesOwnWetDryMix()` returns `false` (default in `AudioProcessor`). Adjusting the rack slot's `Wet-Dry Mix` blends the dry input a second time on top of the already-mixed output.
* **`TeleValue.commitTyped()` Bypasses `FxParameter.step` (`BUG-31a`)**:
  In `TeleValue.java` (lines 483–505), double-tap keyboard entry parses `Double.parseDouble(raw) * valueScale` and calls `setValue(v, true)`, which clamps to `[min, max]` without rounding to `FxParameter.step` (`clampRaw`), allowing off-grid raw integer values.
* **`FxPreviewPeaks.renderRegionInternal()` Marks Non-Length-Changing Offline Effects as `lengthChanged = true` (`BUG-31b`)**:
  In `FxPreviewPeaks.java` (line 224), `isLiveTimeline` returns `new LiveRegionResult(..., true, newTotalFrames, ...)` unconditionally whenever `!chain.offlineProcessors().isEmpty()`, even for `FadeProcessor`, `ChangePitchProcessor`, and `TimelineUtilityProcessor` (Invert/Reverse) where `rFrames == dryFrames`.

---

## Prioritized Remediation Roadmap

1. **Immediate Data-Safety Fixes (P0)**:
   * **`EditEngine.flushTailIntoRange`**: Fix `raf.readFully(Dsp.toBytes(dry, ...))` by reading into a `byte[]` and converting via `Dsp.toFloats`, and mix decaying tail energy additively onto `dry` rather than overwriting post-selection audio with the full FX chain.
   * **`ConversionJobs.dispatchSave`**: Execute offline processors (`chain.offlineProcessors()` via `EditEngine.applyLengthChangingEffectToRange`) before `EditEngine.applyDspToRange` whenever `needsFxBake` is true.
   * **`StudioFragment.commitDspFx` / `resetFxRackAfterApply`**: Either clear/disable baked slots upon commit or persist the sub-selection range `[fxApplyTargetStart, fxApplyTargetEnd)` so save-time re-bakes never expand a sub-selection bake to `[0, totalFrames)`.
   * **`ClickRemovalProcessor` & `RepairProcessor`**: Remove the `!any` comb-filter branch in `ClickRemovalProcessor` and the `!repairedAny` fallback LPC branch in `RepairProcessor` so clean audio is never corrupted; fix `halfWin = Math.max(1, maxSpike / 2)` in `ClickRemovalProcessor`.
2. **Time & Envelope Semantics Fixes (P1)**:
   * **`BrickwallLimiterProcessor` & `ProLimiterProcessor`**: Remove `bufPeak * 0.72f` / `bufMax * 0.65f` adaptive thresholds so limiters only act near `Ceiling`; read the `peakRing` lookahead buffer; hold `gainDb` constant while `holdCounter > 0`; remove `ballisticsTrimDb` and `0.65f` input-gain scaling.
   * **`AutoDuckProcessor`**: Remove `Math.min(pauseFrames, frames / 2)` clamping on `pauseHoldLimit`, remove the fake LFO cycle when `(maxBlockDb - minBlockDb) <= 6f`, release `target` to `0.0 dB` after `pauseFrames`, and respect `duck_thresh` directly.
   * **`TruncateSilenceProcessor`**: Compute `keep = Math.max(1, Math.round(spanLen * (compressTo.getCurrentRaw() / 100f)))` in `"Compress Excess Silence"` mode.
   * **`VocoderProcessor`**: Convert `vc_release` from milliseconds to a sample-rate-aware coefficient: `float relCoef = 1f - (float) Math.exp(-1.0 / Math.max(1.0, release.getCurrentRaw() * 0.001 * sampleRate));`.
   * **`EchoProcessor` & `MultiDelayProcessor`**: Compute `getTailFrames()` dynamically from `echo_time`/`echo_decay` and `md_time * md_echoes`; use expanding tap offsets in `Reverse Bouncing Ball`; clamp `writePos` and resize `delayLine` cleanly.
   * **`FreeverbReverbProcessor`**: Scale `COMB_TUNING`, `ALLPASS_TUNING`, and `STEREO_SPREAD` by `sampleRate / 44100.0`; clamp/reset `prePos` when `preFrames` changes or `reset()` is called.
3. **Parameter Accuracy & Pipeline Polish (P2)**:
   * Fix `FadeProcessor` `Start Gain`/`End Gain` inversion on Fade Out and pre-warm `closingLp`.
   * Fix `AudioGeneratorTool` DTMF keypad mapping (`1209/1336/1477/1633 Hz` x `697/770/852/941 Hz`), noise waveform enum labels, and selection-length handling for `Silence`.
   * Fix `AmplifyProcessor.computeEffectiveGainDb`, `ClipFixProcessor` `refPeak`, `NoiseGateExpanderProcessor` `effThresh`, `WahwahProcessor.isAudible()`, `BassAndTrebleProcessor` `link` at `0 dB`, and `LoudnessNormalizationProcessor` early return before `loud_ceiling`.
   * Scale `RawFloatPlayer.positionFrames()` by `(double) (limitFrame - startFramePos) / outFrames` during offline buffer playback so the playhead tracks time-stretched audio accurately.
