package com.takeone.studio;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import android.app.Activity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;

import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;

import org.junit.Test;
import org.junit.runner.RunWith;

/**
 * Regression cover for the prompter appearing "dead": no scrolling, and the
 * script stopping after the first screenful.
 */
@RunWith(AndroidJUnit4.class)
public class TeleprompterScrollBoundsTest {

    private Activity launch() {
        android.app.Instrumentation instr =
                InstrumentationRegistry.getInstrumentation();
        android.content.Intent i = new android.content.Intent(
                instr.getTargetContext(), MainActivity.class);
        i.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK
                | android.content.Intent.FLAG_ACTIVITY_CLEAR_TASK);
        return instr.startActivitySync(i);
    }

    private static String manyWords(int n) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < n; i++) {
            if (i > 0) sb.append(' ');
            sb.append("word").append(i);
        }
        return sb.toString();
    }

    /**
     * The exact ordering the real screen uses: script is assigned before the
     * view has a size. The scroll bounds were computed at height 0 and then
     * never recomputed, leaving maxScroll at 0.
     */
    @Test
    public void scriptSetBeforeLayoutStillGetsScrollBounds() {
        Activity a = launch();
        TeleprompterView v = new TeleprompterView(a);

        // No measure/layout yet: width and height are both 0.
        v.setScript(manyWords(400));
        assertEquals("precondition: unlaid view has no bounds",
                0f, v.maxScroll(), 0.01f);

        int w = 900, h = 600;
        v.measure(
                View.MeasureSpec.makeMeasureSpec(w, View.MeasureSpec.EXACTLY),
                View.MeasureSpec.makeMeasureSpec(h, View.MeasureSpec.EXACTLY));
        v.layout(0, 0, w, h);

        assertTrue("maxScroll stayed 0 after layout, so the script cannot "
                + "be scrolled past the first screenful", v.maxScroll() > 0f);

        // And it must actually be able to reach the end.
        v.setScrollOffset(Float.MAX_VALUE);
        assertEquals("did not reach the end", v.maxScroll(),
                v.scrollOffset(), 0.01f);
        assertTrue("end of script is at the top of the view",
                v.scrollOffset() > 0f);
    }

    @Test
    public void resizingKeepsScrollBoundsValid() {
        Activity a = launch();
        TeleprompterView v = new TeleprompterView(a);
        v.measure(
                View.MeasureSpec.makeMeasureSpec(900, View.MeasureSpec.EXACTLY),
                View.MeasureSpec.makeMeasureSpec(600, View.MeasureSpec.EXACTLY));
        v.layout(0, 0, 900, 600);
        v.setScript(manyWords(400));
        float before = v.maxScroll();
        assertTrue("no scroll range when laid out", before > 0f);

        // Panel height does not change where the tail has to stop, so the
        // range is stable; what matters is that it stays reachable and that a
        // position from the old height is re-clamped into the new bounds.
        v.scrollBy(100000f);
        v.measure(
                View.MeasureSpec.makeMeasureSpec(900, View.MeasureSpec.EXACTLY),
                View.MeasureSpec.makeMeasureSpec(300, View.MeasureSpec.EXACTLY));
        v.layout(0, 0, 900, 300);
        assertTrue("scroll range vanished after resize", v.maxScroll() > 0f);
        v.scrollBy(100000f);
        assertTrue("offset exceeded bounds after resize",
                v.scrollOffset() <= v.maxScroll() + 0.5f);
        assertTrue("offset left the script", v.scrollOffset() > 0f);
    }

    @Test
    public void draggingTheScriptScrollsIt() {
        Activity a = launch();
        TeleprompterView v = new TeleprompterView(a);
        int w = 900, h = 600;
        v.measure(
                View.MeasureSpec.makeMeasureSpec(w, View.MeasureSpec.EXACTLY),
                View.MeasureSpec.makeMeasureSpec(h, View.MeasureSpec.EXACTLY));
        v.layout(0, 0, w, h);
        v.setScript(manyWords(400));

        final float before = v.scrollOffset();
        // Drag upward: the text follows the finger, revealing later lines.
        v.onTouchEvent(motion(MotionEvent.ACTION_DOWN, 300f, 300f));
        for (float y = 290f; y >= 110f; y -= 20f) {
            v.onTouchEvent(motion(MotionEvent.ACTION_MOVE, 450f, y));
        }
        v.onTouchEvent(motion(MotionEvent.ACTION_UP, 450f, 110f));
        assertTrue("a drag did not scroll the script (" + before + " -> "
                + v.scrollOffset() + ")", v.scrollOffset() > before + 1f);
    }

    @Test
    public void draggingBackReturnsToTheTop() {
        Activity a = launch();
        TeleprompterView v = new TeleprompterView(a);
        int w = 900, h = 600;
        v.measure(
                View.MeasureSpec.makeMeasureSpec(w, View.MeasureSpec.EXACTLY),
                View.MeasureSpec.makeMeasureSpec(h, View.MeasureSpec.EXACTLY));
        v.layout(0, 0, w, h);
        v.setScript(manyWords(400));

        v.scrollBy(150f);
        assertTrue("could not scroll down before dragging back",
                v.scrollOffset() > 100f);
        v.onTouchEvent(motion(MotionEvent.ACTION_DOWN, 450f, 150f));
        for (float y = 450f; y <= 550f; y += 20f) {
            v.onTouchEvent(motion(MotionEvent.ACTION_MOVE, 450f, y));
        }
        v.onTouchEvent(motion(MotionEvent.ACTION_UP, 450f, 550f));
        assertEquals("dragging back did not return to the top",
                0f, v.scrollOffset(), 0.5f);
    }

    /**
     * The prompter must have real height on the actual studio screen. It once
     * collapsed to 0px because the fixed content below overran the layout, so
     * nothing was drawn and nothing could scroll.
     */
    @Test
    public void prompterHasUsableHeightOnTheRealScreen() throws Exception {
        // Pre-seed a session so the studio opens directly: the name dialog
        // otherwise stays up and the activity behind it never lays out fully.
        // Also seed a long script so there is somewhere to scroll to.
        android.content.Context ctx =
                InstrumentationRegistry.getInstrumentation().getTargetContext();
        RecordingEngine engine = RecordingEngine.get();
        engine.abortAndDelete();
        engine.startNewSession(ctx, "Instrumentation", 2);
        ctx.getSharedPreferences("takeone", android.content.Context.MODE_PRIVATE)
                .edit().putString("tele_script", manyWords(400)).apply();
        TeleSettings.invalidateCache();
        try {
            Activity a = launch();
            View fab = a.findViewById(R.id.fabWrap);
            if (fab != null) {
                a.runOnUiThread(fab::performClick);
                InstrumentationRegistry.getInstrumentation().waitForIdleSync();
            }
            final TeleprompterView tele =
                    (TeleprompterView) a.findViewById(R.id.teleView);
            assertTrue("prompter not found", tele != null);
            InstrumentationRegistry.getInstrumentation().waitForIdleSync();
            android.os.SystemClock.sleep(300);

            // The regression was a prompter with no height at all: nothing
            // drawn, and maxScroll stuck at 0 so it could never scroll.
            assertTrue("prompter collapsed to " + tele.getHeight() + "px; "
                            + describe(tele), tele.getHeight() > 0);
        assertTrue("prompter cannot scroll (max=" + tele.maxScroll() + ")",
                tele.maxScroll() > 0f);
        // It must actually show lines, not a single sliver.
        int lines = tele.visibleLineCount();
        assertTrue("only " + lines + " line(s) fit at "
                + tele.getHeight() + "px", lines >= 3);
        // And it must win a real share of its panel, rather than being left
        // with only what the header and controls did not need.
        android.view.View panel = (android.view.View) tele.getParent();
        assertTrue("prompter is " + tele.getHeight() + "px of a "
                + panel.getHeight() + "px panel",
                tele.getHeight() * 3 >= panel.getHeight());
        } finally {
            engine.abortAndDelete();
            ctx.getSharedPreferences("takeone",
                    android.content.Context.MODE_PRIVATE).edit()
                    .remove("tele_script").remove("tele_auto").commit();
            TeleSettings.invalidateCache();
        }
    }

    /**
     * The reading centre must sit in the middle of the *visible* area: the
     * control chrome overlays the top of the panel, so the view shifts its
     * centre down by half the chrome height.
     */
    @Test
    public void readingCentreAccountsForOverlaidChrome() throws Exception {
        android.content.Context ctx =
                InstrumentationRegistry.getInstrumentation().getTargetContext();
        RecordingEngine engine = RecordingEngine.get();
        engine.abortAndDelete();
        engine.startNewSession(ctx, "Instrumentation", 2);
        try {
            Activity a = launch();
            View fab = a.findViewById(R.id.fabWrap);
            if (fab != null) {
                a.runOnUiThread(fab::performClick);
                InstrumentationRegistry.getInstrumentation().waitForIdleSync();
            }
            final TeleprompterView tele =
                    (TeleprompterView) a.findViewById(R.id.teleView);
            assertTrue("prompter not found", tele != null);
            final View chrome = a.findViewById(R.id.teleChrome);
            assertTrue("chrome overlay missing", chrome != null);
            InstrumentationRegistry.getInstrumentation().waitForIdleSync();
            android.os.SystemClock.sleep(300);

            java.lang.reflect.Field f = TeleprompterView.class
                    .getDeclaredField("centerShiftPx");
            f.setAccessible(true);
            float shift = (Float) f.get(tele);
            float expect = chrome.getHeight() / 2f;
            assertEquals("reading centre does not account for the chrome",
                    expect, shift, 2f);
            assertTrue("chrome has no height to account for",
                    chrome.getHeight() > 0);
        } finally {
            engine.abortAndDelete();
        }
    }

    /** Walks up the tree so a collapsed ancestor is obvious. */
    static String describe(android.view.View v0) {
        StringBuilder sb = new StringBuilder("chain: ");
        android.view.View cur = v0;
        int guard = 0;
        while (cur != null && guard++ < 7) {
            sb.append(cur.getClass().getSimpleName()).append("[")
              .append(cur.getWidth()).append("x").append(cur.getHeight())
              .append("] < ");
            if (cur.getParent() instanceof android.view.View) {
                cur = (android.view.View) cur.getParent();
            } else {
                break;
            }
        }
        return sb.toString();
    }

    private MotionEvent motion(int action, float x, float y) {
        long t = android.os.SystemClock.uptimeMillis();
        return MotionEvent.obtain(t, t, action, x, y, 0);
    }

    /**
     * The inline stepper must respond to a horizontal drag even though its
     * children are clickable and consume the initial touch.
     */
    @Test
    public void inlineStepperScrubsOnHorizontalDrag() {
        Activity a = launch();
        TeleValue tv = new TeleValue(a);
        tv.configure(10, 100, 1, 50, "");
        final int[] live = {-1};
        final int[] finished = {-1};
        final int[] discrete = {-1};
        tv.setOnScrubListener(new TeleValue.OnScrubListener() {
            @Override public void onScrubValueChanged(int v) {
                live[0] = v;
            }

            @Override public void onScrubFinished(int v) {
                finished[0] = v;
            }
        });
        tv.setOnValueChanged(v -> discrete[0] = v);

        int w = 200, h = 40;
        tv.measure(
                View.MeasureSpec.makeMeasureSpec(w, View.MeasureSpec.EXACTLY),
                View.MeasureSpec.makeMeasureSpec(h, View.MeasureSpec.EXACTLY));
        tv.layout(0, 0, w, h);

        long t = android.os.SystemClock.uptimeMillis();
        tv.dispatchTouchEvent(motion(MotionEvent.ACTION_DOWN, 100f, 20f));
        for (float x = 104f; x <= 160f; x += 6f) {
            tv.dispatchTouchEvent(motion(MotionEvent.ACTION_MOVE, x, 21f));
        }
        assertTrue("horizontal drag did not change the value live (still "
                + tv.getValue() + ")", live[0] > 50);
        tv.dispatchTouchEvent(motion(MotionEvent.ACTION_UP, 160f, 21f));

        assertEquals("scrub did not report its final value",
                tv.getValue(), finished[0]);
        assertEquals("a scrub must not also fire the discrete tap listener",
                -1, discrete[0]);
    }

    @Test
    public void inlineStepperIgnoresVerticalDrag() {
        Activity a = launch();
        TeleValue tv = new TeleValue(a);
        tv.configure(10, 100, 1, 50, "");
        tv.measure(
                View.MeasureSpec.makeMeasureSpec(200, View.MeasureSpec.EXACTLY),
                View.MeasureSpec.makeMeasureSpec(40, View.MeasureSpec.EXACTLY));
        tv.layout(0, 0, 200, 40);

        tv.dispatchTouchEvent(motion(MotionEvent.ACTION_DOWN, 100f, 10f));
        for (float y = 12f; y <= 38f; y += 6f) {
            tv.dispatchTouchEvent(motion(MotionEvent.ACTION_MOVE, 101f, y));
        }
        tv.dispatchTouchEvent(motion(MotionEvent.ACTION_CANCEL, 101f, 38f));
        assertEquals("a vertical drag must not change the value",
                50, tv.getValue());
    }
}