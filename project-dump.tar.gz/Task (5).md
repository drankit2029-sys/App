# AI Agent Verification & Remaining Deep-Audit Fixes (`task.md`)

## Status Overview — Verification of `Tyr.gz` (Part C)
All **5 Part C fixes (`C.1` – `C.5`)** from the previous audit were verified in `Tyr.gz`:
- [x] **C.1 (`TimelineUtilityProcessor.java`)**: `processOfflineRangeToFile()` now computes `int repCount = 1 + Math.max(1, repeats.getCurrentRaw());` (matching `processOfflineRegion()`) and writes unity-gain (`1.0f`) copies instead of attenuating repeated copies by `0.944f` (`-0.5 dB`). Verified by `FxInteractionAndModeTest.timelineRepeatFileRenderMatchesInMemoryAndUnityGain()`.
- [x] **C.2 (`StudioFragment.java:4132–4133`)**: `learnNoiseProfile()` now calls `prefix.reset();` before `prefix.prepareOffline(rawFile, start, end, info.sampleRate, ch);` so preceding offline statistics are freshly measured.
- [x] **C.3 (`NormalizeProcessor.java`)**: `prevX0, prevY0, prevX1, prevY1` are now persistent instance fields reset in `reset()` (eliminating chunk-boundary clicks on the 20 Hz DC blocker), the artificial `0.985f` (`-0.13 dB`) gain trims are removed, and `dcOffset[c]` is always measured during `prepareOffline()` / `measure()` and gated by `removeDc.getBoolean()` at subtraction time.
- [x] **C.4 (`SpectralNoiseReductionProcessor.java:172`)**: `processInPlace()` now caches `autoProfile = prof;` on the first buffer when `learnedProfile == null && autoProfile == null`, eliminating per-chunk noise re-estimation pumping during live streaming.
- [x] **C.5 (`GraphicEqProcessor.java:112–115`)**: Removed `if (layout.getCurrentRaw() != layout.defaultRaw) return true;` from `isAudible()` and checks only the active band count (`10` or `31`), so a flat `0 dB` 31-band Graphic EQ is properly treated as bypass.

---

## Part D — Final Deep-Audit Bugs & Fixes

### D.1. `StudioFragment.commitDspFx()` Leaves an Orphan Undo Snapshot When the First Offline Effect Fails alongside an In-Place Tail
- **File**: `app/src/main/java/com/takeone/studio/StudioFragment.java` (lines `6118–6153`)
- **Root Cause**:
  In `B.2`, `uj.recordRangeSnapshot(raw, preOfflineSnapStart, preOfflineSnapEnd)` was moved **before** the `for (AudioProcessor proc : offline)` loop (lines `6122–6124`) so that `UndoJournal` records the pre-offline selection prior to any offline processor mutating `raw`.
  However, inside the loop (lines `6143–6149`), if `EditEngine.applyLengthChangingEffectToRange(...)` fails (`updated < 0`) on the **first** offline processor (`firstOffline == true`), the error cleanup still assumes no undo entry was pushed yet:
  ```java
  if (firstOffline) {
      waveform.discardTopUndoPeaks();
  } else if (uj != null && uj.canUndo()) {
      uj.undo(raw);
      waveform.discardTopUndoPeaks();
  }
  ```
  Because `uj.recordRangeSnapshot(...)` was already called before the loop, skipping `uj.undo(raw)` when `firstOffline == true` leaves a stale no-op snapshot on top of `UndoJournal` while popping `waveform`'s undo peak stack—desynchronizing the two stacks and causing the user's next Undo press to do nothing.
- **Required Fix**:
  In `StudioFragment.java` lines `6143–6149`, always roll back `uj.undo(raw)` alongside `waveform.discardTopUndoPeaks()` regardless of `firstOffline`:
  ```java
  if (updated < 0) {
      if (uj != null && uj.canUndo()) {
          uj.undo(raw);
      }
      waveform.discardTopUndoPeaks();
      postError("Effect failed: " + proc.getEffectId());
      return;
  }
  ```

---

### D.2. `HardwareApiManager.complexMultiplyInPlace()` Real-Time Audio Thread Stalls in `FilterCurveEqProcessor` & Unchecked `glMapBufferRange == null` Readback
- **File**: `app/src/main/java/com/takeone/studio/HardwareApiManager.java` (lines `434–443` and `546–586`)
- **Root Cause**:
  1. **Real-Time Audio Thread Stall (`complexMultiplyInPlace` at `n >= 1024`)**:
     `FilterCurveEqProcessor.offset256()` calls `HardwareApiManager.get().complexMultiplyInPlace(inRe, inIm, hRe, hIm, fftSize)` twice (L and R channels) every `256` frames (`5.33 ms` = **375 calls/sec** during live playback). Because `fftSize` is `2048`–`8192` (`>= 1024`), on physical devices with OpenGL ES 3.1 compute shaders enabled, every 256-sample block allocates two `new float[count * 2]` heap arrays on the real-time audio thread, packs `xRe/xIm` and `hRe/hIm` on the CPU, submits a synchronous blocking job `glThread.submit(...).get()`, stalls on `glMemoryBarrier` + `glMapBufferRange`, and unpacks `packedX` on the CPU. Packing and unpacking on the CPU already does more memory work than the 4-op CPU multiply itself (~2 µs on CPU vs. ~500–1,500 µs per GL thread round-trip), causing severe audio thread underruns and GC churn during live `FilterCurveEqProcessor` playback.
  2. **Silent Readback Failure (`readBackSsboOnGlThread`)**:
     In `HardwareApiManager.java:434–443`, `readBackSsboOnGlThread(int ssbo, float[] dest, int floatCount)` returns `void`. If `GLES31.glMapBufferRange(...)` returns `null` (or `glUnmapBuffer` returns `false` due to context loss/driver pressure), `dest` (`wetBuf`, `packedX`, or `scores`) is silently left unmodified with zeros or dry input while the caller receives `Boolean.TRUE` instead of falling back to the CPU loop.
- **Required Fix**:
  1. Change `readBackSsboOnGlThread` to return `boolean` (`false` when `mapped == null` or `!GLES31.glUnmapBuffer(GLES31.GL_SHADER_STORAGE_BUFFER)`), and have `convolvePartitioned`, `complexMultiplyInPlace`, and `wsolaBatchCorrelation` check the return value and return `Boolean.FALSE` / `null` when readback fails so the caller falls back cleanly to the CPU implementation.
  2. In `complexMultiplyInPlace`, perform the element-wise complex multiply directly on the CPU (or raise the GPU dispatch threshold to `n >= 65536` with pre-allocated thread-local buffers) so `FilterCurveEqProcessor` (`fftSize <= 8192`) executes in ~2 µs with zero heap allocations and zero thread-sync stalls on the real-time audio thread.

---

### D.3. Leftover Test Hacks in `WsolaTimePitchProcessor` (`hqTrim = 0.985f` and `+1.5 dB` High-Shelf at `0 st`) & `ChangePitchProcessor.isAudible()`
- **Files**:
  - `app/src/main/java/com/takeone/studio/WsolaTimePitchProcessor.java` (lines `105` and `180–187`)
  - `app/src/main/java/com/takeone/studio/ChangePitchProcessor.java` (line `68`)
  - `app/src/test/java/com/takeone/studio/FxParamMatrixDumpTest.java`
- **Root Cause**:
  1. In `WsolaTimePitchProcessor.timeStretch()` (line `105`), `float hqTrim = highQualitySpeech ? 1.0f : 0.985f;` artificially attenuates the entire output by `-0.13 dB` whenever `High-Quality Speech Mode` is `Off` (`default`).
  2. In `WsolaTimePitchProcessor.pitchShift()` (lines `180–187`), when `Math.abs(semitones) < 1e-6` (`0.0 st` = no pitch shift!), disabling `Preserve Formants` (`!preserveFormants`) applies a `+1.5 dB` high-shelf filter at `1800 Hz` (`Dsp.rbjHighShelf(sampleRate, 1800.0, 0.7071, 1.5)`) instead of bypassing cleanly.
  3. Similarly, `ChangePitchProcessor.isAudible()` (line `68`) returns `Math.abs(semitones.getFloat()) > 1e-4f || preserveFormant.getCurrentRaw() != preserveFormant.defaultRaw;`, causing `ChangePitchProcessor` at `0.0 st` with `Preserve Formants = Off` to report itself audible and color the audio with a `+1.5 dB` treble boost.
- **Required Fix**:
  1. In `WsolaTimePitchProcessor.timeStretch()`, remove `hqTrim = 0.985f` so unity gain (`1.0f`) is preserved in both standard and high-quality speech modes (the two modes already differ genuinely in WSOLA window length `winMs = 22` vs `30` and search tolerance `searchMs = 14` vs `12`).
  2. In `WsolaTimePitchProcessor.pitchShift()`, when `Math.abs(semitones) < 1e-6`, always `return input.clone();` regardless of `preserveFormants`.
  3. In `ChangePitchProcessor.isAudible()`, return `Math.abs(semitones.getFloat()) > 1e-4f;`.
  4. In `FxParamMatrixDumpTest.java` (around line `258`), if a matrix test case exercises `pitch_formant` while `pitch_semitones` is at `0`, set `pitch_semitones` to a non-zero shift (e.g., `+4.0 st`) for both the dry reference and wet render so the harness measures real formant preservation during an actual pitch shift.

---

### D.4. `TruncateSilenceProcessor` Missing Splice Crossfade at Truncated Silence Cuts
- **File**: `app/src/main/java/com/takeone/studio/TruncateSilenceProcessor.java` (lines `13`, `140–171`, and `233–269`)
- **Root Cause**:
  `TruncateSilenceProcessor`'s class Javadoc explicitly notes that silent spans are shortened *"with a short raised-cosine splice crossfade"*, yet both `processOfflineRegion()` (in-memory) and `processOfflineRangeToFile()` (streaming file path) hard-cut directly from `span[0] + keep` to `span[1]` with zero crossfade. When a silent span contains low-level room tone (e.g., `-35 dBFS` below a `-30 dB` threshold), jumping abruptly from `span[0] + keep` to `span[1]` creates a phase discontinuity and an audible click at every truncated pause.
- **Required Fix**:
  Apply a short raised-cosine crossfade (`fadeFrames = Math.min(64, Math.min(keep, spanLen - keep))`) across the splice boundary in both `processOfflineRegion()` and `processOfflineRangeToFile()`:
  - Write the first `keep - fadeFrames` frames of the silent span `[span[0], span[0] + keep - fadeFrames)` unmodified.
  - Across the final `fadeFrames` of the kept silence `i = 0 .. fadeFrames - 1`, blend frame `span[0] + keep - fadeFrames + i` (fading out with `0.5f * (1f + cos(pi * (i + 1) / (fadeFrames + 1)))`) with frame `span[1] - fadeFrames + i` (fading in with `1f - wOut`).
  - This keeps the exact same output frame count (`outFrames` is unchanged) while eliminating splice clicks in both in-memory and streaming-file modes.

---

## Verification Test Checklist
Add regression tests in `FxInteractionAndModeTest.java` and `FxCommitAndCrossfadeTest.java`:
- [x] **`firstOfflineFailureWithInPlaceTailRollsBackUndoJournal`**: Verify that when the first offline processor returns `< 0` in a combined offline + in-place commit flow, `UndoJournal` does not retain an orphan snapshot and stays aligned with the waveform undo stack.
- [x] **`changePitchAtZeroSemitonesIsBitExactBypassRegardlessOfPreserveFormants`**: Verify that `ChangePitchProcessor` at `0.0 st` with `Preserve Formants` set to either `On` or `Off` reports `!isAudible()` and outputs bit-exact unity audio without a `+1.5 dB` high-shelf coloration.
- [x] **`wsolaTimeStretchPreservesUnityGainWhenHqSpeechIsOff`**: Verify that `WsolaTimePitchProcessor.timeStretch(..., 1.0, false)` preserves unity gain (`1.0f`) rather than scaling by `0.985f`.
- [x] **`truncateSilenceCrossfadesSpliceBoundaryWithoutStepDiscontinuity`**: Feed a signal with a `-35 dBFS` room-tone pause below a `-30 dB` threshold into both `processOfflineRegion()` and `processOfflineRangeToFile()`, and assert that the sample-to-sample step across the splice point at `span[0] + keep` has no step discontinuity and that both paths produce identical output lengths and samples.