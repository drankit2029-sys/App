# Command Code import report

/import is a best-effort migration: items that could not be imported were
skipped and are listed below with reasons so you can move them manually.
Nothing in your original setup was modified.

Totals: 0 imported, 22 already present, 0 not supported, 0 failed.

## Claude Code

- [Already present (kept yours)] skill embedded-captions
  - from: /root/.claude/skills/embedded-captions
  - to: /root/.commandcode/skills/embedded-captions
- [Already present (kept yours)] skill faceless-explainer
  - from: /root/.claude/skills/faceless-explainer
  - to: /root/.commandcode/skills/faceless-explainer
- [Already present (kept yours)] skill figma
  - from: /root/.claude/skills/figma
  - to: /root/.commandcode/skills/figma
- [Already present (kept yours)] skill general-video
  - from: /root/.claude/skills/general-video
  - to: /root/.commandcode/skills/general-video
- [Already present (kept yours)] skill hyperframes
  - from: /root/.claude/skills/hyperframes
  - to: /root/.commandcode/skills/hyperframes
- [Already present (kept yours)] skill hyperframes-animation
  - from: /root/.claude/skills/hyperframes-animation
  - to: /root/.commandcode/skills/hyperframes-animation
- [Already present (kept yours)] skill hyperframes-audio
  - from: /root/.claude/skills/hyperframes-audio
  - to: /root/.commandcode/skills/hyperframes-audio
- [Already present (kept yours)] skill hyperframes-cli
  - from: /root/.claude/skills/hyperframes-cli
  - to: /root/.commandcode/skills/hyperframes-cli
- [Already present (kept yours)] skill hyperframes-core
  - from: /root/.claude/skills/hyperframes-core
  - to: /root/.commandcode/skills/hyperframes-core
- [Already present (kept yours)] skill hyperframes-creative
  - from: /root/.claude/skills/hyperframes-creative
  - to: /root/.commandcode/skills/hyperframes-creative
- [Already present (kept yours)] skill hyperframes-keyframes
  - from: /root/.claude/skills/hyperframes-keyframes
  - to: /root/.commandcode/skills/hyperframes-keyframes
- [Already present (kept yours)] skill hyperframes-registry
  - from: /root/.claude/skills/hyperframes-registry
  - to: /root/.commandcode/skills/hyperframes-registry
- [Already present (kept yours)] skill hyperframes-studio
  - from: /root/.claude/skills/hyperframes-studio
  - to: /root/.commandcode/skills/hyperframes-studio
- [Already present (kept yours)] skill media-use
  - from: /root/.claude/skills/media-use
  - to: /root/.commandcode/skills/media-use
- [Already present (kept yours)] skill motion-graphics
  - from: /root/.claude/skills/motion-graphics
  - to: /root/.commandcode/skills/motion-graphics
- [Already present (kept yours)] skill music-to-video
  - from: /root/.claude/skills/music-to-video
  - to: /root/.commandcode/skills/music-to-video
- [Already present (kept yours)] skill pr-to-video
  - from: /root/.claude/skills/pr-to-video
  - to: /root/.commandcode/skills/pr-to-video
- [Already present (kept yours)] skill product-launch-video
  - from: /root/.claude/skills/product-launch-video
  - to: /root/.commandcode/skills/product-launch-video
- [Already present (kept yours)] skill remotion-to-hyperframes
  - from: /root/.claude/skills/remotion-to-hyperframes
  - to: /root/.commandcode/skills/remotion-to-hyperframes
- [Already present (kept yours)] skill slideshow
  - from: /root/.claude/skills/slideshow
  - to: /root/.commandcode/skills/slideshow
- [Already present (kept yours)] skill talking-head-recut
  - from: /root/.claude/skills/talking-head-recut
  - to: /root/.commandcode/skills/talking-head-recut

## OpenCode

- [Already present (kept yours)] skill web-browsing
  - from: /root/.config/opencode/skills/web-browsing
  - to: /root/.commandcode/skills/web-browsing
