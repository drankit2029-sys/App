# Taste

- For verification/testing runs in this project, each test must change a single parameter of a single effect at a time, driven from the expanded effect pill inside the FX panel itself — do not sweep multiple parameters in one run, and do not drive changes from the dedicated effect modal. Confidence: 0.9
- Verification must be evidence-based end to end: confirm the waveform actually changed while a parameter was changed, then apply the effect, download the applied audio, and verify programmatically in Python that the effect was really applied to the audio — UI video/screenshot evidence alone is not sufficient. Confidence: 0.9
- Large test matrices should be parallelised as much as possible on GitHub Actions runners (user confirmed ~40 concurrent jobs are available). Confidence: 0.8
- When choosing between a cheaper sharded device tier and maximum coverage, prefer maximum coverage/parallelism (e.g. one emulator shard per effect) over cutting Actions minutes. Confidence: 0.7
