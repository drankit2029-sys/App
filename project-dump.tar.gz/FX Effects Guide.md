# TakeOne FX Rack — What Each Effect Does & How to Check Every Parameter

This guide documents every effect in the Studio FX rack: what each effect does,
what every control changes, and a concrete way to verify that control with your
ears (and, where useful, with a measurement). It is written for manual testing on
a phone with headphones, but every effect also has an automated parameter matrix
(see §4) if you want numbers instead of opinions.

Notation: **Range (default)** — e.g. `20–20000 Hz (1000)` means the control
spans 20 Hz to 20 kHz and starts at 1000 Hz. `[A | B] (A)` is an enum and the
default is the first entry.

---

## 1. How the FX rack works

1. Open a take in Studio and tap **DSP FX** (the editor strip button). The rack
   replaces the Teleprompter panel.
2. Tap **+ Add Effect** and pick an effect from the searchable list. Effects are
   grouped by category: EQ & Filters, Dynamics & Mastering, Noise Removal &
   Restoration, Delay/Reverb & Spatial, Pitch/Speed & Time, Distortion/Modulation
   & Creative, Fades & Timeline Tools, Generators & Analyzers.
3. Each rack slot has:
   - a header with the effect name and `Enabled` or `Bypassed`,
   - a **Bypass/Enable** chip (the A/B switch),
   - the primary control as a dial (the one you will reach for most),
   - the remaining controls in the slot body; on curve-based effects (parametric
     EQ, graphic EQ, filter curve) they live under **Show advanced controls (N)**,
   - **Learn from selection** for the two noise-reduction effects.
4. Drag slots to reorder. Order matters: effects run top to bottom, so a
   compressor before a limiter behaves differently from a limiter before a
   compressor.
5. **Apply** bakes the enabled slots into the selected region (or the whole take
   when nothing is selected) and exits the rack. **Done** leaves the rack.
   Bypassed slots are ignored when baking.
6. Values are stored per slot and survive closing/reopening the take.

> Tip: before testing any effect, set the take's gain so peaks sit around
> −6 dBFS. Many "the effect sounds broken" reports are actually clipping or a
> too-hot input.

---

## 2. Build a test bench

You need material that contains the thing the effect acts on. The fastest way
to get repeatable material is the **Audio Generator** effect (`generator`),
which writes into the selected region:

| Signal | Generator setup | Use it for |
|---|---|---|
| 1 kHz sine, −6 dBFS | Type: Tone & Chirp, Waveform: Sine/White, Start = End = 1000 Hz, 5 s | Levels, pan, distortion curves, modulation, limiter ceilings |
| 20 Hz → 20 kHz chirp | Type: Tone & Chirp, Start 20, End 20000, 10 s | EQ/filter response, notch, shelf, crossovers |
| Pink noise | Type: Noise, Waveform: Square/Pink | EQ balance, compressor behaviour, spectral effects |
| White noise | Type: Noise, Waveform: Sine/White | Noise reduction, de-hum, de-esser |
| Rhythm track | Type: Rhythm Track, Tempo 90–120 BPM | Delay timing, gate/expander, tremolo, reverse/repeat |
| Short clicks | Type: Rhythm Track (fast tempo) or hand claps | Click removal, repair, transient behaviour |
| DTMF | Type: DTMF | Spectral edit/notch checks, vocoder carriers |
| Speech | Record yourself: "Peter Piper picked…", long "sss", a plosive "P", a quiet pause | Restoration, de-esser, gate, compressor, warmth/presence, pitch/time |

Monitoring: use headphones, keep the phone volume moderate, and watch the
waveform and the peak level while you sweep a control. For stereo effects
(pan, width, phaser, tremolo phase, reverb width) listen on headphones — phone
speakers hide most of what those controls do.

---

## 3. The universal parameter check

For any control, in this order:

1. **Find neutral.** Note the default. If the effect has a bypass chip, toggle
   it: at default settings a well-behaved effect should be near-transparent
   (or intentionally subtle).
2. **Expose the dimension.** Pick a source that contains the thing the control
   governs — low frequencies for a low shelf, sibilance for a de-esser, pauses
   for a gate, a steady tone for modulation.
3. **Sweep min → max → default.** Change only that control, in sensible steps.
   Listen for the intended change first, then for side effects.
4. **Check the extremes.** Minimum/maximum are where bugs hide: silence,
   runaway gain, clicks/zipper noise, metallic artifacts, dropped tails,
   non-finite samples (the waveform collapsing or a hard digital crunch).
5. **Check interaction.** Move the effect before/after a compressor or
   limiter and confirm it still does what the label says.
6. **Save and reopen.** The value should come back and the render should match
   what you previewed.
7. **Trust the direction, not the number.** A control named "Threshold" should
   make the effect act *more* as you lower it (compressors/gates) or *less* as
   you raise it, depending on the design — the table below tells you which.

Parameter types behave differently in the UI:

- **Slider/dial** — continuous; drag slowly to hear zipper noise or stepping.
- **Enum chip** — discrete modes; each label should sound clearly different.
- **Toggle** — on/off; compare both states on the same source.
- **Action button** — runs once (e.g. *Learn from selection*); it must not
  change the audio by itself, only prepare the effect.

---

## 4. Automated checks (numbers, not ears)

The repository ships a per-effect parameter matrix. It renders every parameter
at minimum, default and maximum (every enum label, both boolean states) against
a probe that can actually show that parameter, and compares the result with the
dry reference. It also asserts physical anchors (limiter ceiling, gate closure,
hum removal, pitch/tempo ratios, reverse/invert identity).

```bash
# one effect, off-device (no emulator):
FX_EFFECT=reverb sh ./gradlew :app:testDebugUnitTest --tests '*FxParamMatrixDumpTest'
pip install numpy
python3 tools/fxverify/analyze.py --cases app/build/fxverify/reverb
```

In CI, each effect has its own `dsp-matrix (<effect-id>)` shard inside the
**FX Parameter Verification** workflow, and `tools/fxverify/check_drift.py`
fails the run if an effect exists in code but not in the matrix. The flag file
`app/build/fxverify/<id>/verdicts.json` lists, per parameter, whether it moved
the audio, by how much, and whether that movement matched the expected
direction.

Use this guide's tables to interpret those verdicts: the "What it does" column
is the expected direction, and the "How to check" column is what a human should
hear when the matrix says the parameter moved.

---

## 5. Effect reference

The sections below follow the rack categories. Every registered effect is
covered, including the role-scoped Warmth and Presence entries.

### EQ & FILTERS

---

#### 1. Low-Cut Filter Pro (`hpf`)

*Category: EQ & Filters.*

A clean Butterworth high-pass for removing rumble, handling noise, wind and
plosive thumps. It is the "set and forget" first stage of a vocal chain; the
24 dB/oct mode cascades two second-order sections so the cutoff is steeper
without a resonant peak. Coefficients glide so scrubbing the cutoff does not
click.

| Control | Range (default) | What it does | How to check |
|---|---|---|---|
| Cutoff | `40–160 Hz (80)` | Frequency below which content is attenuated. | Speak with "P"/"B" plosives and raise the cutoff toward 160 Hz: thumps and desk rumble disappear while the voice stays. At 40 Hz almost nothing changes. |
| Slope | `[12 dB/oct \| 24 dB/oct] (24)` | Steepness of the filter below the cutoff. | A/B the two slopes on the same rumble: 24 dB/oct removes noticeably more sub-bass. Check that 24 dB/oct does not add a boom at the corner (it should stay smooth). |

**Quick test:** record "Peter Piper picked a peck" close to the mic; cutoff 80,
slope 24 should remove the plosive thump without thinning the voice.

---

#### 2. High-Pass Filter (`highpass`)

*Category: EQ & Filters.*

A sweepable high-pass with six roll-off strengths (6–48 dB/oct). Where the
Low-Cut Pro is a vocal-chain tool with a narrow range, this is the general-purpose
high-pass: use it to remove everything below the useful band, or to isolate
highs for a check.

| Control | Range (default) | What it does | How to check |
|---|---|---|---|
| Cutoff | `20–20000 Hz (80)` | Corner below which content is attenuated. | Feed the 20 Hz → 20 kHz chirp and raise the cutoff: the sweep should vanish below the displayed frequency and pass above it. At 20 Hz it is effectively off. |
| Roll-Off | `[6 \| 12 \| 18 \| 24 \| 36 \| 48 dB/oct] (12)` | Filter steepness. | Compare 6 vs 48 dB/oct on the chirp: steeper slopes cut more just below the corner. Check high orders for ringing on a click/plosive. |

**Quick test:** chirp sweep with cutoff 1 kHz: only the upper part of the sweep
should remain; every step up the roll-off list should make the transition
sharper.

---

#### 3. Low-Pass Filter (`lowpass`)

*Category: EQ & Filters.*

The mirror of the high-pass: removes hiss, harshness and high-frequency noise
above the cutoff. Same six roll-off strengths.

| Control | Range (default) | What it does | How to check |
|---|---|---|---|
| Cutoff | `20–20000 Hz (12000)` | Corner above which content is attenuated. | With the chirp, lower the cutoff: the top of the sweep disappears. At 12 kHz you hear a duller, darker version of speech; at 2 kHz it sounds like a telephone. |
| Roll-Off | `[6 \| 12 \| 18 \| 24 \| 36 \| 48 dB/oct] (12)` | Filter steepness. | Compare 6 vs 48 dB/oct: 6 leaves audible "air" just above the corner; 48 removes it abruptly. Listen for a metallic ring at extreme slopes. |

**Quick test:** hiss recording → cutoff 6–8 kHz, roll-off 24: hiss drops, speech
stays intelligible; then push cutoff to 2 kHz and confirm the expected
telephone-band sound.

---

#### 4. Notch Filter (`notch`)

*Category: EQ & Filters.*

A surgical notch for removing a single frequency: mains hum (50/60 Hz) or a
ringing resonance. It is a very narrow RBJ notch — the point is to remove the
tone while leaving the voice around it untouched.

| Control | Range (default) | What it does | How to check |
|---|---|---|---|
| Quick Pick | `[Custom \| 50 Hz hum \| 60 Hz hum] (Custom)` | Presets that jump the frequency to a mains hum. | Record/import hum and switch between presets: each should null its named hum. `Custom` leaves your frequency alone. |
| Frequency | `20–20000 Hz (60)` | Center of the notch. | Sweep slowly around 50/60 Hz on a hum recording until the hum disappears. On the chirp, the sweep should have a narrow hole at this frequency. |
| Q | `0.1–30.0 (5.0)` | Notch width: high Q = narrow (surgical), low Q = wide (removes more around the center). | At Q 30 only the exact tone goes; at Q 0.5 a broad band disappears. Use high Q on a steady hum so the voice is untouched, and confirm no audible hole in speech. |

**Quick test:** 60 Hz hum take → Quick Pick "60 Hz hum" → hum vanishes, voice
unchanged; then lower Q to 1 and hear the voice get thinner (proof the width
control works).

---

#### 5. Shelf Filter (`shelf`)

*Category: EQ & Filters.*

A broad low or high shelf with an adjustable slope. Use it for overall tonal
balance: more body (low shelf) or more air/brightness (high shelf).

| Control | Range (default) | What it does | How to check |
|---|---|---|---|
| Shelf Type | `[Low Shelf \| High Shelf] (Low Shelf)` | Which end of the spectrum is shaped. | Low shelf 200 Hz +12 dB adds body to speech; high shelf 3 kHz +12 dB adds brightness. Switching type should move the effect to the other end. |
| Corner Freq | `20–20000 Hz (200)` | Where the shelf starts to act. | With pink noise, a low shelf at 80 Hz boosts only the bottom; at 1 kHz it boosts a large part of the voice. Hear the corner move. |
| Shelf Gain | `-24.0–24.0 dB (0.0)` | Amount of boost/cut. | ±24 dB should be obvious and symmetric; 0 dB must be transparent. Check that large boosts do not clip the output (watch peaks). |
| Slope S | `0.3–2.0 (0.7)` | Shape of the transition into the shelf: lower = gentler, higher = steeper. | On pink noise, compare 0.3 and 2.0: the shelf edge becomes more abrupt; check that 2.0 does not ring. |

**Quick test:** pink noise + high shelf at 4 kHz: raise gain from 0 to +18 dB and
back; sweep the corner from 1 to 12 kHz to hear the transition point move.

---

#### 6. 6-Band Parametric EQ (`eq6`)

*Category: EQ & Filters.*

A console-style EQ: low cut, four musical bands (band 2 can be a low shelf or
bell, band 5 a high shelf or bell), and a high cut. The slot shows a curve
canvas you can drag; numeric controls live under **Show advanced controls**.
The primary value on the rack is the EQ output trim.

| Control | Range (default) | What it does | How to check |
|---|---|---|---|
| Low-Cut Freq | `20–1000 Hz (80)` | High-pass corner at the bottom of the EQ. | At 20 Hz it is effectively off; raise to 120–200 Hz and hear rumble/thump disappear. Confirm the voice does not get thin at 80 Hz. |
| Low-Cut Slope | `[12 dB/oct \| 24 dB/oct] (12)` | Steepness of the low cut. | Compare on a plosive: 24 dB/oct removes more sub-bass; check for a resonant boom at the corner. |
| Band 2 Type | `[Low Shelf \| Bell] (Low Shelf)` | Shape of band 2. | Shelf: broad low-end tilt; Bell: a focused boost/cut. Switch types and confirm the character changes (shelf affects everything below the frequency, bell only around it). |
| Band 2 Freq | `40–500 Hz (120)` | Corner/center of band 2. | On pink noise, sweep 40→500 Hz: the boosted region moves from sub-bass to chest voice. |
| Band 2 Gain | `-18.0–18.0 dB (0.0)` | Boost/cut of band 2. | +12 dB adds chest/body, −12 dB removes boom. 0 dB must be flat. |
| Band 2 Q | `0.3–10.0 (0.7)` | Band 2 width (bell) / shelf transition (shelf). | In Bell mode, Q 10 is a narrow peak; Q 0.3 is broad. In shelf mode it sets how quickly the shelf transitions. |
| Band 3 Freq | `150–2500 Hz (500)` | Center of the low-mid bell. | Sweep while boosting +12 dB: 150 Hz = mud, 500 Hz = boxiness, 2 kHz = honk. |
| Band 3 Gain | `-18.0–18.0 dB (0.0)` | Boost/cut of band 3. | The classic "mud cut" is 300–500 Hz at −3…−6 dB; confirm it clears the voice. |
| Band 3 Q | `0.3–10.0 (1.0)` | Width of band 3. | Narrow Q cuts only the boxy tone; wide Q changes the whole low-mid balance. |
| Band 4 Freq | `600–8000 Hz (2500)` | Center of the presence bell. | Boost +9 dB around 2.5–3 kHz to hear consonants jump forward; 6 kHz is sibilance. |
| Band 4 Gain | `-18.0–18.0 dB (0.0)` | Boost/cut of band 4. | +9 dB should make speech cut through; −9 dB should soften it. Watch for harshness. |
| Band 4 Q | `0.3–10.0 (1.0)` | Width of band 4. | High Q = surgical de-ess-like notch; low Q = broad presence tilt. |
| Band 5 Type | `[High Shelf \| Bell] (High Shelf)` | Shape of band 5. | Shelf = air/brightness; Bell = focused peak. Switch and hear the difference on a "sss". |
| Band 5 Freq | `2000–18000 Hz (8000)` | Corner/center of band 5. | On pink noise, sweep 2→18 kHz: the boost moves from presence to air. |
| Band 5 Gain | `-18.0–18.0 dB (0.0)` | Boost/cut of band 5. | +6 dB adds air; −6 dB tames hiss. Check that +18 dB does not become painful (it should still be controlled). |
| Band 5 Q | `0.3–10.0 (0.7)` | Width (bell) / transition (shelf) of band 5. | Compare narrow vs wide on a cymbal/noise source. |
| High-Cut Freq | `2000–20000 Hz (20000)` | Low-pass corner at the top. | At 20 kHz it is effectively off; lower to 8–10 kHz and hear the top end go. |
| High-Cut Slope | `[12 dB/oct \| 24 dB/oct] (12)` | Steepness of the high cut. | 24 dB/oct removes more air; check for a "swishy" transition. |
| Output Gain | `-18.0–18.0 dB (0.0)` | Final trim for the EQ. | Boost a band and use output to compensate: the voice should get louder without changing tone. 0 dB must be unity. |

**Quick test:** chirp + pink noise; drag each band on the curve while it plays.
Every band should create a local bump/dip at its frequency, Q should change the
bump's width, and switching band 2/5 between shelf and bell should change a
local peak into a broad tilt.

---

#### 7. Graphic EQ (`geq`)

*Category: EQ & Filters.*

A constant-Q graphic EQ: 10 ISO octave bands (31.5 Hz–16 kHz) or 31 one-third-octave
bands (20 Hz–20 kHz), ±18 dB each, plus output trim. Use it for quick broad
shaping or for removing a specific octave.

| Control | Range (default) | What it does | How to check |
|---|---|---|---|
| Layout | `[10 bands (ISO) \| 31 bands (1/3 oct)] (10 bands)` | Switches between octave and third-octave band sets. | Switch layouts on pink noise: 10 bands = broad strokes; 31 bands = surgical. The band controls should change to match. |
| Output Gain | `-18.0–18.0 dB (0.0)` | Final trim. | Boost one band +12 dB and pull output down: tone changes, level returns. 0 dB must be unity. |
| Band 1…N | `-18.0–18.0 dB (0.0)` each | Boost/cut for that band. | On pink noise, boost 1 kHz +12 dB: only that octave (or third) jumps. Cut 250 Hz: boxiness drops. Check that adjacent bands overlap smoothly and that 0 dB is flat. |

**Quick test:** pink noise → boost 500 Hz and 2 kHz alternately; each should
produce a clearly different "honk" and "presence" colour without affecting the
rest of the spectrum.

---

#### 8. Filter Curve EQ (`fcurve`)

*Category: EQ & Filters.*

A draw-your-own linear-phase EQ: up to 32 frequency/gain nodes define the
magnitude curve, and the audio runs through a 1024/2048/4096-tap FIR convolution.
Use it when you want a precise, phase-linear response (classical mastering-style
curves, matching a reference) rather than the character of an IIR EQ.

| Control | Range (default) | What it does | How to check |
|---|---|---|---|
| Output | `-18.0–18.0 dB (0.0)` | Final trim after the FIR. | With a neutral curve, changing output should only change level, not tone. |
| Points | `2–32 (8)` | Number of active nodes. | Raise from 2 to 32: you get more nodes to shape with. Dropping the count must remove the extra nodes without glitches. |
| Precision | `[1024 \| 2048 \| 4096 taps] (2048)` | FIR length: more taps = sharper low-frequency resolution, more latency. | A narrow 40 Hz cut is soft at 1024 and clean at 4096. Confirm the latency changes (the preview/commit alignment handles it) and that the tone matches at all three. |
| F1…Fn | `20–20000 Hz` (defaults span 40 Hz–16 kHz) | Node frequencies (draggable on the curve). | Move one node across the spectrum while boosting it: the bump should follow the node exactly. |
| G1…Gn | `-24.0–24.0 dB (0.0)` | Node gains. | Set one node to +12 and another to −12: you should hear a broad shape, not a narrow spike. Check that a flat curve (all gains 0) is transparent. |

**Quick test:** draw a gentle "smile" (low +4 dB, mid −3 dB, high +3 dB) on pink
noise; compare 1024 vs 4096 taps — the shape should stay the same while the
low-frequency precision improves.

---

#### 9. Bass & Treble (`basstreble`)

*Category: EQ & Filters.*

The classic two-knob tone stack: a 250 Hz low shelf and a 3.5 kHz high shelf,
plus output volume and a link switch. It is the fastest way to tilt a take.

| Control | Range (default) | What it does | How to check |
|---|---|---|---|
| Bass (250 Hz) | `-30.0–30.0 dB (0.0)` | Low-shelf boost/cut. | +12 dB adds weight, −12 dB thins the bottom. On speech, 250 Hz is chest/body; confirm it does not become muddy at +30. |
| Treble (3.5 kHz) | `-30.0–30.0 dB (0.0)` | High-shelf boost/cut. | +12 dB adds articulation/air, −12 dB makes it dull. Check that +30 dB does not turn into harsh hiss. |
| Volume | `-18.0–18.0 dB (0.0)` | Output trim. | Compensate a big bass/treble boost and confirm the level returns without tone change. 0 dB = unity. |
| Link Bass & Treble | `off/on (off)` | Ties the two shelves together (adjusting one moves the other by the same amount). | Turn it on and move Bass: Treble should follow. Turn it off and confirm they move independently. |

**Quick test:** speech → Bass +9, Treble +6, Volume −4: fuller and brighter at
roughly the same loudness; then link the controls and confirm they track.

---

#### 10. Classic Filters (`classic`)

*Category: EQ & Filters.*

Analog-prototype IIR filters: Butterworth (maximally flat passband), Chebyshev I
(equiripple passband), Chebyshev II (equiripple stopband) and Bessel (flat group
delay), orders 1–10, low-pass or high-pass. This is the "textbook filter" effect
for checking filter behaviour or creating extreme band-limiting.

| Control | Range (default) | What it does | How to check |
|---|---|---|---|
| Prototype | `[Butterworth \| Chebyshev I \| Chebyshev II \| Bessel] (Butterworth)` | Filter family. | On a chirp: Butterworth is smooth, Chebyshev I ripples in the passband, Chebyshev II ripples just before the stopband, Bessel keeps transients cleanest. Each must sound different. |
| Passband | `[Low-Pass \| High-Pass] (Low-Pass)` | Direction of the filter. | Flip it: the same cutoff should swap from keeping lows to keeping highs. |
| Order | `1–10 (4)` | Filter steepness (number of poles). | Order 1 is very gentle; order 10 is almost a brick wall. On a chirp, each step should make the transition sharper. Check high orders for ringing on clicks. |
| Cutoff | `20–20000 Hz (1000)` | Corner frequency. | Sweep it on the chirp: the transition follows the displayed frequency. |
| Ripple | `0.1–6.0 dB (1.0)` | Passband (Chebyshev I) or stopband (Chebyshev II) ripple; ignored by Butterworth/Bessel. | In Chebyshev I, raise ripple and listen for a wavy passband on pink noise; in Chebyshev II the ripple appears near the stopband. Butterworth/Bessel should not change. |

**Quick test:** chirp → Butterworth LP 1 kHz order 4 is smooth; switch to
Chebyshev I and raise ripple to 6 dB to hear the passband ripple; switch to
Bessel and confirm the transient (click) stays cleaner.

---

#### 11. Warmth & Vocal Presence (`tone`) — also `warmth` and `presence`

*Category: EQ & Filters.*

Two musical shelves in one processor: a low shelf around 180 Hz for chest/body
("warmth") and a high shelf around 3.5 kHz for articulation and air
("presence"). The rack can host them as one combined effect
(`Warmth & Vocal Presence`), or as role-scoped effects that expose only their
own two controls (`Warmth & Chest Body`, `Vocal Presence & Air`). When both
slots are separated by another effect in the rack, the engine splits the tone
stage around that effect so the order is honoured.

| Control | Range (default) | What it does | How to check |
|---|---|---|---|
| Warmth | `0–100% (tone 40, warmth 40, presence n/a)` | Amount of low-shelf boost around the warmth corner. | On a male voice, 30–50% adds body; 100% should be obviously full/boomy. At 0% the low shelf must be transparent. |
| Warmth Corner | `80–350 Hz (180)` | Where the low shelf starts. | Lower (80–120 Hz) = sub/chest weight; higher (250–350 Hz) = boxy low-mid. Sweep it on speech and hear the weight move. |
| Presence | `0–100% (tone 45, presence 45, warmth n/a)` | Amount of high-shelf boost around the presence corner. | 30–60% makes consonants clearer; 100% can be harsh. At 0% it must be transparent. |
| Presence Corner | `1500–6500 Hz (3500)` | Where the high shelf starts. | 1.5–2.5 kHz = forward/nasal; 4–6.5 kHz = air/sibilance. Sweep it on a "sss" and confirm the brightness moves. |

**Quick test:** speech → Warmth 50%, corner 150 Hz (fuller); Presence 40%, corner
4 kHz (clearer). Then add a Compressor between them in the rack and confirm the
warmth/presence order still matches the slot order (this is the split-tone
path).

### DYNAMICS & MASTERING

---

#### 12. Amplify (`amplify`)

*Category: Dynamics & Mastering.*

Two-pass gain: the processor scans the selection's peak, applies the requested
gain, and (unless you allow clipping) limits the result so the peak does not
exceed the **New Peak Amplitude** target. With **Amplification** at 0 it acts as
a peak normalizer; with a non-zero value it is a plain gain stage that is still
capped to the target unless clipping is allowed.

| Control | Range (default) | What it does | How to check |
|---|---|---|---|
| Amplification | `-50.0–50.0 dB (0.0)` | Fixed gain applied to the selection. | Quiet take: +12 dB should be obviously louder. 0 dB must be unity. At −50 dB the take should almost disappear. |
| New Peak Amplitude | `-40.0–0.0 dB (0.0)` | Target peak. With Amplification at 0 this normalizes the take to this peak. | Set Amplification 0 and New Peak −6 dB on a quiet take: the waveform peak should land at −6. Set −1: louder, still below full scale. |
| Allow Clipping | `off/on (off)` | When off, samples are clamped below 0 dBFS; when on, gain is not capped by the target and can clip. | Hot take + positive gain: with clipping off the peaks flatten safely at the ceiling; turn it on and hear/see the hard clip. |

**Quick test:** quiet speech → Amplification 0, New Peak −6 (normalized); then
Amplification +12 with clipping off (peak capped) vs on (audible crunch).

---

#### 13. Normalize (`normalize`)

*Category: Dynamics & Mastering.*

DC-offset removal plus peak or RMS normalization, with linked or independent
stereo. Peak normalization makes the loudest sample hit the target; RMS
normalization raises the average level instead, which usually sounds louder but
leaves less headroom.

| Control | Range (default) | What it does | How to check |
|---|---|---|---|
| Remove DC Offset | `off/on (on)` | Centers the waveform by subtracting its average. | A take with visible vertical offset (waveform not centered) should re-center. On a clean take it must be inaudible. |
| Normalize Peak Amplitude | `off/on (on)` | Enables peak normalization. | Off = no peak normalization (only DC/RMS behaviour). On = the peak moves to the target. |
| Target Peak | `-60.0–0.0 dB (-1.0)` | Peak (or RMS) level to normalize to. | −1 dB is loud and safe; −6 dB leaves headroom; −40 dB is nearly silent. Check the waveform peak matches the label. |
| Normalize Stereo Channels Independently | `off/on (off)` | Off = one gain for both channels (keeps balance); on = each channel normalized on its own. | Take with a quiet left and loud right: off keeps the imbalance, on brings both channels to the same level. |
| Normalize to RMS instead of Peak | `off/on (off)` | Switches the target from peak to RMS. | On speech, RMS mode is louder for the same target and the peaks sit lower; check for clipping on transient-heavy material. |

**Quick test:** unbalanced stereo take → target −3 dB; toggle independent
normalization and watch one channel jump while the other stays.

---

#### 14. Loudness Normalization (`loudness`)

*Category: Dynamics & Mastering.*

EBU R128 / ITU-R BS.1770-4 loudness normalization with a true-peak ceiling:
it measures integrated LUFS over gated 400 ms blocks and applies one gain so
the program lands on the target, then clamps true peaks to the ceiling. Use it
to match takes to a platform target (−16 LUFS is a common streaming level,
−23 LUFS is broadcast).

| Control | Range (default) | What it does | How to check |
|---|---|---|---|
| Target Loudness | `-70.0–0.0 dB (-16.0)` | Integrated loudness target in LUFS. | Normalize a quiet take to −16: it should be clearly louder; −23 should be ~7 dB quieter than −16. Use an external LUFS meter to confirm. |
| True-Peak Ceiling | `-9.0–-0.1 dB (-1.0)` | Maximum true peak after normalization. | With a transient-heavy take, normalizing loud should pin peaks at the ceiling instead of clipping. Lower the ceiling to −3 and hear the level come down. |
| Dual Mono | `off/on (off)` | Measures/normalizes the channels as two independent mono signals. | On a dual-mono take, enabling it should match both channels; on real stereo it changes the measurement (and therefore the gain). |

**Quick test:** quiet speech → target −16, ceiling −1: loud and clean; then
target −23 and confirm the take is roughly 7 LU quieter.

---

#### 15. Compressor (`dyncomp`)

*Category: Dynamics & Mastering.*

A full-featured compressor with a noise-floor freeze (so silence is not pumped
up), soft knee, Peak/RMS detection, and a downward/upward mode. Downward
compression reduces loud parts; upward compression raises quiet parts. The
noise-floor control freezes gain reduction below a level so room tone does not
breathe.

| Control | Range (default) | What it does | How to check |
|---|---|---|---|
| Threshold | `-60.0–-1.0 dB (-18.0)` | Level where compression starts. Lower = more compression. | Speech with peaks around −12 dB: at −18 only the loudest syllables compress; at −40 the whole take is squashed. |
| Noise Floor | `-80.0–-20.0 dB (-55.0)` | Below this level the detector freezes, preventing silence from being boosted. | Record speech with a quiet pause: with the floor high, the pause stays quiet; with it low, the noise pumps up between words. |
| Ratio | `1.1–20.0:1 (3.0)` | How strongly levels above the threshold are reduced. | 1.1:1 is nearly transparent; 10:1 flattens dynamics. Confirm the compressor acts *more* as the ratio rises. |
| Attack | `1.0–200.0 ms (10.0)` | How fast gain reduction engages. | Fast attack (1–5 ms) tames plosives but can dull transients; slow (50–200 ms) lets transients through. Compare on a click/plosive. |
| Release | `10.0–2000.0 ms (150.0)` | How fast gain returns after the signal drops. | Short release pumps/ducks; long release smooths and sustains. Hear the difference on speech with pauses. |
| Knee Width | `0.0–20.0 dB (6.0)` | Softness of the threshold transition. | 0 dB = hard knee (audible "grab"), 20 dB = gradual. On a slowly rising tone the onset of compression should soften. |
| Detector | `[Peak \| RMS] (RMS)` | Peak follows sample peaks; RMS follows average energy. | Peak clamps transients hard; RMS breathes with the overall level. On a drum-like signal the difference is obvious. |
| Upward Compression | `off/on (off)` | Inverts the action: raises quiet parts toward the threshold instead of lowering loud parts. | Off = normal downward compression. On = the quiet parts come up; check that the noise floor is not exaggerated. |
| Make-Up Gain | `-12.0–24.0 dB (0.0)` | Output gain after compression. | Compress heavily and raise make-up to restore loudness; it should not change the compressed dynamics. |

**Quick test:** speech with a noisy pause → threshold −24, ratio 4:1, fast
attack, 150 ms release: words even out; raise Noise Floor until the pause stops
breathing; switch to Upward and hear the quiet syllables lift.

---

#### 16. Compressor Pro (`comp`)

*Category: Dynamics & Mastering.*

A simple vocal leveler: one **Compression** amount drives a soft-knee
compressor with automatic, gated make-up. Because the make-up is gated, room
tone before speech is not amplified.

| Control | Range (default) | What it does | How to check |
|---|---|---|---|
| Compression | `0–100% (0)` | Overall amount of compression (and automatic make-up). | 0% must be transparent. 40–60% evens out speech; 100% is heavily controlled. Confirm the take gets denser, not just quieter. |
| Ratio | `1.2–10.0:1 (3.0)` | Slope above the internal threshold. | With Compression at 50%, raising the ratio should flatten peaks further. |
| Attack | `1.0–100.0 ms (8.0)` | Engagement speed. | Fast attack softens plosives; slow attack keeps consonant transients crisp. |
| Release | `10.0–1000.0 ms (140.0)` | Recovery speed. | Short release sounds lively but can pump; long release is smoother. Check on speech with pauses. |
| Knee | `0.0–18.0 dB (6.0)` | Softness of the onset. | 0 dB grabs abruptly; 18 dB eases in. Listen on a sustained vowel. |

**Quick test:** alternating loud/quiet speech → Compression 50% should even it
out; confirm the silent gap before the first word stays quiet (gated make-up).

---

#### 17. Multiband Compressor (`mbcomp`)

*Category: Dynamics & Mastering.*

Splits the signal into three bands (low/mid/high) at two crossovers and
compresses each independently, then sums them. Use it to control a boomy low
end without dulling the highs, or to tame harsh upper-mids without touching the
bass.

| Control | Range (default) | What it does | How to check |
|---|---|---|---|
| Low Crossover | `80.0–500.0 Hz (200.0)` | Boundary between the low and mid bands. | On pink noise with the low band compressing, moving the crossover shifts which frequencies pump. |
| High Crossover | `1500.0–8000.0 Hz (3200.0)` | Boundary between the mid and high bands. | Move it while compressing the high band: the "sss" region starts being controlled at a different point. |
| Low Threshold | `-48.0–-3.0 dB (-20.0)` | Compression threshold for the low band. | Lower it: bass/boom gets controlled. Confirm the mids stay untouched. |
| Low Ratio | `1.2–10.0:1 (3.0)` | Low-band compression amount. | Raise it and hear the low end flatten on a bass-heavy take. |
| Mid Threshold | `-48.0–-3.0 dB (-18.0)` | Compression threshold for the mid band. | Lower it to tame boxy/honky mids; confirm lows/highs are unaffected. |
| Mid Ratio | `1.2–10.0:1 (2.5)` | Mid-band compression amount. | Compare 2.5 vs 10 on speech: the mid band becomes progressively flatter. |
| High Threshold | `-48.0–-3.0 dB (-22.0)` | Compression threshold for the high band. | Lower it to control harshness/sibilance; check that it does not dull the air too much. |
| High Ratio | `1.2–10.0:1 (3.5)` | High-band compression amount. | Raise it on a bright take: the top end smooths. |
| Overall Amount | `0–100% (65)` | Blends all three compressed bands with the dry signal. | 0% should be transparent; 100% is full multiband control. Sweep it to hear the whole compression appear. |

**Quick test:** bass-heavy speech → low threshold −30, low ratio 6:1, overall
70%: boom is controlled while the voice stays open; then move the low crossover
and hear the control point shift.

---

#### 18. Brickwall Limiter (`bricklim`)

*Category: Dynamics & Mastering.*

A 3 ms look-ahead brickwall limiter with a soft-clip knee and optional auto
make-up. It is the safety stage: drive into it and the output peak should never
exceed the ceiling.

| Control | Range (default) | What it does | How to check |
|---|---|---|---|
| Input Gain | `0.0–24.0 dB (0.0)` | Gain before limiting (how hard you drive it). | Raise it on a mix: the limiter works harder, the take gets louder, and the peak stays at the ceiling. |
| Ceiling | `-15.0–-0.05 dB (-0.3)` | Maximum output peak. | Watch the waveform peak: it should sit at the ceiling, never above. Lower the ceiling to −6 and hear the level drop. |
| Release | `5.0–500.0 ms (60.0)` | Recovery after limiting. | Fast release is punchy but can distort low frequencies; slow release is smoother. Check on bass-heavy material. |
| Soft-Clip Knee | `off/on (on)` | Rounds peaks approaching the ceiling instead of hard-limiting. | On = less brittle on transients; off = harder, more obvious limiting. Compare on a clap/plosive. |
| Auto Make-Up | `off/on (off)` | Restores loudness lost to limiting. | Drive hard with it off, then on: the output should come back up while still respecting the ceiling. |

**Quick test:** hot take → Input Gain +12, ceiling −1: peaks pinned at −1 dBFS;
sweep the ceiling from −0.3 to −6 and watch the waveform top follow it.

---

#### 19. Brickwall Limiter Pro (`limiter`)

*Category: Dynamics & Mastering.*

The always-on ceiling limiter. At **Drive 0** it is a safety ceiling only:
signals below the ceiling pass untouched and only peaks approaching it are
shaped. Raising Drive pushes the signal into the ceiling for loudness.

| Control | Range (default) | What it does | How to check |
|---|---|---|---|
| Drive | `0–100% (0)` | Amount of gain pushed into the soft-clip ceiling (up to the limiter's maximum drive). | 0% must be transparent for signals below the ceiling. 50–100% should get louder while peaks stop at the ceiling. |
| Ceiling | `-6.0–-0.1 dBFS (-0.2)` | Maximum output level. | Watch peaks: they should never cross the value. Lowering the ceiling should lower the output level, not create clipping. |
| Release | `10.0–500.0 ms (80.0)` | Recovery time of the limiter. | Short release can pump/distort bass; long release is smoother. Compare on a bass note. |

**Quick test:** a signal that peaks at −1 dBFS with Drive 0 should pass nearly
unchanged; Drive 100% should be louder with the waveform top flat at the
ceiling.

---

#### 20. Gate / Expander (`gateexp`)

*Category: Dynamics & Mastering.*

A noise gate / downward expander with hysteresis, hold, ratio, range and a
sidechain high-pass. In **Expander** mode quiet signals are faded down by the
ratio; in **Gate** mode they are cut to the range floor. The sidechain HPF stops
rumble from holding the gate open.

| Control | Range (default) | What it does | How to check |
|---|---|---|---|
| Mode | `[Gate \| Expander] (Expander)` | Gate = hard close; Expander = gradual downward expansion. | On room tone, Gate snaps shut; Expander fades it. Both should reduce noise between phrases. |
| Threshold | `-96.0–-6.0 dB (-42.0)` | Level where the gate opens/closes. | Raise it until room noise closes but speech still opens it. Confirm the voice does not get chopped. |
| Hysteresis | `0.0–12.0 dB (4.0)` | Gap between open and close thresholds; prevents chatter. | At 0 dB a signal near the threshold stutters; raising it makes the open/close stable. |
| Ratio | `1.5–20.0:1 (4.0)` | Expander slope below the threshold. | In Expander mode, higher ratios attenuate quiet parts more strongly. |
| Range / Floor | `-90.0–0.0 dB (-24.0)` | Maximum attenuation when closed. | At −24 dB the noise is reduced but audible; at −90 it is silent. Check the floor on a quiet pause. |
| Attack | `1.0–100.0 ms (3.0)` | How fast the gate opens. | Fast attack catches word onsets; slow attack can clip the first consonant. |
| Hold | `0.0–1000.0 ms (40.0)` | Keeps the gate open after the signal drops. | Increase it so short gaps between words do not close the gate (no chopping). |
| Release | `10.0–2000.0 ms (180.0)` | How fast it closes/fades down. | Short release sounds abrupt/tail-cutting; long release sounds natural but lets noise linger. |
| Sidechain HPF | `20.0–600.0 Hz (120.0)` | High-pass on the detector signal. | With desk rumble, a higher HPF stops the rumble from opening the gate; the voice still opens it. |

**Quick test:** speech + room tone → threshold until the pauses close, hold
~100 ms so word gaps do not chop, release ~200 ms; then tap the desk and confirm
the sidechain HPF stops the thump from opening the gate.

---

#### 21. Auto Duck (`autoduck`)

*Category: Dynamics & Mastering.*

Ducks the signal whenever the input exceeds the threshold — the classic
"music bed under a voice" tool. It ramps down quickly, holds through short
pauses, and ramps back up smoothly.

| Control | Range (default) | What it does | How to check |
|---|---|---|---|
| Duck Amount | `-36.0–0.0 dB (-12.0)` | How far the signal is reduced while ducking. | On a music bed, −12 dB is a gentle dip; −36 dB is nearly muted. 0 dB should not duck at all. |
| Threshold | `-60.0–-3.0 dB (-28.0)` | Input level that triggers ducking. | Speak over the bed: lower the threshold until the voice reliably triggers the duck; too low and room tone triggers it. |
| Fade Down | `10–2000 ms (120)` | Ramp-down time. | Short = instant duck (can click); long = the first word may be masked. Check the start of a phrase. |
| Fade Up | `10–3000 ms (400)` | Ramp-up time after the trigger stops. | Long = smooth recovery; short = the bed jumps back. Listen after a phrase. |
| Max Pause | `50–5000 ms (500)` | Hold time across brief pauses before releasing. | Speak with pauses shorter than this value: the bed should stay ducked instead of pumping between words. |

**Quick test:** voice over a music/room bed → threshold set so speech triggers,
amount −15 dB, fade down 100 ms, fade up 500 ms, max pause 600 ms: the bed dips
under speech and stays down through short pauses.

---

#### 22. De-Esser (Split Band) (`deesssplit`)

*Category: Dynamics & Mastering.*

A precision sibilance compressor: a band around the **Frequency** is detected
and reduced, either split-band (only the sibilant band is attenuated) or
broadband (the whole signal is ducked). The threshold and max reduction make the
behaviour predictable.

| Control | Range (default) | What it does | How to check |
|---|---|---|---|
| Frequency | `3000–12000 Hz (6800)` | Center of the sibilance band. | On a long "sss", sweep the frequency: the reduction should be strongest when it matches the hiss. 6–8 kHz is typical for "s". |
| Bandwidth Q | `0.5–10.0 (2.0)` | Width of the detector band. | High Q = only the exact sibilant; low Q = a wider band. Compare on "sh" vs "s". |
| Threshold | `-48.0–0.0 dB (-18.0)` | Level where reduction starts. | Lower it: more sibilance is caught. Too low and normal consonants get dulled. |
| Max Reduction | `0.0–24.0 dB (12.0)` | Ceiling on how much the band can be reduced. | 3–6 dB is gentle; 24 dB is heavy. Confirm "sss" is tamed without a lisp. |
| Mode | `[Split-Band \| Broadband] (Split-Band)` | Split-band attenuates only the band; broadband ducks the whole signal. | Split-band keeps the vowel untouched; broadband dips the whole word on an "s". Compare on "seventy-six". |

**Quick test:** read "She sells seashells" → Frequency 6.8 kHz, threshold −24,
max 8 dB, split-band: hiss softens, vowels unchanged; switch to broadband and
hear the whole word dip.

### NOISE REMOVAL & RESTORATION

---

#### 23. Noise Suppression Pro (`noise`)

*Category: Noise Removal & Restoration.*

Spectral noise subtraction with a learned noise profile. Select a noise-only
region, tap **Learn from selection** in the slot, then apply the effect to the
take: the learned spectrum is subtracted from every frame while loud voice bins
are left alone. With no learned profile it falls back to an adaptive minimum
tracker, so it still does something out of the box (less precisely).

| Control | Range (default) | What it does | How to check |
|---|---|---|---|
| Intensity | `0–100% (50)` | How much of the learned noise spectrum is subtracted. | On a hissy take, 20–40% is gentle, 80–100% is aggressive. Too high produces "underwater"/metallic artifacts; confirm the voice stays natural. |
| Smoothing | `0–100% (50)` | Smooths the subtraction over frequency/time, trading detail for fewer artifacts. | Low smoothing keeps more detail but can sound "chirpy"; high smoothing reduces musical noise but can dull consonants. Compare on an "sss". |
| Learn from selection | action button | Captures the noise profile from the current selection. | Select 1–2 s of noise only (no voice), tap Learn, then apply: hiss should drop. Re-learn from a noisy region and confirm the result changes. |

**Quick test:** record 3 s of room tone, then speech. Select the room tone, tap
**Learn from selection**, apply to the speech: hiss drops, voice intact; push
Intensity to 100% and hear the artifacts (proof the control works).

---

#### 24. Spectral Noise Reduction (`specnr`)

*Category: Noise Removal & Restoration.*

A second spectral denoiser with explicit dB controls. It learns a per-bin noise
profile from a selection and applies spectral gating; **Sensitivity** controls
over-subtraction and **Freq Smoothing** controls how many neighboring bins are
smoothed. **Reduce Noise** outputs the cleaned signal; **Isolate Noise** outputs
what is being removed (useful to hear exactly what the effect is doing).

| Control | Range (default) | What it does | How to check |
|---|---|---|---|
| Noise Reduction | `0.0–48.0 dB (18.0)` | Maximum attenuation applied to bins judged noise. | At 6 dB the noise is softened; at 48 dB it is nearly removed but artifacts increase. |
| Sensitivity | `0.0–24.0 dB (6.0)` | Over-subtraction: higher values treat more bins as noise. | Raise it and hear more noise disappear — and more voice detail go with it. |
| Freq Smoothing | `0–12 bins (2)` | Smooths the gain curve across neighboring bins. | 0 bins can sound granular; 12 bins is smoother but smears narrow tones. Check on a steady hiss and on speech. |
| Mode | `[Reduce Noise \| Isolate Noise] (Reduce Noise)` | Reduce = cleaned output; Isolate = the removed component only. | Switch to Isolate: you should hear hiss/room tone and almost no voice. This is the clearest proof the learned profile is correct. |
| Learn from selection | action button | Captures the per-bin noise profile. | Select noise only, Learn, then switch between Reduce/Isolate: Isolate should sound like the selected noise. |

**Quick test:** hum + hiss take → learn from a noise-only region → Reduce with
18 dB / 6 dB sensitivity: noise drops; Isolate should contain the removed noise
only.

---

#### 25. Click Removal (`declick`)

*Category: Noise Removal & Restoration.*

Detects short impulsive clicks, pops and mouth ticks by their second-order
curvature relative to the surrounding neighborhood and replaces them with cubic
Hermite interpolation, leaving the rest of the audio untouched.

| Control | Range (default) | What it does | How to check |
|---|---|---|---|
| Threshold | `1–900 (200)` | Detection sensitivity: lower values catch smaller clicks, higher values only strong ones. | On a take with a clear click, lower the threshold until it disappears. Too low and the effect starts dulling normal transients. |
| Max Spike Width | `1–40 samples (12)` | Longest click the interpolator may replace. | A wide pop needs a bigger width; setting it too small leaves part of the click. Check a short tick vs a longer pop. |

**Quick test:** add a click (tap the mic or use a rhythm track), set width 12:
lower the threshold until the click vanishes; confirm speech transients survive
at that setting.

---

#### 26. Clip Fix (`clipfix`)

*Category: Noise Removal & Restoration.*

Repairs flat-topped clipped waveforms: it finds runs that sit at the clipping
threshold, reduces the whole take by the requested headroom to make room, and
reconstructs each run with a cubic arch matching the entry/exit slopes.

| Control | Range (default) | What it does | How to check |
|---|---|---|---|
| Clipping Threshold | `80–100% (95)` | How close to the peak a sample must be to count as clipped. | Set it just below the recorded clipping level (e.g. 95%). Too low treats loud peaks as clipped; too high leaves flat tops. |
| Restore Headroom | `-18.0–0.0 dB (-6.0)` | Gain reduction applied before rebuilding peaks. | More headroom gives the arch room but lowers the take; less keeps level but limits the repair. Check the waveform top becomes rounded instead of flat. |

**Quick test:** a deliberately clipped recording (record too hot) → threshold 95%,
headroom −6 dB: flat tops become rounded; confirm the take is slightly quieter
and less crunchy.

---

#### 27. Repair (`repair`)

*Category: Noise Removal & Restoration.*

LPC interpolation for a short glitch or dropout: it finds the worst span in the
region and reconstructs it from the audio on both sides using forward and
backward linear prediction, cross-faded with a raised-cosine window.

| Control | Range (default) | What it does | How to check |
|---|---|---|---|
| Prediction Order | `8–32 (16)` | Number of LPC coefficients used to model the signal. | Higher orders follow complex material better but can ring; lower orders smooth more. Compare on a voiced vowel. |
| Max Repair Length | `0.5–50.0 ms (3.0)` | Longest span that can be repaired. | A tiny dropout needs a short length; a longer gap needs more. If the length is too short the repair is incomplete. |

**Quick test:** create a short dropout (a click or a tiny muted gap in a test
file), order 16, length 3 ms: the gap should be filled with plausible audio
instead of a click/silence.

---

#### 28. De-Hum (`dehum`)

*Category: Noise Removal & Restoration.*

A cascade of high-Q notches at the mains frequency and its harmonics. Set the
base to 50 or 60 Hz depending on the country, then choose how many harmonics to
remove.

| Control | Range (default) | What it does | How to check |
|---|---|---|---|
| Base Frequency | `45–65 Hz (50)` | Mains fundamental to notch. | On a hum recording, 50 Hz removes European/Asian hum, 60 Hz removes US hum. Confirm the buzz disappears at the right setting. |
| Harmonics | `1–10 (8)` | How many multiples of the base frequency are notched. | Buzz usually needs 3–8 harmonics; at 1 only the fundamental goes and the buzzy overtones remain. Raise until the buzz is gone. |
| Notch Q | `5–40 (20)` | Width of each notch. | High Q is surgical (voice untouched); low Q removes more around each harmonic but can thin the voice. |

**Quick test:** 60 Hz hum take → base 60, harmonics 8, Q 20: buzz disappears;
set harmonics 1 and hear the remaining overtones; lower Q and hear the voice
thin.

---

#### 29. Plosive & Breath Suppressor (`plosive`)

*Category: Noise Removal & Restoration.*

A dynamic low-band suppressor: it detects sub-140 Hz plosive bursts relative to
mid-band voice energy and attenuates only the offending low band, plus a gentle
breath gate for unvoiced breath sounds between phrases.

| Control | Range (default) | What it does | How to check |
|---|---|---|---|
| Plosive Cut Sensitivity | `0–100% (60)` | How aggressively plosives are detected/attenuated. | On "Peter Piper", raise it until the thumps are gone; too high can thin normal low notes. |
| Plosive Corner | `60–220 Hz (130)` | Upper edge of the band treated as plosive. | 60–100 Hz targets only the deepest thump; 200 Hz catches more body. Keep it below the voice fundamental. |
| Breath Attenuation | `-24.0–0.0 dB (-9.0)` | How much quiet breath noise is reduced. | On a breathy speaker, −6 dB is gentle, −24 dB nearly removes breaths. At 0 dB breaths should be untouched. |

**Quick test:** read plosive-heavy text → sensitivity 60, corner 130, breath
−9 dB: "P/B" thumps soften, breaths reduce, vowels unchanged.

---

#### 30. De-Esser Pro (`deess`)

*Category: Noise Removal & Restoration.*

A relative sibilance suppressor with a split-band detector. **Reduction** is the
amount applied; **Center Freq** tunes the sibilant band; **Bandwidth** sets how
wide the band is; **Mode** chooses split-band (only the band is attenuated) or
broadband (the whole signal ducks).

| Control | Range (default) | What it does | How to check |
|---|---|---|---|
| Reduction | `0–100% (0)` | How strongly sibilance is suppressed. | 0% must be transparent. 30–60% tames "sss"; 100% can lisp. |
| Center Freq | `3500–10000 Hz (6500)` | Sibilance band center. | Sweep on "sss": the strongest reduction should occur at the hiss frequency. Female sibilance often sits higher than male. |
| Bandwidth | `10–100% (50)` | Width of the detector/attenuation band. | Low = narrow (only the hiss); high = wide (more of the consonant). Check "sh" vs "s". |
| Mode | `[Split-band \| Broadband] (Split-band)` | Split-band keeps the voice; broadband ducks the whole signal. | Split-band: only the "s" softens. Broadband: the whole word dips. Compare on "six". |

**Quick test:** "She sells seashells" → Reduction 50%, center 6.5 kHz, bandwidth
50%, split-band: hiss softens with no lisp; switch to broadband and hear the
whole word duck.

---

#### 31. Room Gate Pro (`gate`)

*Category: Noise Removal & Restoration.*

A musical downward expander with a key-filtered detector, hysteresis, hold and
release. The **Threshold** percentage is the familiar main control: higher
percentages raise the threshold so the gate closes more readily.

| Control | Range (default) | What it does | How to check |
|---|---|---|---|
| Threshold | `0–100% (40)` | Gate threshold (higher % = higher threshold). | Raise it until room tone closes between phrases; lower it if quiet words get cut. Confirm the voice opens it reliably. |
| Range | `6.0–40.0 dB (20.0)` | How much the signal is attenuated when closed. | 6 dB is a gentle fade; 40 dB is near-silence. Check the noise floor on a pause. |
| Release | `40–400 ms (160)` | How fast the gate closes after the hold. | Short = abrupt, long = natural but lets noise linger. Listen to the end of a phrase. |
| Hold | `0–200 ms (40)` | Keeps the gate open after the level drops. | Increase it so gaps between words do not chop the voice. |

**Quick test:** speech + room tone → threshold until pauses close, range 20 dB,
hold 60 ms, release 160 ms: pauses are quiet, word gaps stay intact.

### DELAY, REVERB & SPATIAL

---

#### 32. Studio Reverb (`reverb`)

*Category: Delay, Reverb & Spatial.*

A Freeverb-style stereo room: eight feedback combs and four all-pass diffusers
per channel, with pre-delay, damping, wet/dry gains, tone shaping and width.
**Room Size** and **Reverberance** both feed the comb feedback, so together they
set how long the tail lasts.

| Control | Range (default) | What it does | How to check |
|---|---|---|---|
| Room Size | `0–100% (55)` | Scales the reverb tank's decay/size (averaged with Reverberance). | On a clap, raising it lengthens the tail; lowering it makes a small, tight room. |
| Pre-Delay | `0–200 ms (15)` | Gap between the dry sound and the reverb onset. | On speech, 0 ms fuses the reverb with the word; 60–120 ms creates a clear "room" before the tail. |
| Reverberance | `0–100% (60)` | Reverb decay amount (also feeds the comb feedback). | Raise it and the tail blooms; lower it and the reverb becomes short. Confirm it changes tail length, not just level. |
| HF Damping | `0–100% (50)` | Absorbs high frequencies in the tail (soft room). | High damping = dark, natural tail; low damping = bright/metallic. Compare on a cymbal/clap. |
| Tone Low | `0–100% (100)` | Low-frequency tone of the wet signal. | Lower it to remove low rumble from the tail; confirm the dry signal is unaffected. |
| Tone High | `0–100% (100)` | High-frequency tone of the wet signal. | Lower it to soften a bright reverb; at 100% the tail is unfiltered. |
| Wet Gain | `-24.0–6.0 dB (-6.0)` | Level of the reverb return. | Raise it for an obvious effect; lower it for subtle ambience. −24 dB is nearly dry. |
| Dry Gain | `-24.0–6.0 dB (0.0)` | Level of the original signal. | Pull it down for a wet-only sound; 0 dB keeps the dry level. |
| Stereo Width | `0–100% (100)` | Stereo spread of the tail. | 0% collapses the reverb to mono; 100% is wide. Check with headphones for a mono-compatible image. |
| Wet Only | `off/on (off)` | Mutes the dry path. | On = only the reverb tail. Use it to hear what the tank is doing, then turn it off. |

**Quick test:** a single clap → pre-delay 50 ms, size 70%, wet −6 dB: a clear
room tail after the clap; damp 80% darkens it, width 0% centers it.

---

#### 33. Multi-Echo Delay (`multidelay`)

*Category: Delay, Reverb & Spatial.*

A multi-tap delay with three behaviours: **Regular** (evenly spaced echoes),
**Bouncing Ball** (taps get progressively closer, like a bouncing ball), and
**Reverse Echo** (taps build up rather than decay). Each tap can change level and
time.

| Control | Range (default) | What it does | How to check |
|---|---|---|---|
| Delay Type | `[Regular \| Bouncing Ball \| Reverse Echo] (Regular)` | Tap spacing pattern. | On a single clap: Regular is evenly spaced; Bouncing Ball accelerates; Reverse builds into the hit. Each must be clearly different. |
| Delay Time | `10–3000 ms (280)` | Base spacing between the first taps. | Short = slapback; long = distinct repeats. Tap along with a click track and confirm the spacing matches the label. |
| Time Change / Echo | `-200.0–200.0 ms (0.0)` | Change in spacing from one tap to the next. | Positive values spread taps apart; negative values bunch them together. Listen to the first three taps. |
| Level / Echo | `-24.0–1.0 dB (-6.0)` | Level change per successive tap. | −6 dB gives natural decay; positive values make later taps louder; −24 dB kills them quickly. |
| Echo Count | `1–30 (4)` | Number of taps. | Raise it and count the repeats; at 1 only one tap should sound. |

**Quick test:** clap → Regular, 300 ms, level −6 dB, count 4: four evenly spaced
decaying taps; switch to Bouncing Ball and hear the spacing shrink.

---

#### 34. Echo (`echo`)

*Category: Delay, Reverb & Spatial.*

A simple feedback echo: one delay line whose output is fed back into itself.
**Delay Time** sets the spacing and **Decay Factor** sets how much of each repeat
survives. Changing the delay time does not erase the echoes already in the
buffer.

| Control | Range (default) | What it does | How to check |
|---|---|---|---|
| Delay Time | `10–5000 ms (400)` | Time between repeats. | On speech, 80–150 ms is slapback; 400–800 ms is a distinct echo. Count the repeats against a slow count. |
| Decay Factor | `1–95% (45)` | Feedback amount: how long the repeats last. | Low % = one or two repeats; 90% = a long trail. Confirm that high feedback does not run away into clipping. |

**Quick test:** single word → 400 ms / 45%: two or three audible repeats;
raise decay to 85% and hear the trail extend.

---

#### 35. Stereo Imaging (`stereoimg`)

*Category: Delay, Reverb & Spatial.*

Constant-power pan, mid/side width and channel operations (swap, mono, phase
invert). Use it to place a take in the stereo field, widen a mono source, or
check mono compatibility.

| Control | Range (default) | What it does | How to check |
|---|---|---|---|
| Pan (L ↔ R) | `-100–100% (0)` | Constant-power pan from left to right. | Hard left at −100, center at 0, hard right at +100. Confirm the level stays roughly constant across the sweep (constant-power). |
| Stereo Width | `0–200% (100)` | Mid/side width: 0 = mono, 100 = original, 200 = extra wide. | 0% should collapse to mono (both channels identical); 200% widens. Check on headphones and then in mono for phase cancellation. |
| Channel Mode | `[Normal \| Swap L ↔ R \| Stereo to Mono \| Invert Both (180°) \| Invert Left Only \| Invert Right Only] (Normal)` | Routing/phase operations. | Swap should exchange sides; Mono should make L=R; Invert Both on a mono source should be inaudible (polarity flip only) but cancel against the original in a null test. |

**Quick test:** stereo music bed → width 0 then 200% (mono vs wide); pan full
left then right; then Invert One channel and confirm the center image collapses
on headphones (proof the phase control works).

---

### PITCH, SPEED & TIME

> These are offline transforms: they rewrite the selected region (or the whole
> take) when applied. Speech is the best test material because pitch and
> duration errors are obvious. Check that the processed region still lines up
> in time after applying.

---

#### 36. Change Pitch (`changepitch`)

*Category: Pitch, Speed & Time.*

WSOLA pitch shift that keeps the tempo: the signal is time-stretched and then
resampled back so the duration is unchanged. Semitones, cents and percent all
add together (100% ≈ +12 semitones, −50% ≈ −12). **Preserve Formants** keeps the
vocal tract character so a pitched-up voice does not sound like a chipmunk.

| Control | Range (default) | What it does | How to check |
|---|---|---|---|
| Semitones | `-24.0–24.0 (0.0)` | Coarse pitch shift. | Speak a steady vowel: +12 should be an octave up, −12 an octave down, with the same duration. Check a tuner or a reference tone. |
| Cents | `-100–100 (0)` | Fine pitch trim (100 cents = 1 semitone). | With a sustained tone, +50 cents should be a quarter-tone sharp; use a tuner to confirm. |
| Percent Change | `-50.0–100.0% (0.0)` | Alternative pitch amount (logarithmic): +100% = +12 st, −50% = −12 st. | Set +100% and −50% and confirm they match +12/−12 semitones. It should combine with the semitone control, not replace it. |
| Preserve Formants | `off/on (on)` | Keeps the vocal formants natural. | On: pitch-shifted speech still sounds like the same speaker. Off: obvious chipmunk/monster character. Compare at +7 st. |

**Quick test:** speech → +5 semitones with formants on: higher but natural and
the same length; turn formants off and hear the cartoon effect; then −5 and
confirm the duration is still unchanged.

---

#### 37. Change Tempo (`tempo`)

*Category: Pitch, Speed & Time.*

WSOLA time-stretch that changes duration while keeping pitch. You can set the
change as a percentage or as BPM from/to; **High-Quality Speech Mode** improves
the transient handling for spoken material.

| Control | Range (default) | What it does | How to check |
|---|---|---|---|
| Percent Change | `-75.0–300.0% (0.0)` | Speed of playback: negative = slower/longer, positive = faster/shorter. | +100% should roughly halve the duration, −50% should double it; pitch must stay the same. |
| BPM From | `30–300 (120)` | Source tempo for a musical calculation. | With BPM To fixed, changing From changes the resulting percentage. Confirm the displayed/effective change matches the ratio. |
| BPM To | `30–300 (120)` | Target tempo. | Set From 120 → To 90: the take should slow to 75% speed, pitch unchanged. |
| High-Quality Speech Mode | `off/on (on)` | Better transient/phase handling for speech. | On should sound smoother with fewer metallic artifacts; off is faster but more grainy. Compare on a plosive-heavy phrase. |

**Quick test:** 10 s speech → +50%: about 6.7 s and the same pitch; −50%: about
20 s; toggle HQ and compare the consonants.

---

#### 38. Change Speed and Pitch (`speedpitch`)

*Category: Pitch, Speed & Time.*

Varispeed: resampling that changes speed and pitch together, like playing a tape
faster or slower. Use it for creative speed changes; use Change Tempo or Change
Pitch when you need to move only one dimension.

| Control | Range (default) | What it does | How to check |
|---|---|---|---|
| Speed Multiplier | `0.25–4.0x (1.0x)` | Playback rate; pitch scales with it. | 2.0x = twice as fast and an octave up; 0.5x = half speed and an octave down. Confirm both happen together. |
| Percent Change | `-75.0–300.0% (0.0)` | Same control as a percentage: +100% = 2x, −50% = 0.5x. | +100% should match 2.0x; −50% should match 0.5x. |

**Quick test:** speech → 2.0x: short and high; 0.5x: long and low. Then use
Change Tempo at +100% and confirm the pitch does *not* change (that contrast is
the point of both effects).

---

#### 39. Sliding Stretch (`slidestretch`)

*Category: Pitch, Speed & Time.*

A time-varying WSOLA: the tempo and pitch ramp linearly from the start of the
region to the end. Use it for risers, slowdowns, or a gradual pitch drift.

| Control | Range (default) | What it does | How to check |
|---|---|---|---|
| Initial Tempo Change | `-75.0–300.0% (0.0)` | Tempo at the start of the region. | Set +100 → −50 and listen: the beginning is fast and the end is slow. |
| Final Tempo Change | `-75.0–300.0% (0.0)` | Tempo at the end. | The opposite of Initial; together they define the ramp direction. |
| Initial Pitch Shift | `-24.0–24.0 st (0.0)` | Pitch at the start. | Set +12 → 0 and hear the pitch fall over the region. |
| Final Pitch Shift | `-24.0–24.0 st (0.0)` | Pitch at the end. | Set 0 → −12 and hear it drop; confirm it is a smooth glide, not a step. |

**Quick test:** a sustained vowel → tempo 0%/0%, pitch +12 → −12: a smooth
downward glide with no clicks at the segment boundaries.

---

#### 40. Paulstretch (`paulstretch`)

*Category: Pitch, Speed & Time.*

Extreme ambient time-stretching: a large-window STFT keeps the spectral
amplitudes but randomizes the phases, producing a smeared, pad-like texture.
Use it on music or a single note, not on speech you need to understand.

| Control | Range (default) | What it does | How to check |
|---|---|---|---|
| Stretch Factor | `1.5–100.0x (8.0x)` | How much longer the region becomes. | 2x is a mild smear; 10x+ turns a note into an ambient bed. Confirm the output length scales with the factor. |
| Time Resolution | `0.05–1.0 s (0.25 s)` | STFT window: shorter = more detail/transients, longer = smoother and more smeared. | Compare 0.05 s vs 1.0 s on a plucked note: short keeps more attack, long blurs it into a pad. |

**Quick test:** a single piano note or vowel → 8x, 0.25 s: a long ambient
tail; drop the resolution to 0.05 s and hear more of the original attack.

### DISTORTION, MODULATION & CREATIVE

---

#### 41. Distortion (`distort`)

*Category: Distortion, Modulation & Creative.*

An 11-curve waveshaper with drive, asymmetry, oversampling and a post low-pass.
The curves range from hard clipping to tube-like even harmonics; oversampling
reduces the aliasing that waveshaping creates.

| Control | Range (default) | What it does | How to check |
|---|---|---|---|
| Curve Type | `[Hard Clipping \| Soft Clipping (Tanh) \| Soft Overdrive \| Medium Overdrive \| Hard Overdrive \| Cubic Waveshaper \| Even Harmonics (Tube) \| Expand & Compress \| Leveller \| Rectifier \| Hard Limiter] (Soft Clipping (Tanh))` | Selects the transfer function. | On a 1 kHz sine, step through every curve: hard clip = square-ish, tanh = smooth, even harmonics = octave-rich/asymmetric, rectifier = buzzy octave, expander = dynamics weirdness. Each must be distinct. |
| Drive | `0–100% (45)` | How hard the signal is pushed into the curve. | Raise it: more saturation and harmonics. At 0% the curve should be nearly clean. |
| Asymmetry / DC | `-100–100% (0)` | Makes the positive/negative halves clip differently, adding even harmonics and potentially DC. | At +50% a sine becomes visibly asymmetric and sounds an octave-ish/richer; at the extremes check for DC offset on the waveform. |
| Clipping Level | `-24.0–0.0 dB (-3.0)` | Level at which the curve begins to saturate. | Lower it for more distortion at the same drive; raise it for a cleaner, more dynamic result. |
| Curve Parameter | `0–100% (50)` | Shape control for curves that use one (e.g. cubic/overdrive variants). | Some curves ignore it; on those that use it, sweep and listen for the knee/kink moving. |
| Oversampling | `[1x (Off) \| 2x \| 4x] (2x)` | Internal oversampling to suppress aliasing. | Feed a high sine (6–10 kHz) with heavy drive: 1x has gritty inharmonic aliases; 4x is cleaner. Compare the top end. |
| Post Tone LP | `800–18000 Hz (8000)` | Low-pass after the shaper. | Lower it to remove fizz/harshness; at 18 kHz the distortion is brightest. |

**Quick test:** 1 kHz sine → drive 80%, each curve in turn; then a 6 kHz sine
with drive 100% and compare 1x vs 4x oversampling (alias grit vs clean).

---

#### 42. Phaser (`phaser`)

*Category: Distortion, Modulation & Creative.*

2–24 cascaded all-pass stages swept by an LFO, with feedback, stereo phase and
dry/wet. More stages create more notches; feedback deepens them.

| Control | Range (default) | What it does | How to check |
|---|---|---|---|
| Stages | `2–24 (6)` | Number of all-pass stages (notch density). | On pink noise, 2 stages = one broad sweep; 24 = many dense notches. Countable difference. |
| Dry/Wet | `0–100% (50)` | Blend of phased and dry signal (notch depth). | 0% = dry, 50% = classic phaser, 100% = all-pass only (no notches audible on its own). |
| LFO Rate | `0.05–10.0 Hz (0.6)` | Sweep speed. | Slow = 0.1 Hz (a slow whoosh); fast = 5–10 Hz (vibrato-like). Watch the sweep move. |
| Stereo Phase | `0–360° (90)` | Offset between left/right LFOs. | 0° = both channels sweep together (mono-ish); 90–180° gives a wide, swirling image on headphones. |
| Depth | `0–100% (70)` | How far the notches sweep. | 0% = static notches; 100% = full-range sweep. Check the extremes. |
| Feedback | `-95–95% (40)` | Feeds the output back into the all-pass chain, sharpening the notches. | Higher feedback = more resonant/whistly sweep; negative feedback shifts the character. Check that 95% does not run away. |
| Center Freq | `150–4000 Hz (800)` | Center of the sweep range. | Move it: the whole sweep shifts from low (vowel-like) to high (thin/airy). |

**Quick test:** pink noise → rate 0.5 Hz, depth 100%, stages 6 vs 24: hear the
notch count change; then set stereo phase 180° and listen on headphones for the
wide swirl.

---

#### 43. Chorus & Flanger (`chorus`)

*Category: Distortion, Modulation & Creative.*

A fractional-delay modulation effect with three modes: **Chorus** (thickening),
**Flanger** (jet-plane sweep) and **Doubler/ADT** (short doubling). Base delay,
depth, rate, feedback and mix shape it.

| Control | Range (default) | What it does | How to check |
|---|---|---|---|
| Mode | `[Chorus \| Flanger \| Doubler (ADT)] (Chorus)` | Sets the delay range/character. | On a sustained tone: Chorus = lush detune; Flanger = pronounced whoosh; ADT = single short double. Each mode must be obvious. |
| Base Delay | `1.0–35.0 ms (15.0)` | Nominal delay before modulation. | Short delays flange; 15–25 ms chorus; 30–35 ms doubling. Listen for the comb-filter colour change. |
| Mod Depth | `0.1–10.0 ms (2.5)` | How far the delay is modulated. | Low depth = subtle shimmer; high depth = wide pitch wobble. Check that it does not sound out of tune. |
| LFO Rate | `0.05–8.0 Hz (0.8)` | Modulation speed. | Slow = drifting; fast = vibrato-ish. Compare 0.1 vs 6 Hz. |
| Feedback | `-90–90% (20)` | Delay feedback (resonance/ring). | Positive feedback intensifies the comb/whistle; negative changes the tone. High feedback should not self-oscillate into clipping. |
| Wet/Dry Mix | `0–100% (50)` | Blend of modulated and dry. | 0% = dry; 50% = classic; 100% = only the modulated copy (pitch wobble is obvious). |

**Quick test:** sustained vowel → Chorus 15 ms / 2.5 ms / 0.8 Hz: thicker;
switch to Flanger with feedback 60%: jet sweep; switch to ADT: one tight double.

---

#### 44. Tremolo (`tremolo`)

*Category: Distortion, Modulation & Creative.*

LFO amplitude modulation with five waveforms, depth, rate and stereo phase.
Unlike vibrato, tremolo changes level, not pitch.

| Control | Range (default) | What it does | How to check |
|---|---|---|---|
| Waveform | `[Sine \| Triangle \| Sawtooth \| Inverse Sawtooth \| Square] (Sine)` | Shape of the level modulation. | On a steady tone: sine = smooth pulse; square = on/off chop; sawtooth = ramp. Each must be clearly different. |
| Depth | `0–100% (50)` | Amount of level modulation. | 0% = steady; 100% = full on/off. At 100% with square you should hear clear chopping. |
| Rate | `0.1–20.0 Hz (4.0)` | Modulation speed. | 0.5 Hz = slow swell; 10–20 Hz = fast flutter. Confirm pitch does not change (that would be vibrato). |
| Starting / Stereo Phase | `0–360° (0°)` | LFO phase / left-right offset. | 0° = both channels together; 180° = ping-pong on headphones. Check the image moves side to side. |

**Quick test:** 1 kHz sine → depth 100%, rate 2 Hz, square: clear chopping;
switch to sine: smooth; set phase 180° and hear the sides alternate.

---

#### 45. Wahwah (`wah`)

*Category: Distortion, Modulation & Creative.*

A swept resonant band-pass driven by an LFO and/or the input envelope
(auto-wah). It is the "talking" filter: the peak sweeps through the spectrum.

| Control | Range (default) | What it does | How to check |
|---|---|---|---|
| LFO Rate | `0.1–6.0 Hz (1.5)` | Speed of the automatic sweep. | Slow = vowel-like sweeps; fast = wobble. Use a sustained tone to hear the peak move. |
| Depth | `0–100% (70)` | How far the filter sweeps. | 0% = fixed filter; 100% = full-range sweep. |
| Resonance (Q) | `0.5–10.0 (3.0)` | Sharpness of the resonant peak. | High Q = vocal/whistly peak; low Q = broad. Check high Q for a loud resonant whistle. |
| Freq Offset | `0–100% (30)` | Shifts the sweep range up/down. | Low = darker "ooh"; high = brighter "aah". Sweep it on a steady tone. |
| Stereo Phase | `0–360° (0°)` | LFO offset between channels. | 180° gives a wide, side-to-side wah on headphones. |
| Auto-Wah Env | `0–100% (0)` | How much the input envelope drives the filter instead of the LFO. | 0% = LFO only. Raise it and play/speak with varying loudness: louder input opens the filter. |
| Output Gain | `-18.0–12.0 dB (-6.0)` | Output trim (the filter can boost at resonance). | Match the bypassed level; raise it if the wah sounds quiet, lower it if the resonance is too loud. |

**Quick test:** sustained vowel → rate 1 Hz, depth 100%, Q 5: a clear "wah-wah"
sweep; set Auto-Wah 100% and stop the LFO by rate → the filter follows your
voice level.

---

#### 46. Vocoder (`vocoder`)

*Category: Distortion, Modulation & Creative.*

A multi-band vocoder: the voice (modulator) is split into 8–32 bands and each
band's envelope is imposed on an internal carrier. The result is the classic
robotic/talking-synth sound.

| Control | Range (default) | What it does | How to check |
|---|---|---|---|
| Vocoder Bands | `8–32 (16)` | Number of analysis/synthesis bands. | 8 bands = very robotic and intelligible-ish; 32 = detailed and smoother. Countable difference on speech. |
| Carrier Type | `[Sawtooth Synth \| White Noise \| Original + Synth] (Sawtooth Synth)` | Timbre of the carrier. | Sawtooth = classic synth voice; White noise = whispery/breathy; Original + Synth = hybrid with more of the real voice. |
| Carrier Pitch | `50–400 Hz (110)` | Base pitch of the synth carrier. | Low = deep/buzzy; high = thin/robotic. On a sustained vowel the pitch of the robot voice should follow. |
| Noise Mix | `0–100% (15)` | Amount of noise added to the carrier. | More noise = breathier, less tonal. 0% = pure synth; 100% = whispered robot. |
| Envelope Speed | `1.0–120.0 ms (10.0)` | How fast band envelopes follow the voice. | Fast = crisp consonants; slow = smeared/pad-like. Compare on "ba ba ba". |

**Quick test:** speak "one two three" → 16 bands, sawtooth, pitch 110: robotic
but intelligible; raise bands to 32 (clearer) and envelope speed to 120 ms
(smeared).

---

### FADES & TIMELINE TOOLS

---

#### 47. Fade (`fade`)

*Category: Fades & Timeline Tools.*

Fade in, fade out, equal-power "studio" fade out (with a closing low-pass) and a
fully adjustable fade with start/end gains and a mid-fade boost.

| Control | Range (default) | What it does | How to check |
|---|---|---|---|
| Type | `[Fade In \| Fade Out \| Studio Fade Out \| Adjustable Fade] (Fade In)` | Direction/character of the fade. | On a steady tone: Fade In rises, Fade Out falls, Studio Fade Out falls and darkens, Adjustable follows your start/end gains. |
| Curve Shape | `[Linear \| Logarithmic \| Exponential \| Cosine \| S-Curve] (Linear)` | Shape of the fade envelope. | Linear = even; logarithmic/exponential = slower at one end; S-curve = gentle both ends. Compare on a 2 s fade. |
| Mid-Fade Boost | `-100–100% (0)` | Adds a bump (positive) or dip (negative) in the middle of an adjustable fade. | Only meaningful for Adjustable Fade. Set +50% and hear the level swell mid-fade; −50% and hear a dip. |
| Start Gain | `0–100% (0)` | Starting level for Adjustable Fade. | Set 50%: the fade starts half-level instead of silence. |
| End Gain | `0–100% (100)` | Ending level for Adjustable Fade. | Set 20%: the fade ends at 20% instead of silence. |
| Length | `1–100% (20)` | How much of the region the fade covers. | 10% = short fade at the edge; 100% = across the whole selection. Watch the waveform ramp length change. |

**Quick test:** steady tone → Fade In, length 50%: half the region ramps up;
switch curves and watch/listen to the shape; Studio Fade Out should also dull
the top end as it fades.

---

#### 48. Timeline Utility (`timeline`)

*Category: Fades & Timeline Tools.*

Three destructive timeline operations on the region: **Invert** (polarity flip),
**Reverse** (play backwards) and **Repeat** (loop the region N times). When the
action is still Invert and you change the repeat count, the effect honours the
repeat count automatically — the primary dial is never a dead control.

| Control | Range (default) | What it does | How to check |
|---|---|---|---|
| Action | `[Invert \| Reverse \| Repeat] (Invert)` | Operation to perform. | Invert alone is hard to hear on a single track (it flips the waveform vertically); Reverse turns speech backwards; Repeat loops it. Each must be obvious except Invert. |
| Number of Repeats | `1–50 (2)` | Number of copies used by Repeat (or honoured automatically if Invert is selected and the count is changed). | Set Repeat with 3: the region should play three times. With Invert selected and repeats 3, the take should also repeat three times. |

**Quick test:** a spoken word → Reverse: clearly backwards; Repeat 4: the word
loops four times; Invert: the waveform flips but the sound is unchanged (that is
correct — polarity is only audible against another copy).

---

#### 49. Truncate Silence (`truncsil`)

*Category: Fades & Timeline Tools.*

Finds silent spans (10 ms RMS windows) longer than a minimum and either truncates
them to a target length or compresses them to a percentage, with a short
crossfade at each splice. It is the "tighten the pauses" tool.

| Control | Range (default) | What it does | How to check |
|---|---|---|---|
| Threshold | `-80.0–-20.0 dB (-40.0)` | Level below which audio counts as silence. | Raise it and more quiet audio is treated as silence; lower it and only true silence is cut. Check on a noisy room. |
| Minimum Silence | `50–5000 ms (400)` | Shortest silence that gets processed. | Set 100 ms to shorten every gap; 1000 ms to leave short pauses alone. |
| Action | `[Truncate Detected Silence \| Compress Excess Silence] (Truncate Detected Silence)` | Truncate = cut each silence to the target; Compress = shorten by a percentage. | Truncate produces a fixed pause length; Compress keeps the pauses proportional. Compare on speech. |
| Truncate To | `10–2000 ms (150)` | Target length for Truncate mode. | Set 100 ms: pauses become short and uniform. Confirm speech is not cut. |
| Compress To | `5–90% (35)` | Percentage for Compress mode. | 35% keeps about a third of each pause; 90% barely changes it. |

**Quick test:** speech with long pauses → threshold −40, min 300 ms, Truncate to
150 ms: the take gets tighter with no clipped words; switch to Compress 35% and
compare the pause lengths.

---

#### 50. Spectral Edit (`spectraledit`)

*Category: Fades & Timeline Tools.*

An STFT-domain EQ: shape or remove a frequency band inside the spectrum. It is
the closest thing to Audacity's spectral selection tools — band-limited
changes that can be much sharper than a time-domain EQ.

| Control | Range (default) | What it does | How to check |
|---|---|---|---|
| Mode | `[Spectral Parametric EQ \| Spectral Shelf \| Spectral Delete / Notch] (Spectral Parametric EQ)` | Boost/cut a band, shape a shelf, or delete the band. | On a chirp: Parametric = a local bump/dip; Shelf = one side shaped; Delete = the band disappears entirely. |
| Low Frequency | `20–20000 Hz (200)` | Lower edge of the band. | Sweep it on pink noise: the affected region moves. Ensure Low < High. |
| High Frequency | `20–20000 Hz (2000)` | Upper edge of the band. | Narrow the band and hear the edit become surgical; widen it for broad shaping. |
| Gain | `-36.0–24.0 dB (0.0)` | Boost/cut inside the band (ignored in Delete mode). | +12 dB boosts the band; −24 dB almost removes it; in Delete mode the band should vanish regardless of gain. |

**Quick test:** chirp → Delete mode, 2–4 kHz: that part of the sweep disappears
and the rest stays; switch to Parametric +12 dB and hear the band jump out.

---

### GENERATORS & ANALYZERS

---

#### 51. Audio Generator (`generator`)

*Category: Generators & Analyzers.*

Writes a test signal into the selected region (it overwrites, like a "Generate"
command): tone/chirp, noise, silence, a rhythm track, or DTMF digits. This is the
effect you use to build the test bench described in §2.

| Control | Range (default) | What it does | How to check |
|---|---|---|---|
| Generator | `[Tone & Chirp \| Noise \| Silence \| Rhythm Track \| DTMF] (Tone & Chirp)` | Signal family to generate. | Select a region and switch types: tone = steady pitch; noise = hiss; silence = flat; rhythm = beat; DTMF = phone tones. |
| Waveform | `[Sine / White \| Square / Pink \| Sawtooth / Brown \| Triangle / Blue \| No-Alias / Velvet] (Sine / White)` | Tone waveform (Tone & Chirp) or noise colour (Noise). | 1 kHz tone: sine is pure, square is buzzy, sawtooth bright, triangle soft. Noise: white is bright, pink balanced, brown dark. |
| Start Frequency | `20–20000 Hz (1000)` | Tone frequency, or chirp start. | Confirm with a tuner/spectrum: a 1 kHz setting should show/measure 1 kHz. |
| End Frequency | `20–20000 Hz (1000)` | Chirp end frequency. | Set 20 → 20000 (with a longer duration) and hear the sweep rise; set both equal for a steady tone. |
| Amplitude | `0–100% (50)` | Output level. | 0% = silence; 100% = full-scale (watch clipping). Keep test tones around 30–50% for headroom. |
| Duration | `0.1–600.0 s (5.0)` | Length of the generated signal. | Set 0.5 s vs 10 s and confirm the generated region length matches (clamped to the selection). |
| Tempo | `30–300 BPM (120)` | Rhythm-track tempo. | Tap along: 120 BPM = two beats per second; change to 60 and hear the spacing double. |
| DTMF Sequence | `0–999999999 (5)` | Digits played as DTMF tones in DTMF mode. | Try 123: three distinct phone tones in sequence. |

**Quick test:** select 3 s → Tone & Chirp, 20 Hz → 20 kHz, 3 s, 40%: a clean
sweep; switch to Noise / Pink for a 3 s pink-noise bed; switch to DTMF 123 and
confirm the tones.

---

## Appendix A — Primary dial per effect

The rack shows one **primary** control as the big dial; everything else is in the
slot body or under **Show advanced controls**. The primary dial is the fastest
thing to sanity-check first:

| Effect (`id`) | Primary dial |
|---|---|
| Low-Cut Filter Pro (`hpf`) | Cutoff |
| High-Pass / Low-Pass (`highpass` / `lowpass`) | Cutoff |
| Notch Filter (`notch`) | Frequency |
| Shelf Filter (`shelf`) | Shelf Gain |
| 6-Band Parametric EQ (`eq6`) | Output Gain |
| Graphic EQ (`geq`) | Output Gain |
| Filter Curve EQ (`fcurve`) | Output |
| Bass & Treble (`basstreble`) | Bass |
| Classic Filters (`classic`) | Cutoff |
| Warmth & Vocal Presence (`tone`) / Warmth (`warmth`) / Presence (`presence`) | Warmth / Warmth / Presence |
| Amplify (`amplify`) | Amplification |
| Normalize (`normalize`) | Target Peak |
| Loudness Normalization (`loudness`) | Target Loudness |
| Compressor (`dyncomp`) | Threshold |
| Compressor Pro (`comp`) | Compression |
| Multiband Compressor (`mbcomp`) | Overall Amount |
| Brickwall Limiter (`bricklim`) | Ceiling |
| Brickwall Limiter Pro (`limiter`) | Drive |
| Gate / Expander (`gateexp`) | Threshold |
| Auto Duck (`autoduck`) | Duck Amount |
| De-Esser (Split Band) (`deesssplit`) | Threshold |
| Noise Suppression Pro (`noise`) | Intensity |
| Spectral Noise Reduction (`specnr`) | Noise Reduction |
| Click Removal (`declick`) | Threshold |
| Clip Fix (`clipfix`) | Clipping Threshold |
| Repair (`repair`) | Prediction Order |
| De-Hum (`dehum`) | Base Frequency |
| Plosive & Breath Suppressor (`plosive`) | Plosive Cut Sensitivity |
| De-Esser Pro (`deess`) | Reduction |
| Room Gate Pro (`gate`) | Threshold |
| Studio Reverb (`reverb`) | Room Size |
| Multi-Echo Delay (`multidelay`) | Delay Time |
| Echo (`echo`) | Delay Time |
| Stereo Imaging (`stereoimg`) | Pan |
| Change Pitch (`changepitch`) | Semitones |
| Change Tempo (`tempo`) | Percent Change |
| Change Speed and Pitch (`speedpitch`) | Speed Multiplier |
| Sliding Stretch (`slidestretch`) | Initial Tempo Change |
| Paulstretch (`paulstretch`) | Stretch Factor |
| Distortion (`distort`) | Drive |
| Phaser (`phaser`) | Dry/Wet |
| Chorus & Flanger (`chorus`) | Wet/Dry Mix |
| Tremolo (`tremolo`) | Depth |
| Wahwah (`wah`) | Depth |
| Vocoder (`vocoder`) | Carrier Pitch |
| Fade (`fade`) | Length |
| Timeline Utility (`timeline`) | Number of Repeats |
| Truncate Silence (`truncsil`) | Threshold |
| Spectral Edit (`spectraledit`) | Gain |
| Audio Generator (`generator`) | Amplitude |

---

## Appendix B — If it sounds wrong, check this first

| Symptom | Likely cause | What to check |
|---|---|---|
| A control changes nothing | Effect is bypassed, the value is at its default, or the control is a secondary/advanced one | Toggle Bypass → Enable; open **Show advanced controls**; confirm you are moving the right control; check another source that exposes that dimension |
| Output clips/distorts after a boost | Too much gain in one stage | Lower the effect's output/gain or add the Brickwall Limiter Pro at the end; keep peaks around −1 dBFS |
| Clicks when dragging a control | Coefficient stepping or a level jump | Sweep slowly; on EQs/filters expect smooth glides; note the exact control and value where it clicks |
| Everything sounds metallic after denoising | Over-aggressive spectral reduction | Lower Intensity/Noise Reduction, raise smoothing, re-learn the profile from a quieter noise-only region |
| Repeats/tail cut off | Effect has a tail but the selection/render ends | Leave silence after the sound; check the delay/reverb tail setting; on Apply, include the tail in the selection |
| Pitch/time effect sounds broken | WSOLA/stretch artifacts at extreme settings | Reduce the amount; enable High-Quality Speech Mode (Change Tempo) or Preserve Formants (Change Pitch); test on longer material |
| Fade/truncate does nothing | The selection is too short or the silence threshold is wrong | Select more audio; lower the silence threshold; check Minimum Silence |
| Ringing/whistling in a filter | High resonance/Q | Reduce Q (Wah, Notch), use a gentler slope (Classic/HPF), or lower Feedback (Phaser) |
| Noise gate chops words | Threshold too high / hold too short | Lower Threshold, raise Hold, increase Release |
| Effect applies to the wrong part | Selection vs whole take | Clear or set the waveform selection; Apply uses the selection when one exists |
| Values reset after reopening | Slot not saved / effect deleted | Confirm Apply or Done saves the rack; check the slot still exists |

---

## Appendix C — Automated parameter matrix per effect

Each effect id below has its own CI shard and a local runner. The command is:

```bash
FX_EFFECT=<id> sh ./gradlew :app:testDebugUnitTest --tests '*FxParamMatrixDumpTest'
python3 tools/fxverify/analyze.py --cases app/build/fxverify/<id>
```

Effect ids (in rack categories):

- **EQ & Filters:** `hpf`, `highpass`, `lowpass`, `notch`, `shelf`, `eq6`, `geq`,
  `fcurve`, `basstreble`, `classic`, `tone`, `warmth`, `presence`
- **Dynamics & Mastering:** `amplify`, `normalize`, `loudness`, `dyncomp`, `comp`,
  `mbcomp`, `bricklim`, `limiter`, `gateexp`, `autoduck`, `deesssplit`
- **Noise Removal & Restoration:** `noise`, `specnr`, `declick`, `clipfix`,
  `repair`, `dehum`, `plosive`, `deess`, `gate`
- **Delay, Reverb & Spatial:** `reverb`, `multidelay`, `echo`, `stereoimg`
- **Pitch, Speed & Time:** `changepitch`, `tempo`, `speedpitch`, `slidestretch`,
  `paulstretch`
- **Distortion, Modulation & Creative:** `distort`, `phaser`, `chorus`, `tremolo`,
  `wah`, `vocoder`
- **Fades & Timeline Tools:** `fade`, `timeline`, `truncsil`, `spectraledit`
- **Generators & Analyzers:** `generator`

The matrix renders every parameter at min/default/max (every enum label and both
boolean states), against a probe chosen to expose that parameter, and compares it
to the dry render. Use it as the objective backstop to the listening checks in
this guide.

---

## Appendix D — 10-minute smoke test for the whole rack

1. Generate a 10 s pink-noise bed and a 10 s 1 kHz sine (Generator).
2. On pink noise, check the three EQs (`eq6`, `geq`, `fcurve`) and the filters
   (`hpf`, `highpass`, `lowpass`, `notch`, `shelf`) with one boost/cut each.
3. On speech, check `dyncomp`, `comp`, `gateexp`, `gate`, `deess`, and
   `loudness` at moderate settings; confirm bypass is transparent.
4. On a single clap, check `reverb`, `multidelay`, `echo` (tail, spacing,
   repeats) and `fade`/`timeline`/`truncsil`.
5. On a sustained vowel, check `chorus`, `phaser`, `tremolo`, `wah`, `vocoder`,
   `distort` (three curves + oversampling), `changepitch`, `tempo`,
   `speedpitch`, `slidestretch`, `paulstretch`.
6. On a noisy take, check `noise` and `specnr` (learn from a noise-only
   selection), `dehum`, `plosive`, `declick`, `clipfix`, `repair`.
7. Finally, stack a compressor → EQ → limiter and confirm rack order matters:
   swap the EQ and limiter and hear the difference.

If every step produces the change described in the tables above, and bypass is
transparent at defaults, the rack is healthy. Any deviation is a bug worth
writing down with: effect id, control, value, source, and expected vs actual.

---

*Generated from the processor parameter definitions in
`app/src/main/java/com/takeone/studio/*Processor.java`; ranges and defaults match
the code. If you add or change a parameter, update the corresponding table and
the `tools/fxverify` matrix.*

