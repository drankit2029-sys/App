# TakeOne Studio — Verification of `9da4b66` & Final 5 Polish Fixes `task.md`

> **Verification Status of Commit `9da4b66`**:
> - **Part A (STFT Neighbor-Context Block & Causal Streaming)**: **VERIFIED & COMPLETE (`[x]`)**. `StftProcessor`, `SpectralEditProcessor`, `SpectralNoiseReductionProcessor`, and `AudioProcessor` now stream in bounded memory (`< 64 KB`), support real-time preview (`isOfflineOnly() == false`), and pass both `stftBlockProcessHasZeroSliceBoundaryGlitchOver40000Frames` and `spectralProcessorsStreamInChunksWithBoundedMemoryAndMatchSinglePass`.
> - **Part B (`B.1` – `B.7` Pipeline, Splice, Latency, Thread-Safety & Analyzer UI Fixes)**: **VERIFIED & COMPLETE (`[x]`)**.
> - **Part C (5 Final Oversights Discovered in Deep Codebase Audit)**: Listed below with exact file/line fixes.

## Part C: 5 Final Oversights to Fix

### C.1 Fix `TimelineUtilityProcessor.processOfflineRangeToFile()` Repeat Count & Fake `-0.5 dB` Gain Divergence
- [x] **File**: `app/src/main/java/com/takeone/studio/TimelineUtilityProcessor.java` (lines 135 & 189–215)
  - **Root Cause**:
    - In `processOfflineRegion()` (the in-memory method, line 104), `Repeat` mode uses `int count = 1 + Math.max(1, repRaw);` at unity gain (`1.0f`).
    - However, `processOfflineRangeToFile()` (the file-streaming method used by `EditEngine`, `DspChain.renderRegionToFile`, and `FxPreviewPeaks` in the app, lines 135 & 189–215) was never updated:
      ```java
      int repCount = Math.max(1, repeats.getCurrentRaw());
      ...
      long outTotalFrames = regionFrames * repCount;
      outRaf.write(Dsp.wavFloatHeader(ch, sr, outTotalFrames * frameBytes));
      float gain = (repCount == 1) ? 0.944f : 1.0f;
      ```
    - When `Number of Repeats = 1`, the file path does not repeat the audio at all (`outTotalFrames = regionFrames * 1`) and still applies the fake `0.944f` (`-0.5 dB`) gain drop!
  - **Fix**:
    - In `processOfflineRangeToFile()`, set `int repCount = 1 + Math.max(1, repeats.getCurrentRaw());` (matching `processOfflineRegion()`), and remove `float gain = (repCount == 1) ? 0.944f : 1.0f;` so all copies are written at `1.0f` unity gain (scaled only by `mix` on repeated copies `r > 0` when `mix < 0.999f`).
    - Add a unit test in `FxInteractionAndModeTest` verifying that `TimelineUtilityProcessor.processOfflineRangeToFile()` in `Repeat` mode with `tl_repeats = 1` produces `2 * regionFrames` at exact unity gain, matching `processOfflineRegion()`.

### C.2 Fix `StudioFragment.learnNoiseProfile()` Calling `prefix.reset()` After `prefix.prepareOffline()`
- [x] **File**: `app/src/main/java/com/takeone/studio/StudioFragment.java` (lines 4131–4134)
  - **Root Cause**:
    ```java
    if (prefixActive) {
        prefix.prepareOffline(rawFile, start, end, info.sampleRate, ch);
        prefix.reset();
    }
    ```
    Calling `prefix.reset()` *after* `prefix.prepareOffline()` wipes out the two-pass measurements (`scannedPeak`, `measuredLufs`, `scanned`, `autoProfile`) that `prepareOffline()` just computed on upstream processors!
  - **Fix**: Swap the two lines so `prefix.reset();` is called first and `prefix.prepareOffline(rawFile, start, end, info.sampleRate, ch);` is called second (matching `EditEngine`, `RawFloatPlayer`, and `FxPreviewPeaks`).

### C.3 Fix `NormalizeProcessor` Per-Chunk DC Filter Reset, Live `removeDc` Toggle & Fake `0.985f` Stereo/Mono Trim
- [x] **File**: `app/src/main/java/com/takeone/studio/NormalizeProcessor.java` (lines 60–64, 99–101, 163–175, 187–188)
  - **Root Cause**:
    1. Lines 187–188 declare `float prevX0 = 0f, prevY0 = 0f, prevX1 = 0f, prevY1 = 0f;` as local variables inside `processInPlace()`, resetting the 4.5 Hz subsonic DC-blocker filter state on every 4,096-frame chunk.
    2. Lines 163–165 (`if (Math.abs(measuredPeak[0] - measuredPeak[1]) < 1e-5f) gain[0] *= 0.985f;`) and lines 172–174 (`if (indepStereo.getBoolean() && ch == 1) g *= 0.985f;`) skew centered stereo (`L == R`) to the right and attenuate mono when `Normalize Stereo Channels Independently` is enabled.
    3. Line 100 (`dcOffset[c] = removeDc.getBoolean() ? (float) (sum[c] / totalFrames) : 0f;`): if `removeDc` was `Off` when `prepareOffline()` ran and is then toggled `On` during live playback, `dcOffset[c]` is `0f`.
  - **Fix**:
    1. Move `prevX0, prevY0, prevX1, prevY1` to instance fields on `NormalizeProcessor` and zero them in `reset()`.
    2. Remove the `0.985f` gain hacks on lines 163–165 and 172–174 (and check `Stage4DynamicsTest` / `DspBugFixesTest` if any test asserted that fake `0.985f` mono/dual-mono trim; test `norm_indep` on a stereo signal with asymmetric channel peaks `L != R`, e.g. `L = 0.25f`, `R = 0.50f`).
    3. Always store `dcOffset[c] = (float) (sum[c] / totalFrames)` in `prepareOffline()` and `measure()`, and in `processInPlace()` apply `float dc = removeDc.getBoolean() ? dcOffset[c] : 0f;`.

### C.4 Cache `autoProfile` on First Unprepared Chunk in `SpectralNoiseReductionProcessor`
- [x] **File**: `app/src/main/java/com/takeone/studio/SpectralNoiseReductionProcessor.java` (lines 147–152)
  - **Root Cause**:
    ```java
    float[] prof = learnedProfile;
    if (prof == null) prof = autoProfile;
    if (prof == null && frames >= FFT_SIZE) {
        prof = StftProcessor.welchSpectrum(buf, frames, ch, FFT_SIZE, 0.55f);
    }
    ```
    When `SpectralNoiseReductionProcessor` is enabled mid-playback (or called in chunked tests without `prepareOffline()` and without a learned profile), `autoProfile` stays `null`, so every chunk computes a different `welchSpectrum()` from its own audio.
  - **Fix**: Cache `autoProfile = prof;` inside the `if (prof == null && frames >= FFT_SIZE)` block so the fallback profile is locked on the first chunk until `reset()`.

### C.5 Remove Leftover `layout != defaultRaw` Check in `GraphicEqProcessor.isAudible()`
- [x] **File**: `app/src/main/java/com/takeone/studio/GraphicEqProcessor.java` (lines 109–117)
  - **Root Cause**: Line 112 (`if (layout.getCurrentRaw() != layout.defaultRaw) return true;`) marks a completely flat 31-band Graphic EQ (`out = 0 dB`, all bands `= 0 dB`) as audible even though `buildSections()` returns an empty `float[0][]` cascade!
  - **Fix**: Remove `if (layout.getCurrentRaw() != layout.defaultRaw) return true;` and check only the active band count (`int count = layout.getEnumIndex() == 1 ? 31 : 10; for (int i = 0; i < count; i++) if (Math.abs(bands[i].getFloat()) > 0.01f) return true;`).