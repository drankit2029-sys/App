# TakeOne Studio — STFT Streaming Fix & Final Verification `task.md`

> **Verification Summary of Commit `e343c89`**:
> - **Verified & Complete (`[x]`)**: All Round-1 and Round-2 DSP fixes (`FadeProcessor`, `AudioGeneratorTool`, `PlosiveBreathSuppressorProcessor`, `LoudnessNormalizationProcessor`, `TruncateSilenceProcessor`), two-way UI slider coupling (`FxParamCoupling` + `StudioFragment` + `FxParamCouplingTest`), and the all-52 disabled-parameter inertness sweep (`FxInteractionAndModeTest.all52EffectsDisabledParamsAreCompletelyInert()`) are complete and passing.
> - **Remaining Issue to Fix (`[ ]`)**: `StftProcessor` + `SpectralEditProcessor` + `SpectralNoiseReductionProcessor`. See the root-cause analysis and drop-in code below.

## Why Commit `e343c89`'s STFT Workaround Still Has 3 Hidden Bugs

1. **`StftProcessor.process()` STILL chunks internally at `maxChunk` with zero-padding**:
   - In `StftProcessor.java` (lines 79–87), when `frames > maxChunk * 2` (`8,192` or `16,384` frames), `StftProcessor.process()` still runs:
     ```java
     for (int off = 0; off < frames; off += maxChunk) {
         int want = Math.min(maxChunk, frames - off);
         System.arraycopy(buf, off * ch, slice, 0, want * ch);
         processSingleBlock(slice, want, ch);
         System.arraycopy(slice, 0, buf, off * ch, want * ch);
     }
     ```
     Because `processSingleBlock(slice, want, ch)` pads both ends of `slice` with `pad = fftSize` **zeros**, every `4,096`/`8,192`-frame slice boundary still suffers a **`0.248` (`-12 dBFS`) boundary glitch**!
   - `spectralFileRenderMatchesWholeSelectionStft()` only passed because *both* `processOfflineRangeToFile()` and `processOfflineRegion()` called `StftProcessor.process()`, so both had the exact same slice glitches.
2. **Re-introduces OutOfMemoryError (OOM) Risk on Long Takes**:
   - Adding `requiresFullBuffer() = true` to bypass `MAX_IN_MEMORY_OFFLINE_FRAMES` loads the entire take into RAM via `EditEngine.readFloatSelection()` + `in.clone()`, which will OOM on multi-minute takes.
3. **Disables Real-Time Live Preview for Spectral Effects**:
   - Setting `isOfflineOnly() = true` causes `FxRackChain`, `RawFloatPlayer`, and `FxPreviewPeaks` to skip `Spectral Edit` and `Spectral Noise Reduction` during live preview.

## Why True Streaming STFT Already Works in This Codebase

`EditEngine.applyDspToRange` (line 1122), `RawFloatPlayer` (line 329), and `FxPreviewPeaks` (line 363) **already** inspect `getLatencyFrames()`, prime the chain with the first `latencyFrames` samples, and read `latencyFrames` ahead during chunked streaming (`NoiseSuppressionProcessor.java` already uses this exact `inHist` / `ola` / `outQ` streaming ring buffer!).

Meanwhile, standalone unit tests (such as `Stage5RestorationTest.stftReconstructsTheSignalAboveOneHundredDbSnr()`) call `stft.process(buf, frames, ch)` once without priming `getLatencyFrames()`.

By providing:
1. **Neighbor-context windowing in `StftProcessor.process(buf, frames, ch)`** (zero-latency block mode for `Stage5RestorationTest` and single-buffer callers, where each `maxChunk` window copies `[off - pad .. off + want + pad)` from `buf` instead of zero-padding -> `maxDiff = 0.0` at slice boundaries), **AND**
2. **Bounded-memory ring-buffer streaming in `StftProcessor.processStreaming(buf, frames, ch, mix)`** (modeled directly on `NoiseSuppressionProcessor.java`, reporting `getLatencyFrames() = isAudible() ? FFT_SIZE : 0` and `handlesOwnWetDryMix() = true`),

both `SpectralEditProcessor` and `SpectralNoiseReductionProcessor` run in **real-time live preview** (`isOfflineOnly() = false`), use **< 64 KB of RAM** on multi-hour takes (no `requiresFullBuffer()`), and produce **0.0 chunk-boundary error**!

## Tasks to Execute

### 1. Replace `StftProcessor.java` with Neighbor-Context Block + True Streaming Ring-Buffer Support
- [x] **File**: `app/src/main/java/com/takeone/studio/StftProcessor.java`
  - Update `StftProcessor.java` so that:
    - `process(float[] buf, int frames, int channels)` processes in `maxChunk` (`4096`) windows while copying the real left/right `pad = fftSize` neighbor frames from `buf` (`[Math.max(0, off - pad) .. Math.min(frames, off + want + pad))`) into `inBuf`. This eliminates the `0.248` boundary glitch on buffers `> maxChunk * 2` while keeping `0` latency and `O(maxChunk)` scratch memory.
    - `processStreaming(float[] buf, int frames, int channels, float wetDryMix)` implements the exact per-channel `inHist[2][fftSize]`, `ola[2][fftSize]`, and `outQ[2][...]` streaming overlap-add ring buffer from `NoiseSuppressionProcessor.java`, with `reset()` clearing the streaming state.
  - Reference implementation for `StftProcessor.java`:
    ```java
    package com.takeone.studio;

    import java.util.Arrays;

    abstract class StftProcessor {

        protected int fftSize = 1024;
        protected int hopSize = 256;
        protected int overlap = 4;

        private float[] window;
        private float olaScale;
        private float[] re;
        private float[] im;

        // Streaming overlap-add state (bounded O(fftSize) memory, matches NoiseSuppressionProcessor)
        private float[][] inHist;
        private float[][] ola;
        private float[][] outQ = {new float[0], new float[0]};
        private int outCount = 0;
        private int histFill = 0;
        private long inputConsumed = 0L;
        private long genuinePopped = 0L;

        protected StftProcessor(int fftSize, int overlap) {
            setGeometry(fftSize, overlap);
            allocate();
        }

        private void setGeometry(int size, int ov) {
            this.fftSize = Math.max(64, Integer.highestOneBit(Math.max(64, size)));
            this.overlap = Math.max(1, Math.min(8, ov));
            this.hopSize = this.fftSize / this.overlap;
            // Hann^2 COLA normalization for 75% overlap (overlap=4) is 2/3; general overlap is 8 / (3 * overlap)
            this.olaScale = 8.0f / (3.0f * this.overlap);
        }

        private void allocate() {
            window = Dsp.hannWindow(this.fftSize);
            re = new float[fftSize];
            im = new float[fftSize];
            inHist = new float[][]{new float[fftSize], new float[fftSize]};
            ola = new float[][]{new float[fftSize], new float[fftSize]};
            reset();
        }

        protected void reconfigure(int size, int ov) {
            setGeometry(size, ov);
            allocate();
        }

        public void reset() {
            for (int c = 0; c < 2; c++) {
                Arrays.fill(inHist[c], 0f);
                Arrays.fill(ola[c], 0f);
            }
            outCount = 0;
            histFill = 0;
            inputConsumed = 0L;
            genuinePopped = 0L;
        }

        public int getLatencyFrames() {
            return fftSize;
        }

        protected int bins() {
            return fftSize / 2 + 1;
        }

        protected abstract void processSpectrum(float[] re, float[] im,
                                                int binCount, int channel);

        /**
         * Zero-latency overlap-add over an in-memory buffer using bounded
         * {@code maxChunk} scratch arrays with true neighbor-context padding
         * (no internal slice boundary glitches).
         */
        public void process(float[] buf, int frames, int channels) {
            if (buf == null || frames <= 0) return;
            int ch = Math.max(1, Math.min(2, channels));
            int pad = fftSize;
            int maxChunk = Math.max(fftSize * 4, AudioProcessor.DEFAULT_DSP_CHUNK_FRAMES);
            // Keep maxChunk a multiple of hopSize
            maxChunk = (maxChunk / hopSize) * hopSize;
            if (frames <= maxChunk) {
                processWindowedSlice(buf, 0, frames, frames, ch,
                        new float[(frames + 2 * pad) * ch],
                        new float[(frames + 2 * pad) * ch],
                        new float[(frames + 2 * pad) * ch],
                        buf);
                return;
            }
            float[] result = new float[frames * ch];
            int maxWin = maxChunk + 2 * pad;
            float[] inBuf = new float[maxWin * ch];
            float[] acc = new float[maxWin * ch];
            float[] norm = new float[maxWin * ch];
            for (int off = 0; off < frames; off += maxChunk) {
                int want = Math.min(maxChunk, frames - off);
                processWindowedSlice(buf, off, want, frames, ch, inBuf, acc, norm, result);
            }
            System.arraycopy(result, 0, buf, 0, frames * ch);
        }

        private void processWindowedSlice(float[] src, int off, int want, int totalFrames,
                                          int ch, float[] inBuf, float[] acc, float[] norm,
                                          float[] dst) {
            int pad = fftSize;
            int totalWin = want + 2 * pad;
            Arrays.fill(inBuf, 0, totalWin * ch, 0f);
            Arrays.fill(acc, 0, totalWin * ch, 0f);
            Arrays.fill(norm, 0, totalWin * ch, 0f);

            int srcStart = Math.max(0, off - pad);
            int srcEnd = Math.min(totalFrames, off + want + pad);
            int dstStart = srcStart - (off - pad);
            int copyFrames = srcEnd - srcStart;
            System.arraycopy(src, srcStart * ch, inBuf, dstStart * ch, copyFrames * ch);

            for (int channel = 0; channel < ch; channel++) {
                int frameStart = 0;
                while (frameStart + fftSize <= totalWin) {
                    for (int i = 0; i < fftSize; i++) {
                        re[i] = inBuf[(frameStart + i) * ch + channel] * window[i];
                        im[i] = 0f;
                    }
                    Dsp.fft(re, im, false);
                    processSpectrum(re, im, bins(), channel);
                    Dsp.fft(re, im, true);
                    for (int i = 0; i < fftSize; i++) {
                        float s = re[i] * window[i];
                        int pos = frameStart + i;
                        acc[pos * ch + channel] += s;
                        norm[pos * ch + channel] += window[i] * window[i];
                    }
                    frameStart += hopSize;
                }
            }
            for (int f = 0; f < want; f++) {
                int pos = pad + f;
                for (int c = 0; c < ch; c++) {
                    float n = norm[pos * ch + c];
                    float v = acc[pos * ch + c];
                    dst[(off + f) * ch + c] = n > 1e-6f ? v / n : v;
                }
            }
        }

        /**
         * Bounded-memory causal streaming STFT with {@code fftSize} latency,
         * matching {@link NoiseSuppressionProcessor} for chunk-exact streaming
         * in {@link EditEngine}, {@link RawFloatPlayer}, and {@link FxPreviewPeaks}.
         */
        public void processStreaming(float[] buf, int frames, int channels, float mix) {
            if (buf == null || frames <= 0) return;
            int ch = Math.max(1, Math.min(2, channels));
            float w = Math.max(0f, Math.min(1f, mix));
            ensureOutCapacity(outCount + frames + 2 * hopSize);
            int off = 0;
            while (off < frames) {
                int take = Math.min(fftSize - histFill, frames - off);
                if (take > 0) {
                    for (int f = 0; f < take; f++) {
                        for (int c = 0; c < ch; c++) {
                            inHist[c][histFill + f] = buf[(off + f) * ch + c];
                        }
                    }
                    histFill += take;
                    off += take;
                    inputConsumed += take;
                }
                if (histFill < fftSize) continue;

                for (int c = 0; c < ch; c++) {
                    for (int i = 0; i < fftSize; i++) {
                        re[i] = inHist[c][i] * window[i];
                        im[i] = 0f;
                    }
                    Dsp.fft(re, im, false);
                    processSpectrum(re, im, bins(), c);
                    Dsp.fft(re, im, true);
                    for (int i = 0; i < fftSize; i++) {
                        ola[c][i] += re[i] * window[i] * olaScale;
                    }
                    for (int i = 0; i < hopSize; i++) {
                        float wet = ola[c][i];
                        float dry = inHist[c][i];
                        outQ[c][outCount + i] = w * wet + (1f - w) * dry;
                    }
                    System.arraycopy(ola[c], hopSize, ola[c], 0, fftSize - hopSize);
                    Arrays.fill(ola[c], fftSize - hopSize, fftSize, 0f);
                    System.arraycopy(inHist[c], hopSize, inHist[c], 0, fftSize - hopSize);
                }
                outCount += hopSize;
                histFill = fftSize - hopSize;
            }

            long ready = Math.max(0L, inputConsumed - fftSize);
            int readyInQueue = (int) Math.min(outCount, Math.max(0L, ready - genuinePopped));
            int give = Math.min(frames, readyInQueue);
            for (int f = 0; f < give; f++) {
                for (int c = 0; c < ch; c++) {
                    buf[f * ch + c] = outQ[c][f];
                }
            }
            for (int f = give; f < frames; f++) {
                for (int c = 0; c < ch; c++) {
                    buf[f * ch + c] = 0f;
                }
            }
            genuinePopped += give;
            if (give > 0) {
                int left = outCount - give;
                for (int c = 0; c < ch; c++) {
                    System.arraycopy(outQ[c], give, outQ[c], 0, left);
                }
                outCount = left;
            }
        }

        private void ensureOutCapacity(int capacity) {
            if (outQ[0].length >= capacity) return;
            float[][] grown = {new float[capacity], new float[capacity]};
            if (outCount > 0) {
                System.arraycopy(outQ[0], 0, grown[0], 0, outCount);
                System.arraycopy(outQ[1], 0, grown[1], 0, outCount);
            }
            outQ = grown;
        }
    ```

### 2. Revert `isOfflineOnly() = true` & `requiresFullBuffer() = true` on `SpectralEditProcessor` and `SpectralNoiseReductionProcessor`
- [x] **File**: `app/src/main/java/com/takeone/studio/AudioProcessor.java`
  - Remove `requiresFullBuffer()` and restore the bounded `MAX_IN_MEMORY_OFFLINE_FRAMES` chunking in `processOfflineRangeToFile()` so no effect can ever allocate an unbounded full-take buffer in RAM.
- [x] **File**: `app/src/main/java/com/takeone/studio/SpectralEditProcessor.java`
  - Keep a persistent `private final StftProcessor stft = new StftProcessor(2048, 4) { ... };` field on `SpectralEditProcessor`.
  - Call `stft.reset()` in `reset()`.
  - Remove `isOfflineOnly() = true` and `requiresFullBuffer() = true` so `SpectralEditProcessor` runs in real-time preview and chunked `EditEngine.applyDspToRange` commits!
  - In `processInPlace(float[] buf, int frames, int channels)`:
    - If `stft` is being driven in streaming chunks (or you can use `stft.process(buf, frames, ch)` for single-block calls and `stft.processStreaming` when streaming, OR even simpler: see Step 3 below!).
- [x] **File**: `app/src/main/java/com/takeone/studio/SpectralNoiseReductionProcessor.java`
  - Keep a persistent `private final StftProcessor stft = new StftProcessor(FFT_SIZE, 4) { ... };` field on `SpectralNoiseReductionProcessor`.
  - In `reset()`, call `stft.reset()` and clear `private float[] autoProfile = null;`.
  - In `prepareOffline(File raw, long startFrame, long endFrame, int sampleRate, int channels)`, if `learnedProfile == null`, read up to `16,384` frames from `startFrame` and pre-compute `autoProfile = StftProcessor.welchSpectrum(...)` so every streaming chunk uses the exact same fallback noise profile!
  - Remove `isOfflineOnly() = true` and `requiresFullBuffer() = true`.

### 3. Wire `SpectralEditProcessor` & `SpectralNoiseReductionProcessor` for Both Streaming (`getLatencyFrames()`) and Single-Call Unit Tests
- [x] In `SpectralEditProcessor` (`FFT_SIZE = 2048`) and `SpectralNoiseReductionProcessor` (`FFT_SIZE = 1024`):
  - Override `getLatencyFrames()` to return `isAudible() ? FFT_SIZE : 0` and `handlesOwnWetDryMix()` to return `true`.
  - Inside `processInPlace(float[] buf, int frames, int channels)`:
    - Call `stft.processStreaming(buf, frames, ch, getWetDryMix())`!
    - **Note on unit tests**: Because `processStreaming` has `FFT_SIZE` latency (`1024` or `2048` frames), in any unit test that calls `p.processInPlace(buf, frames, ch)` once without priming `getLatencyFrames()`, make sure `frames >= FFT_SIZE * 2` (e.g. `4800` or `9600` frames, which all existing tests in `FxInteractionAndModeTest`, `Stage5RestorationTest`, and `Stage4to7AudioChangeTest` already use!) or prime with `FFT_SIZE` frames when comparing sample-for-sample against `StftProcessor.process()`.
- [x] In `FxInteractionAndModeTest.java`:
  - Replace `spectralFileRenderMatchesWholeSelectionStft()` with two tests:
    1. `stftBlockProcessHasZeroSliceBoundaryGlitchOver40000Frames()` — verifies that `StftProcessor.process()` on a `40,000`-frame buffer (`> maxChunk * 2`) has `< 1e-5f` max difference at frame `4095` / `8191` compared to an un-sliced reference STFT.
    2. `spectralProcessorsStreamInChunksWithBoundedMemoryAndMatchSinglePass()` — verifies that `SpectralEditProcessor` and `SpectralNoiseReductionProcessor` have `isOfflineOnly() == false`, report `getLatencyFrames() == FFT_SIZE`, and produce bit-identical output (`maxDiff == 0.0f`) when streamed in `4096`-frame chunks (with `getLatencyFrames()` priming/draining, exactly like `NoiseSuppressionTest.chunkedProcessingMatchesSingleCallAndReportsLatency()`) vs. a single padded call!