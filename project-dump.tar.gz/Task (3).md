# TakeOne Studio — STFT Streaming + UI, Effect Pipeline & Concurrency Fix `task.md`

> **Instructions for the AI Agent**:
> Work through Part A (STFT Streaming & Neighbor-Context Fix) and Part B (7 Critical UI, Effect Pipeline & Concurrency Bugs) sequentially. Mark each item `- [x]` once verified by `./gradlew testDebugUnitTest lintDebug`.

## Part A: STFT Neighbor-Context Block & Bounded-Memory Streaming Fix

### A.1 Why Commit `e343c89`'s STFT Workaround Must Be Replaced
1. **`StftProcessor.process()` still chunks internally at `maxChunk` with zero-padding**:
   - In `StftProcessor.java` (lines 79–87), when `frames > maxChunk * 2`, `StftProcessor.process()` slices `buf` into isolated `maxChunk` blocks and runs `processSingleBlock(slice, want, ch)` with zero-padding at both ends of each slice, causing a `0.248` (`-12 dBFS`) boundary glitch at frame `4095`/`8191`.
2. **OOM Risk on Long Takes**:
   - `requiresFullBuffer() = true` bypasses `MAX_IN_MEMORY_OFFLINE_FRAMES` (`32,768` frames) and reads the entire selection into a single `float[]` in RAM (`EditEngine.readFloatSelection()` + `in.clone()`), which will OOM on multi-minute takes.
3. **Lost Real-Time Live Preview**:
   - Setting `isOfflineOnly() = true` causes `FxRackChain`, `RawFloatPlayer`, and `FxPreviewPeaks` to skip `Spectral Edit` and `Spectral Noise Reduction` during live preview.

### A.2 Replace `StftProcessor.java` & Restore Streaming on `SpectralEditProcessor` / `SpectralNoiseReductionProcessor`
- [x] **File**: `app/src/main/java/com/takeone/studio/StftProcessor.java`
  - In `process(float[] buf, int frames, int channels)` (zero-latency block mode used by `Stage5RestorationTest.stftReconstructsTheSignalAboveOneHundredDbSnr()`):
    - When `frames > maxChunk`, process in `maxChunk` (`4096`) windows, but for each window `[off .. off + want)`, copy the actual neighbor context `[Math.max(0, off - pad) .. Math.min(frames, off + want + pad))` from `buf` into `inBuf` instead of zero-padding at `off` and `off + want`. This reduces the slice boundary error on a 40,000-frame buffer from `0.248` to **`0.0`** while keeping `0` latency and `O(maxChunk)` scratch memory.
  - Add `processStreaming(float[] buf, int frames, int channels, float wetDryMix)` and `reset()`:
    - Use the exact per-channel `inHist[2][fftSize]`, `ola[2][fftSize]`, and `outQ[2][...]` streaming overlap-add ring buffer already proven in `NoiseSuppressionProcessor.java` (`olaScale = 8.0f / (3.0f * overlap)`), with `getLatencyFrames() = fftSize`.
- [x] **File**: `app/src/main/java/com/takeone/studio/AudioProcessor.java`
  - Remove `requiresFullBuffer()` and restore the strict `MAX_IN_MEMORY_OFFLINE_FRAMES` bound in `processOfflineRangeToFile()`.
- [x] **Files**: `SpectralEditProcessor.java` & `SpectralNoiseReductionProcessor.java`
  - Keep a persistent `StftProcessor stft` instance field on both processors and call `stft.reset()` inside `reset()`.
  - Remove `isOfflineOnly() = true` and `requiresFullBuffer() = true`.
  - Override `getLatencyFrames()` to return `isAudible() ? FFT_SIZE : 0` and `handlesOwnWetDryMix()` to return `true`.
  - In `SpectralNoiseReductionProcessor`, cache `private float[] autoProfile` on the first block after `reset()` (and pre-compute it in `prepareOffline()` when `learnedProfile == null`) so all 4,096-frame chunks use the exact same fallback noise profile.
  - In `processInPlace(float[] buf, int frames, int channels)`:
    - If `frames` is being streamed via `EditEngine` / `RawFloatPlayer` / `FxPreviewPeaks` (or whenever `stft.processStreaming` is used), note that standalone unit tests that call `p.processInPlace(buf, frames, ch)` once without priming `getLatencyFrames()` can either prime `FFT_SIZE` frames or `processInPlace` can use `stft.processStreaming(buf, frames, ch, getWetDryMix())` (all existing tests in `Stage5RestorationTest`, `Stage4to7AudioChangeTest`, and `FxInteractionAndModeTest` use `frames >= 4800 > FFT_SIZE`).

## Part B: Fix 7 Critical UI, Effect Pipeline & Concurrency Bugs

### B.1 Fix `EditEngine.applyLengthChangingEffectToRange` Deleting 240 Frames (`5 ms`) on Sub-Selection Offline Edits
- [x] **File**: `app/src/main/java/com/takeone/studio/EditEngine.java` (lines 1020–1062)
  - **Root Cause**:
    - `saveTailFrom(raw, endFrame, tailTmp, false)` saves `[endFrame, totalFrames)` (`tailFrames = totalFrames - endFrame`).
    - Then `spliceTailAfterReplace(raw, newEnd, tailTmp)` overlaps `tailTmp[0..240)` (`[endFrame, endFrame + 240)`) backwards onto `[newEnd - 240, newEnd)` and writes `newTotal = newEnd + tailFrames - 240`!
    - Whenever the user applies any non-length-changing offline effect (`Fade`, `Timeline Invert`, `Timeline Reverse`, `Change Pitch`) to a sub-selection (`endFrame < totalFrames`), **the file shrinks by 240 frames (5 ms) and every sample after the selection shifts 240 frames earlier in time!** Also `startFrame` has no crossfade at all.
  - **Fix**:
    1. Before overwriting `raw` at `startFrame`, if `startFrame > 0`, read `headFade = (int) Math.min(Dsp.CROSSFADE_FRAMES, Math.min(selFrames / 2, newFrames / 2))` dry frames starting at `startFrame` (`origHead`) and `tailFade = (endFrame < totalFrames) ? headFade : 0` dry frames ending at `endFrame` (`origTail`, from `[endFrame - tailFade, endFrame)`).
    2. In `undo.recordRangeSnapshot(...)`, record `[startFrame, endFrame)` (since `startFrame` and `endFrame` are the exact splice boundaries and `tailTmp` starts at `endFrame`).
    3. Write all `newFrames` of `renderTmp` at `startFrame .. startFrame + newFrames`, crossfading the first `headFade` frames of `renderTmp` (`0 -> 1`) against `origHead` (`1 -> 0`) and the last `tailFade` frames of `renderTmp` (`1 -> 0`) against `origTail` (`0 -> 1`).
    4. Append `tailTmp` (`[endFrame, totalFrames)`) directly at `newEnd = startFrame + newFrames` **without** pulling `tailTmp` backwards by 240 frames! Now `newTotal = startFrame + newFrames + tailFrames`, so `newFrames == selFrames` preserves the exact file length `totalFrames` down to the sample!

### B.2 Fix Undo Corruption When Combining Offline Effects + In-Place Tail Effects (`Reverb` / `Echo` / `MultiDelay`)
- [x] **File**: `app/src/main/java/com/takeone/studio/StudioFragment.java` (lines 5902–5935)
  - **Root Cause**:
    - In `commitDspFx()`, when `!offline.isEmpty()` and `chain.hasInPlaceProcessors()`, `applyLengthChangingEffectToRange` only records an undo snapshot up to `end` (or `end + 240`), and then `EditEngine.applyDspToRange(raw, start, regionEnd, inPlace, null)` runs with `undo = null` and writes up to `96,000` frames (`2 seconds`) of reverb/delay tail past `regionEnd` into `[regionEnd, regionEnd + tailFrames)`.
    - Tapping **Undo** restores `[start, end)` and shifts the tail back, leaving the 2-second reverb/delay tail permanently baked into the dry audio after `end`!
  - **Fix**:
    - Before the `for (AudioProcessor proc : offline)` loop in `commitDspFx()`, compute:
      ```java
      DspChain inPlaceProbe = chain.hasInPlaceProcessors()
              ? new DspChain(info.channels, dspConfig) : null;
      if (inPlaceProbe != null) inPlaceProbe.clearOfflineProcessors();
      int inPlaceTail = inPlaceProbe != null ? Math.max(0, inPlaceProbe.getTailFrames()) : 0;
      ```
    - Record a single undo range snapshot on `uj` upfront covering `[Math.max(0L, start - Dsp.CROSSFADE_FRAMES), Math.min(totalFrames, end + Dsp.CROSSFADE_FRAMES + inPlaceTail))` and pass `null` as the `UndoJournal` to every `applyLengthChangingEffectToRange` and `applyDspToRange` call inside that commit.

### B.3 Fix `RawFloatPlayer` Live Preview Latency Double-Play / Stutter Bug
- [x] **File**: `app/src/main/java/com/takeone/studio/RawFloatPlayer.java` (lines 328–344 & 394–430)
  - **Root Cause**:
    - When `preChain.offlineProcessors().isEmpty()` and `lat = preChain.getLatencyFrames() > 0` (`NoiseSuppressionProcessor`, `FilterCurveEqProcessor`, `BrickwallLimiterProcessor`, `SpectralEditProcessor`, `SpectralNoiseReductionProcessor`), lines 329–341 prime `preChain` with frames `[startFramePos .. startFramePos + lat)`.
    - Then the main playback loop (line 394) starts reading at `framePos = startFramePos` again instead of `framePos + lat`! As a result, the first `lat` frames (`2048` frames = `43 ms`) are fed into `preChain` **twice** (causing an audible double-play stutter at the start of playback) and the last `lat` frames before `limitFrame` are never drained!
  - **Fix**:
    - Track `int primedLatency = 0;` when priming `preChain` (lines 329–341).
    - In the main playback loop (`while (!stop && framePos < limitFrame)`), read from `long inStart = framePos + primedLatency;` (clamping available file frames to `limitFrame` and padding any remaining `want - fromFile` tail frames with post-context or `0f`, identical to `EditEngine.java` lines 1165–1182 and `FxPreviewPeaks.java` lines 402–425).
- [x] **File**: `app/src/main/java/com/takeone/studio/DspChain.java` (`renderRegionToFile`, lines 1554–1585)
  - In `DspChain.renderRegionToFile()`, when `hasInPlaceProcessors() && curFrames > 0`, also prime `int lat = Math.max(0, getLatencyFrames());` before the `while (off < curFrames)` loop and read `off + lat` ahead (padding with `0f` past `curFrames`), so combining an offline effect with a latency-reporting in-place effect (`Noise Suppression Pro`, `Filter Curve EQ`, `Brickwall Limiter`) never prepends `lat` frames of silence!

### B.4 Fix Live Scrubbing Thread-Safety & UI-Thread FFT Stall (`DspChain`, `BiquadFilter`, `FilterCurveEqProcessor`)
- [x] **File**: `app/src/main/java/com/takeone/studio/DspChain.java` & `FxRackChain.java`
  - **Root Cause**:
    - During live playback, `StudioFragment` calls `livePreviewDsp.updateConfig(dspConfig)` on the UI thread on every slider scrub event while `RawFloatPlayer` calls `dspChain.processInPlace(buf, want)` on the audio thread.
    - `DspChain.updateConfig()` calls `resetProcessorSlotExtras()`, which temporarily sets every processor's `wetDryMix = 1.0f`, clears `noiseProfile = null`, and resets all secondary parameters to `defaultRaw` before `applySlotExtras(cfg)` restores them! Because `updateConfig()` and `processInPlace()` are unsynchronized, the audio thread frequently processes chunks right in the middle of `updateConfig()`, causing sudden 100%-wet default-parameter blasts!
  - **Fix**:
    - Synchronize `updateConfig(Config)`, `processInPlace(float[], int)`, `reset()`, `setSampleRate(int)`, and `prepareOffline(...)` on a shared lock (`synchronized (rack)`) in `DspChain` (and `FxRackChain`).
- [x] **File**: `app/src/main/java/com/takeone/studio/BiquadFilter.java`
  - Make `setSections`, `reset`, and `process` `synchronized` (or swap an immutable `(sections, z1, z2, channels)` state holder atomically) so changing filter order/slope/band-count (`10-band <-> 31-band` Graphic EQ, Slope Filter, Classic Filter) during live playback can never throw `ArrayIndexOutOfBoundsException` on `z1[k]` or `sections[s]`.
- [x] **File**: `app/src/main/java/com/takeone/studio/FilterCurveEqProcessor.java` (lines 130–135)
  - **Root Cause**: `prepare(int sr, int ch)` unconditionally sets `designKey = Long.MIN_VALUE; rebuild();`. Because `DspChain.applySlotExtras()` calls `p.prepare()` on **every** slot whenever **any** slider in the rack moves, `FilterCurveEqProcessor` recomputes two 8,192-point FFTs on the UI thread on every touch event even when nothing on `FilterCurveEqProcessor` changed (and `designKeyNow()` already hashes `sampleRate`, `channels`, and all node parameters!).
  - **Fix**: Remove `designKey = Long.MIN_VALUE;` from `FilterCurveEqProcessor.prepare(int sr, int ch)` so `rebuild()` only runs when `designKeyNow() != designKey`, and synchronize `rebuild()`, `reset()`, and `processInPlace()`.

### B.5 Fix Concurrent Temp-File Race in `FxPreviewPeaks` & `DspChain.renderRegionToFile`
- [x] **Files**:
  - `app/src/main/java/com/takeone/studio/FxPreviewPeaks.java` (line 271)
  - `app/src/main/java/com/takeone/studio/DspChain.java` (lines 1506, 1595)
  - `app/src/main/java/com/takeone/studio/EditEngine.java` (lines 1012–1015)
  - **Root Cause**: `FxPreviewPeaks.renderRegionLive` is spawned on a new background `Thread` on every slider scrub (`StudioFragment.java:3687`), yet all threads share the hardcoded file path `new File(raw.getParentFile(), raw.getName() + ".fxprev_reg_tmp")` (and `.step0` inside `renderRegionToFile`). When Thread 1 finishes and deletes `regionTmp` in its `finally` block, it deletes the file while Thread 2 is reading/writing it!
  - **Fix**: Use `File.createTempFile("fxprev_reg_", ".wav", raw.getParentFile())` (and `File.createTempFile(...)` for `.step`, `.offline_region_tmp`, `.lcrender`, and `.lctail`) so concurrent preview and apply threads never collide on disk.

### B.6 Fix Frozen EQ Curve in `StudioFragment.showEffectDetailModal()` & Null-Reset in `rebuildFxRackList()`
- [x] **File**: `app/src/main/java/com/takeone/studio/StudioFragment.java`
  1. **Lines 4324–4340 (`showEffectDetailModal`)**: Add `refreshers.add(eqView::invalidate);` right after `body.addView(eqView, eqLp);` (matching `refreshers.add(dynView::invalidate);` on line 4354) so scrubbing any EQ parameter slider in the full-screen modal immediately redraws the EQ response curve even when playback is paused.
  2. **Lines 4951–4957 (`rebuildFxRackList` -> `onSlotMutated`)**: When refreshing `extraControls`, if `slot.extraParams.get(entry.getKey())` is `null`, fall back to the parameter's `defaultRaw` (`FxParameter p = meta != null ? meta.getParam(entry.getKey()) : null; int val = v != null ? v : (p != null ? p.defaultRaw : 0); entry.getValue().setValue(val, false);`) and also update `pc.setEnabled(meta.isParamApplicable(...))` and `pc.setAlpha(...)`.

### B.7 Wire `PlotSpectrumDialog` and `AudioDiagnosticsTool` Into the Studio UI
- [x] **File**: `app/src/main/java/com/takeone/studio/StudioFragment.java`
  - **Root Cause**: `PlotSpectrumDialog.java` and `AudioDiagnosticsTool.java` exist in `src/main/java/com/takeone/studio/` and are unit-tested in `Stage7TimeToolsTest`, but have zero UI entry points in `StudioFragment`!
  - **Fix**: Add `"Plot Spectrum"` and `"Audio Diagnostics"` actions (e.g., in the Studio options sheet / FX header tools or analyzer section) that read up to `65,536` frames from the current selection (or active take around the cursor) via `EditEngine.readFloatSelection`, run `PlotSpectrumDialog.analyze(...)` / `AudioDiagnosticsTool.analyze(...)`, and display the formatted summary in a clean modal dialog.