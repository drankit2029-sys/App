# TakeOne Studio — Complete 52-FX Audit, Bug-Fix & Automated Verification `task.md`

> **Implementation note (branch `ut/fx-gpu-undo`):** this codebase uses package
> `com.takeone.studio` (no `.fx` subpackage), `FxRackChain`/`DspChain.EffectType`,
> `getParameters()` and `slot.extraParams`. Checklist marks refer to the actual APIs;
> `FadeEnvelopeProcessor` does not exist here (the branch has `FadeProcessor` with a
> different type model) and `StftProcessor` has no streaming FIFO state to persist.

> **Instructions for the AI Agent**:
> Work through the phases below sequentially. Mark each item `- [/]` when starting and `- [x]` only after compiling and verifying via the automated JUnit suite in Phase 5. Do **not** re-introduce `== defaultRaw` or `!= defaultRaw` workarounds to make legacy single-parameter OAT tests pass; instead, fix the underlying DSP/UI logic and update the test harness so parameters are tested at active operating points.

## Phase 1: Mode-Applicability Contract & Universal UI Disabling

### 1.1 Add `isParamApplicable(String paramId)` to `AudioProcessor`
- [x] **File**: `app/src/main/java/com/takeone/studio/fx/AudioProcessor.java`
  - Add a default method to the `AudioProcessor` interface:
    ```java
    default boolean isParamApplicable(String paramId) {
        return true;
    }
    ```

### 1.2 Implement `isParamApplicable(String paramId)` in All Multi-Mode Processors
- [x] **File**: `app/src/main/java/com/takeone/studio/fx/AudioGeneratorTool.java` (`generator`)
  - Read `int t = type.getEnumIndex();` (`0 = Tone & Chirp`, `1 = Noise`, `2 = Pluck`, `3 = Rhythm Track`, `4 = DTMF`, `5 = Silence`).
  - Return applicability per parameter ID:
    - `"gen_type"`, `"gen_dur"`, `"gen_amp"` -> `t != 5` for `"gen_amp"`, always `true` for `"gen_type"` and `"gen_dur"`.
    - `"gen_wave"`, `"gen_f0"`, `"gen_f1"`, `"gen_interp"` -> `t == 0`
    - `"gen_noise"` -> `t == 1`
    - `"gen_midi"`, `"gen_pluck"` -> `t == 2`
    - `"gen_bpm"`, `"gen_bpb"`, `"gen_bars"`, `"gen_click"` -> `t == 3`
    - `"gen_dtmf"`, `"gen_duty"` -> `t == 4`
- [x] **File**: `app/src/main/java/com/takeone/studio/fx/TimelineUtilityProcessor.java` (`timeline`)
  - `"tl_repeats"` -> `action.getEnumIndex() == 2` (only active in `Repeat` mode; disabled in `Invert (0)` and `Reverse (1)`).
- [x] **File**: `app/src/main/java/com/takeone/studio/fx/TruncateSilenceProcessor.java` (`truncsil`)
  - `"ts_trunc"` -> `action.getEnumIndex() == 0` (`Truncate Detected Silence`)
  - `"ts_compress"` -> `action.getEnumIndex() == 1` (`Compress Excess Silence`)
- [x] **File**: `app/src/main/java/com/takeone/studio/fx/ClassicFiltersProcessor.java` (`classic`)
  - `"ripple"` -> `type.getEnumIndex() == 1 || type.getEnumIndex() == 2` (only `Chebyshev I (1)` and `Chebyshev II (2)` use passband/stopband ripple; `Butterworth (0)` and `Bessel (3)` must disable `"ripple"`).
- [x] **File**: `app/src/main/java/com/takeone/studio/fx/SpectralEditProcessor.java` (`spectraledit`)
  - `"se_gain"` -> `mode.getEnumIndex() != 2` (disabled in `Spectral Delete / Notch (2)`, where attenuation is a deep notch rather than a variable shelf/bell gain).
- [x] **File**: `app/src/main/java/com/takeone/studio/fx/FreeverbReverbProcessor.java` (`reverb`)
  - `"dry_gain"` -> `!wetOnly.getBoolean()` (disabled when `Wet Only` toggle is `On`).
- [x] **File**: `app/src/main/java/com/takeone/studio/fx/VocoderProcessor.java` (`vocoder`)
  - `"vc_pitch"` -> `carrier.getEnumIndex() != 1` (disabled when `Carrier Type` is `White Noise (1)`, which is unpitched).
- [x] **File**: `app/src/main/java/com/takeone/studio/fx/AmplifyProcessor.java` (`amplify`)
  - `"new_peak"` -> `!allowClip.getBoolean()` (or keep synced with `"gain"` — see Phase 3.3).
- [x] **File**: `app/src/main/java/com/takeone/studio/fx/GraphicEqProcessor.java` (`geq`)
  - For 31-band sliders (`"b11"` .. `"b31"` or any band parameter beyond index 10): return `layout.getEnumIndex() == 1` (`31 bands (1/3 oct)`).
- [ ] **File**: `app/src/main/java/com/takeone/studio/fx/FadeEnvelopeProcessor.java` (`fade`)
  - `"curve"` -> `type.getEnumIndex() == 2` (`Adjustable Fade`), since `Linear In (0)`, `Linear Out (1)`, `Exponential (3)`, `Logarithmic (4)`, and `Cosine S-Curve (5)` use fixed curves.
  - `"dir"` -> `type.getEnumIndex() >= 2` (since `Linear In (0)` and `Linear Out (1)` already hardcode direction).

### 1.3 Wire Universal UI Parameter Disabling in `StudioFragment`
- [x] **File**: `app/src/main/java/com/takeone/studio/StudioFragment.java` (inside `rebuildFxRackList()`, around lines 1630–1790)
  - Before building parameter rows, instantiate a temporary processor instance via `AudioProcessor probe = FxRegistry.create(slot.type);` and apply `slot.values` to `probe.getParams()`.
  - For each `FxParam p` in `probe.getParams()`:
    - Query `boolean applicable = probe.isParamApplicable(p.id);`
    - Set `row.setAlpha(applicable ? 1.0f : 0.38f);`
    - Enable/disable interactive controls on that row (`seekBar.setEnabled(applicable)`, `spinner.setEnabled(applicable)`, `switchView.setEnabled(applicable)`, `valueText.setEnabled(applicable)`).
  - Whenever any `ENUM` or `BOOLEAN` parameter changes in `StudioFragment`, invoke `rebuildFxRackList()` (or a lightweight `refreshFxRowApplicability(slot)` helper) so dependent sliders enable/disable immediately without closing the panel.

## Phase 2: Fix All Default-Value Gates (`== defaultRaw` / `!= defaultRaw`) & Silent Mode Hijacks

### 2.1 `SlopeFilterProcessor.java` (`lowpass` / `highpass`) — Cutoff-Dependent Slope Bug
- [x] **File**: `app/src/main/java/com/takeone/studio/fx/SlopeFilterProcessor.java` (lines 65–74)
  - **Root Cause**: Line 69 checks `if (!highpass && freq.getCurrentRaw() == freq.defaultRaw && idx != slope.defaultRaw)` and shifts `f0` by `Math.pow(0.82, idx)` **only** when `freq` is at its exact default (`12000 Hz`). As soon as `freq` is moved to any non-default value, changing `slope` stops shifting `f0` and barely changes audible level on broadband/low-frequency material.
  - **Fix**: Delete line 69 (`if (!highpass && freq.getCurrentRaw() == freq.defaultRaw ...)`). Pass the true `f0 = Dsp.clamp(freq.getFloat(), 20.0, sampleRate * 0.45)` and `order = idx + 1` directly into `Dsp.butterworth(order, sampleRate, f0, highpass)`.

### 2.2 `AudioGeneratorTool.java` (`generator`) — Silent Mode Hijacking
- [x] **File**: `app/src/main/java/com/takeone/studio/fx/AudioGeneratorTool.java` (lines 125–135)
  - **Root Cause**: `effectiveTypeIndex()` overrides `typeIdx == 0 (Tone & Chirp)` to `4 (DTMF)` if `sequence.getCurrentRaw() != sequence.defaultRaw`, or to `3 (Rhythm Track)` if `tempo.getCurrentRaw() != tempo.defaultRaw`. Switching back to `Tone & Chirp` after editing `Rhythm Track` or `DTMF` keeps generating clicks or DTMF tones.
  - **Fix**: Replace `effectiveTypeIndex()` so it simply returns `type.getEnumIndex()` with no `!= defaultRaw` overrides.

### 2.3 `TimelineUtilityProcessor.java` (`timeline`) — Silent Action Override & Fake 1x Repeat Trim
- [x] **File**: `app/src/main/java/com/takeone/studio/fx/TimelineUtilityProcessor.java` (lines 74–81, 112–118)
  - **Root Cause**:
    1. `effectiveActionIndex()` (lines 74–81) overrides `actIdx == 0 (Invert)` to `2 (Repeat)` whenever `repeats.getCurrentRaw() != repeats.defaultRaw`.
    2. Lines 112–118 apply an artificial `0.944f (-0.5 dB)` gain drop when `count == 1` in `Repeat` mode so a single-parameter test sees a sample delta.
  - **Fix**:
    1. Make `effectiveActionIndex()` return `action.getEnumIndex()` strictly.
    2. In `Repeat` mode (`actIdx == 2`), `count` is the number of additional repeats (`1..8` -> total copies = `count + 1`, or set minimum `repeats` to `1` additional copy so `totalFrames = frames * (1 + count)`), and remove the fake `0.944f` attenuation on `count == 1`.

### 2.4 `TruncateSilenceProcessor.java` (`truncsil`) — Silent Action Override
- [x] **File**: `app/src/main/java/com/takeone/studio/fx/TruncateSilenceProcessor.java` (lines 97–98, 152–154, 197–198)
  - **Root Cause**: `boolean compress = action.getEnumIndex() == 1 || compressTo.getCurrentRaw() != compressTo.defaultRaw;` forces `Compress` mode even when `Action` is `Truncate (0)` if `Compress To` was ever moved from its default. Also lines 97–98 force `threshDb = -26f` when `compressTo != defaultRaw`.
  - **Fix**:
    1. Set `boolean compress = (action.getEnumIndex() == 1);` strictly in both `processInPlace()` and `processResize()`.
    2. Remove lines 97–98 (`if (threshDb < -35f && compressTo.getCurrentRaw() != compressTo.defaultRaw) threshDb = -26f;`).

### 2.5 `GraphicEqProcessor.java` (`geq`) — Sticky 31-Band Mode & Hidden +1.2 dB Boost
- [x] **File**: `app/src/main/java/com/takeone/studio/fx/GraphicEqProcessor.java` (lines 81–86, 100, 112–117)
  - **Root Cause**:
    1. Line 100 (`boolean thirdOctave = layout.getEnumIndex() == 1 || hasUpperBandGain();`) locks the EQ into 31-band mode even when the user switches `Layout` back to `10 bands (ISO)`.
    2. Lines 112–117 inject a hidden `+1.2 dB` peaking filter at `1000 Hz` when `layout == 1` and all bands are at `0 dB`.
  - **Fix**:
    1. Change line 100 to `boolean thirdOctave = (layout.getEnumIndex() == 1);` and delete `hasUpperBandGain()`.
    2. Delete lines 112–117 so a flat 31-band Graphic EQ (`all bands = 0 dB`) has a genuinely flat `0.0 dB` response.

### 2.6 `ParametricEq6BandProcessor.java` (`eq6`) — Hidden +3.0 dB Boost When Band Gain Is 0 dB
- [x] **File**: `app/src/main/java/com/takeone/studio/fx/ParametricEq6BandProcessor.java` (lines 101–125, 149–196)
  - **Root Cause**: `isBand2SecondaryTouched()` .. `isBand5SecondaryTouched()` check if `Freq`, `Q`, or `Type` is non-default while `Gain == 0.0 dB`, and secretly inject `g = 3.0 dB`! A parametric EQ band with `0.0 dB` gain must be unity/flat regardless of its `Freq` or `Q`.
  - **Fix**: Delete `isBand2SecondaryTouched()` .. `isBand5SecondaryTouched()` and their `if (Math.abs(g) <= 0.01 && ...) g = 3.0;` blocks in `rebuild()`.

### 2.7 `ShelfFilterProcessor.java` (`shelf`) — Hidden +3.0 dB Boost When Shelf Gain Is 0 dB
- [x] **File**: `app/src/main/java/com/takeone/studio/fx/ShelfFilterProcessor.java` (lines 59–75)
  - **Root Cause**: When `Shelf Gain` is `0.0 dB` and `type`, `freq`, or `slope` is non-default, `hasSecondaryChange()` forces `g = 3.0 dB`.
  - **Fix**: Delete `hasSecondaryChange()` and lines 69–71 (`if (Math.abs(g) < 0.05 && hasSecondaryChange()) g = 3.0;`). Either set the default `Shelf Gain` to a non-zero value (e.g. `+3.0 dB`) if you want the effect audible on insert, or keep `0.0 dB` strictly flat and test `type`/`freq`/`slope` with `gain != 0 dB` in the test suite.

### 2.8 `SpectralEditProcessor.java` (`spectraledit`) — Hidden -6 dB Cut at 0 dB Gain & Mode 2 Gain Leak
- [x] **File**: `app/src/main/java/com/takeone/studio/fx/SpectralEditProcessor.java` (lines 58–62, 79–81, 103–106)
  - **Root Cause**:
    1. Lines 79–81 inject `rawG = -6.0f` when `gain == 0.0 dB` and `fLow` or `fHigh` is touched.
    2. Line 106 (`targetDb = -24.0f + g * 0.45f;`) makes `Spectral Delete / Notch (mode 2)` depend on `gain` even though `Delete` mode should attenuate the selected spectral region independently of shelf/bell gain.
  - **Fix**:
    1. Delete `hasBandEdgeChange()` and lines 79–81.
    2. In `mode == 2 (Spectral Delete / Notch)`, use a fixed deep attenuation (`targetDb = -48.0f`) and disable `se_gain` via `isParamApplicable("se_gain")`.

### 2.9 `ClassicFiltersProcessor.java` (`classic`) — Fake Ripple Biquad on Butterworth & Bessel
- [x] **File**: `app/src/main/java/com/takeone/studio/fx/ClassicFiltersProcessor.java` (lines 90–100)
  - **Root Cause**: Lines 90–100 append a peaking biquad at `f0` when `proto == 0 (Butterworth)` or `proto == 3 (Bessel)` and `ripple != ripple.defaultRaw`. Butterworth is maximally flat and Bessel is maximally linear-phase; neither has passband ripple.
  - **Fix**: Delete lines 90–100 and rely on `isParamApplicable("ripple")` (Phase 1.2) to disable `ripple` in modes `0` and `3`.

### 2.10 `FreeverbReverbProcessor.java` (`reverb`) — Dry Signal Bleed When `Wet Only` Is On
- [x] **File**: `app/src/main/java/com/takeone/studio/fx/FreeverbReverbProcessor.java` (lines 143–146)
  - **Root Cause**: `float dry = wetOnly.getBoolean() ? (dryGain.getCurrentRaw() != dryGain.defaultRaw ? Dsp.dbToLin(dryGain.getFloat()) * 0.08f : 0f) : Dsp.dbToLin(dryGain.getFloat());` leaks 8% dry signal when `Wet Only` is `On` if `Dry Gain` is non-default.
  - **Fix**: Replace with `float dry = wetOnly.getBoolean() ? 0f : Dsp.dbToLin(dryGain.getFloat());`.

### 2.11 Remove Fake `0%` Primary-Amount Overrides Across 8 Processors
- [x] **Files & Lines**:
  1. `app/src/main/java/com/takeone/studio/fx/ChorusFlangerProcessor.java` (lines 71–80, 104): Delete `hasSecondaryChange()` and `if (mix <= 0.001f && hasSecondaryChange()) mix = 0.25f;`.
  2. `app/src/main/java/com/takeone/studio/fx/PhaserProcessor.java` (lines 71–80, 90, 94): Delete `hasSecondaryChange()` and the `depth = 0.35f` / `w = 0.35f` overrides when `depth` or `wet` is `0%`.
  3. `app/src/main/java/com/takeone/studio/fx/DistortionWaveshaperProcessor.java` (lines 79–88, 140–141): Delete `hasSecondaryChange()` and `if (drv <= 0.001f && hasSecondaryChange()) drv = 0.25f;`.
  4. `app/src/main/java/com/takeone/studio/fx/MultibandCompressorProcessor.java` (lines 74–83, 101): Delete `hasSecondaryChange()` and `if (amt <= 0.001f && hasSecondaryChange()) amt = 0.35f;`.
  5. `app/src/main/java/com/takeone/studio/fx/ProCompressorProcessor.java` (lines 58–65, 81–82): Delete `hasSecondaryChange()` and `if (amt <= 0.001f && hasSecondaryChange()) amt = 0.35f;`.
  6. `app/src/main/java/com/takeone/studio/fx/ProDeEsserProcessor.java` (lines 60–66, 106–107): Delete `hasSecondaryChange()` and `if (amt <= 0.001f && hasSecondaryChange()) amt = 0.35f;`.
  7. `app/src/main/java/com/takeone/studio/fx/ProToneProcessor.java` (lines 63–69, 115, 124): Delete `hasSecondaryChange()` and the `w = 0.2f` / `p = 0.2f` overrides when `Warmth` and `Presence` are both `0%`.
  8. `app/src/main/java/com/takeone/studio/fx/TremoloProcessor.java` (lines 58–64, 92–93): Delete `hasSecondaryChange()` and `if (d <= 0.001f && hasSecondaryChange()) d = 0.25f;`.

## Phase 3: Two-Way UI Parameter Coupling for Redundant Unit Controls

### 3.1 `ChangeTempoProcessor.java` (`tempo`) — Couple `percent` with `bpm_from` / `bpm_to`
  - **Status:** DSP coupling and rack UI two-way sync implemented; verified by the full unit/lint CI.
- [x] **File**: `app/src/main/java/com/takeone/studio/fx/ChangeTempoProcessor.java` (lines 71–84) & `StudioFragment.java`
  - **Root Cause**: `stretchFactor()` checks `if (Math.abs(pct) < 0.01 && from > 1f && to > 1f && Math.abs(to - from) > 0.01)`. If `Percent Change` is non-zero (e.g., `+10%`), adjusting `BPM From` or `BPM To` does nothing at all!
  - **Fix**:
    1. In `StudioFragment.java` (parameter change listener): When the user edits `bpm_from` or `bpm_to` on `CHANGE_TEMPO`, compute `double pct = ((bpmTo - bpmFrom) / bpmFrom) * 100.0;` and update the `percent` parameter in `slot.values` and its slider UI. Conversely, when the user edits `percent`, update `bpm_to = bpmFrom * (1.0 + pct / 100.0)`.
    2. In `ChangeTempoProcessor.stretchFactor()`: If both `pct` and `bpm_from`/`bpm_to` are modified programmatically in headless tests without UI sync, compute `double rPct = 1.0 + (pct / 100.0); double rBpm = (from > 1f && to > 1f) ? (to / from) : 1.0;` and if `Math.abs(rPct - rBpm) < 1e-3` (synced by UI) use `rPct`, otherwise use `rPct * rBpm` so neither control is ever dead.

### 3.2 `ChangeSpeedAndPitchProcessor.java` (`speedpitch`) — Sync `speed` and `percent`
  - **Status:** DSP coupling and rack UI two-way sync implemented; verified by the full unit/lint CI.
- [x] **File**: `app/src/main/java/com/takeone/studio/fx/ChangeSpeedAndPitchProcessor.java` (lines 66–72) & `StudioFragment.java`
  - **Fix**: In `StudioFragment.java`, when the user moves `speed` (`0.25x..4.00x`), update `percent` (`(speed - 1.0f) * 100f`) in `slot.values` and its slider row; when the user moves `percent`, update `speed = 1.0f + percent / 100f`. In `ChangeSpeedAndPitchProcessor.effectiveRatio()`, check if `Math.abs(s - (1.0 + pct / 100.0)) < 1e-2` (synced) and return `s`, otherwise return `Dsp.clamp(s * (1.0 + pct / 100.0), 0.25, 4.0)`.

### 3.3 `AmplifyProcessor.java` (`amplify`) — Sync `gain` and `new_peak`
  - **Status:** processor ceiling/applicability implemented; rack UI sync pending.
- [ ] **File**: `app/src/main/java/com/takeone/studio/fx/AmplifyProcessor.java` (lines 77–93) & `StudioFragment.java`
  - **Root Cause**: `AmplifyProcessor` ignores `new_peak` whenever `Math.abs(gDb) >= 0.01f` (unless clipping occurs and `allow_clip == false`).
  - **Fix**:
    1. In `StudioFragment.java`, when `new_peak` is scrubbed by the user, update `gain` (`gDb = newPeakDb - currentTrackPeakDb`), and when `gain` is scrubbed, update `new_peak = currentTrackPeakDb + gDb`.
    2. In `AmplifyProcessor.processInPlace()`, when `!allowClip.getBoolean()`, treat `new_peak` as the ceiling (`maxAllowedDb = targetPeakDb - currentPeakDb`) and clamp `effectiveDb = Math.min(gDb, maxAllowedDb)` when `new_peak` has been lowered below `gDb`, or if `Math.abs(gDb) < 0.01f`, target `targetPeakDb - currentPeakDb`.

### 3.4 `NotchFilterProcessor.java` (`notch`) — Sync `preset` (`Quick Pick`) and `freq`
  - **Status:** processor rule and rack UI preset/frequency sync implemented; tests updated.
- [x] **File**: `app/src/main/java/com/takeone/studio/fx/NotchFilterProcessor.java` (lines 69–78) & `StudioFragment.java`
  - **Root Cause**: When `preset` is `1 (50 Hz hum)` or `2 (60 Hz hum)`, `NotchFilterProcessor.buildSections()` hardcodes `f0 = 50.0` or `60.0` and completely ignores the `Center Frequency` (`freq`) slider unless `freq != freq.defaultRaw`! Even worse, if the user selects `60 Hz hum` while `freq` happens to be at its default `60 Hz`, and then scrubs `freq` back to `60 Hz` or `1000 Hz`, the logic conflicts.
  - **Fix**:
    1. In `StudioFragment.java`, selecting `preset == 1` sets `freq = 50 Hz`; selecting `preset == 2` sets `freq = 60 Hz`; scrubbing `freq` manually sets `preset = 0 (Custom)`.
    2. In `NotchFilterProcessor.buildSections()`, if `p == 1 && freq.getCurrentRaw() == freq.defaultRaw` use `50.0`, else if `p == 2 && freq.getCurrentRaw() == freq.defaultRaw` use `60.0`, otherwise use `freq.getFloat()`.

## Phase 4: Fix Newly Discovered DSP, Chunk-Boundary State, Look-Ahead & Compression Bugs

### 4.1 `VocoderProcessor.java` (`vocoder`) — Fix Chunk-Boundary State Reset, Memory Churn & White Noise Leak
- [x] **File**: `app/src/main/java/com/takeone/studio/fx/VocoderProcessor.java` (lines 83–135)
  - **Root Cause**:
    1. `BiquadFilter modBp = new BiquadFilter(); BiquadFilter carBp = new BiquadFilter();` and `float env = 0f;` are instantiated as local variables inside the `for (int b = 0; b < nBands; b++)` loop in `processInPlace()`. Because audio is processed in 4096-frame chunks, all 32 bandpass filter states and all 32 envelope followers reset to zero every 85 ms, causing severe periodic clicks at chunk boundaries and allocating 64 `BiquadFilter` instances + 64 `float[4096]` arrays per chunk!
    2. Line 98: In `White Noise (cType == 1)` mode, `carrierSig[f] = ((rng.nextFloat() * 2f) - 1f) * 0.6f + 0.18f * saw;` mixes a pitched sawtooth wave into the white noise carrier!
  - **Fix**:
    1. Store persistent fields on `VocoderProcessor`:
       ```java
       private static final int MAX_BANDS = 32;
       private final BiquadFilter[] modBp = new BiquadFilter[MAX_BANDS];
       private final BiquadFilter[] carBp = new BiquadFilter[MAX_BANDS];
       private final float[] bandEnv = new float[MAX_BANDS];
       ```
       Initialize the `BiquadFilter` instances in the constructor, reset their states (`modBp[b].reset()`, `carBp[b].reset()`, `Arrays.fill(bandEnv, 0f)`) inside `reset()`, and update their coefficients when parameters change without zeroing filter state between consecutive chunks.
    2. Remove `+ 0.18f * saw` from `cType == 1 (White Noise)` on line 98 so `White Noise` is pure unpitched noise (`((rng.nextFloat() * 2f) - 1f) * 0.6f`).

### 4.2 `SpectralEditProcessor.java` & `SpectralNoiseReductionProcessor.java` — Persist `StftProcessor` Across Chunks
  - **Status:** not implemented. This branch's `StftProcessor` processes each call statelessly and has no `inFifo`/`outFifo`/`outAccum` fields; a streaming FIFO rewrite is required.
- [ ] **Files**:
  - `app/src/main/java/com/takeone/studio/fx/SpectralEditProcessor.java` (line 84)
  - `app/src/main/java/com/takeone/studio/fx/SpectralNoiseReductionProcessor.java` (line 98)
  - **Root Cause**: Both classes create `new StftProcessor(FFT_SIZE, HOP_SIZE, ...)` as a local variable inside `processInPlace()`. When `EditEngine` or `FxPreviewPeaks` streams 4096-frame chunks, the STFT overlap-add FIFOs (`inFifo`, `outFifo`, `outAccum`) are wiped out every 4096 frames, causing a 1024-sample fade-in dropout at the start of every single chunk!
  - **Fix**:
    1. Move `StftProcessor stft` to an instance field on both `SpectralEditProcessor` and `SpectralNoiseReductionProcessor`.
    2. Call `stft.reset()` only inside `prepare()` / `reset()`.
    3. Update current active parameters stored as fields on `this` before calling `stft.processInPlace(buf, frames, ch)` so the same `StftProcessor` instance maintains continuous overlap-add state across all chunks.
    4. Override `getLatencyFrames()` to return `FFT_SIZE` (`1024`) on both processors so `EditEngine`'s tail-flushing logic compensates for the STFT latency and flushes the final overlap-add tail.

### 4.3 `BrickwallLimiterProcessor.java` (`bricklim`) — Wire Up the Unused 3 ms Look-Ahead Delay Line
- [x] **File**: `app/src/main/java/com/takeone/studio/fx/BrickwallLimiterProcessor.java` (lines 54–66, 89–116)
  - **Root Cause**: `prepare()` and `reset()` allocate `private float[][] delay = new float[2][lookaheadSamples];` and `private int writeIdx = 0;`, and `getLatencyFrames()` returns `lookaheadSamples` (~144 frames = 3 ms). However, `processInPlace()` (lines 89–116) **never reads or writes `delay` or `writeIdx`**! It applies `gain` directly to the undelayed sample and hard-clips the transient overshoot with `Dsp.clamp(v, -ceilLin, ceilLin)`.
  - **Fix**:
    1. In `processInPlace()`, for each frame `f`, compute the peak across channels on the incoming (look-ahead) sample `inPeak`.
    2. Update the gain-reduction envelope (`gain`) toward `targetGain = (inPeak > threshLin) ? (threshLin / inPeak) : 1.0f` using the attack time constant aligned to `lookaheadSamples` (and prevent `gain` from exceeding `ceilLin / delayedPeak`).
    3. Read the delayed audio sample `float delayed = delay[c][writeIdx];`, write the current input sample `delay[c][writeIdx] = buf[base + c] * inGain;`, advance `writeIdx = (writeIdx + 1) % lookaheadSamples;`, and output `delayed * gain` (clamped to `[-ceilLin, ceilLin]` as a final safety).

### 4.4 `EchoProcessor.java` & `MultiDelayProcessor.java` — Remove Fake Short-Buffer Early Reflection
- [x] **Files**:
  - `app/src/main/java/com/takeone/studio/fx/EchoProcessor.java` (lines 85–90)
  - `app/src/main/java/com/takeone/studio/fx/MultiDelayProcessor.java` (lines 118–125)
  - **Root Cause**: Both processors contain:
    ```java
    if (echo == 0f && f < delaySamples && frames < delaySamples) {
        int earlyDelay = Math.max(64, Math.min(frames / 2, delaySamples % Math.max(128, frames / 2)));
        ...
    }
    ```
    Because chunked streaming passes `frames = 4096` (~85 ms at 48 kHz), any delay time longer than 85 ms satisfies `frames < delaySamples` on the first chunk and injects a fake early reflection at `earlyDelay` (~40 ms) that doesn't belong to the delay line!
  - **Fix**: Delete the `if (echo == 0f && f < delaySamples && frames < delaySamples)` block from both `EchoProcessor.java` and `MultiDelayProcessor.java`. In unit tests, test `EchoProcessor` and `MultiDelayProcessor` with a buffer length (or multi-chunk stream) longer than the maximum delay time (e.g. `2.5 seconds` = `120,000 frames` at 48 kHz, or stream multiple 4096-frame chunks).

### 4.5 `CompressorProcessor.java` (`dyncomp`) — Fix Upward Compression Sign & Noise Floor Bleed
- [x] **File**: `app/src/main/java/com/takeone/studio/fx/CompressorProcessor.java` (lines 111–120, 137–140)
  - **Root Cause**:
    1. In `Upward Compression` (`up == true`, lines 112–115), when `lvlDb < threshDb` and `lvlDb > floorDb`, `float under = threshDb - lvlDb; targetGrDb = -slope * under * 0.5f;` computes a **negative** gain (`targetGrDb < 0`), which **attenuates** quiet signals instead of boosting them upward toward the threshold!
    2. Lines 137–140: When `lvlDb <= floorDb` (signal is below the noise gate/floor), it sets `float bleedTarget = -floorScale * 3.0f;`, which attenuates the signal based on the `Noise Floor` slider setting instead of holding/freezing the compressor gain!
  - **Fix**:
    1. In `up == true` mode, when `lvlDb < threshDb && lvlDb > floorDb`, compute a **positive** upward boost: `targetGrDb = Math.min(20.0f, slope * (threshDb - lvlDb));` (and `0f` when `lvlDb >= threshDb`).
    2. When `lvlDb <= floorDb`, hold `currentGainDb` (or let it smoothly release toward `0f`: `currentGainDb = relCoef * currentGainDb;`) without applying the fake `bleedTarget` attenuation.

### 4.6 `StereoImagingProcessor.java` (`stereoimg`) — Remove Fake Mono Filter/Trim Hacks
- [x] **File**: `app/src/main/java/com/takeone/studio/fx/StereoImagingProcessor.java` (lines 72–83, 108–114)
  - **Root Cause**:
    1. On mono buffers (`ch == 1`, lines 72–83), `StereoImagingProcessor` applies arbitrary gain trims (`modeScale = 0.96f`, `panTrim = 1.0f + 0.18f * p`) and a 1-pole high-pass difference filter (`diff = x - prevMono`) just so a mono test harness detects a change.
    2. On dual-mono buffers (`L == R`, lines 108–114), when `side == 0`, it synthesizes a fake high-passed side signal `side = (xL - prevMono) * 0.25f * (w - 1.0f)`.
  - **Fix**:
    1. Remove the mono `prevMono` filter hack and arbitrary mono `modeScale`/`panTrim` volume changes (in mono `ch == 1`, only polarity invert modes `3` and `4` invert the mono signal `-x`; stereo width and pan require 2 channels).
    2. Remove the fake `Math.abs(side) < 1e-6f` high-pass injection in stereo mode (lines 108–114).
    3. Ensure the automated test harness tests `StereoImagingProcessor` (and all other stereo effects) on a true stereo buffer where `L != R` (`ch = 2` with decorrelated/phase-offset L/R channels).

## Phase 5: Build & Run the Automated Interaction, Mode-Gating & Chunk-Continuity Test Suite

### 5.1 Create `FxInteractionAndModeTest.java`
  - **Status:** a targeted `FxInteractionAndModeTest` was added and is green; the four all-52 generic methods are still pending.
- [ ] **File**: `app/src/test/java/com/takeone/studio/fx/FxInteractionAndModeTest.java`
  - Implement a rich JUnit 4 test class with a multi-featured deterministic **2-channel stereo test probe** (`48,000 Hz`, `2.2 seconds` = `105,600 frames` so delays up to 2.0s and tempo/silence truncation have full signal coverage, with pitched harmonic + chirp + transient clicks + quiet `-35 dBFS` phrase + silent gap + decorrelated L/R stereo difference).
  - Include the following 4 automated test methods across all 52 `FxType` entries in `FxRegistry`:
    1. `testAll52Effects_nonDefaultContextSensitivity()`:
       - For every `FxType`, construct a **non-default active context** where **every** non-ENUM, non-BOOLEAN parameter is simultaneously offset away from `defaultRaw` (e.g. `+20%` of its range, and primary amount/mix/depth/gain parameters set to an active non-zero operating point like `50%` or `+6 dB`).
       - For each active mode and each parameter `P` where `proc.isParamApplicable(P.id)` is `true`, sweep `P` across 3 values (`20%`, `55%`, `85%` of range) while all other parameters remain at their **non-default** values, and assert that `maxSampleDiff` / `rmsDiff` / `framesDiff` between at least two points exceeds `1e-4f`.
       - This directly catches every `== defaultRaw` gate and parameter-override bug.
    2. `testAll52Effects_pairwiseAnchorInvariance()`:
       - For every parameter `P` and every secondary parameter `Q` in the same effect (within an active mode where `P` is applicable), verify that sweeping `P` produces a measurable output change **both** when `Q == Q.defaultRaw` **and** when `Q` is moved to `25%` and `75%` of its range.
    3. `testAll52Effects_modeInapplicableParamsAreInertAndFlagged()`:
       - For every `ENUM` or `BOOLEAN` mode selector `M`, iterate through each mode value `m`.
       - For every parameter `P` where `proc.isParamApplicable(P.id)` is `false` in mode `m`, assert that sweeping `P` from `min` to `max` produces **exact bit-for-bit identical audio** (`maxSampleDiff == 0.0f` and `framesDiff == 0`).
    4. `testAll52Effects_chunkedStreamingContinuity()`:
       - For every real-time `AudioProcessor` (`!proc.requiresFullBuffer()`), process the stereo test signal in a single contiguous call (`processInPlace(fullBuf, totalFrames, 2)`) vs. streaming in `4096`-frame chunks (`for (int off = 0; off < totalFrames; off += 4096) ...`) on a freshly reset processor.
       - Assert that the chunked output matches the contiguous output (`maxSampleDiff < 1e-4f`) with no chunk-boundary clicks or STFT/vocoder state resets!

### 5.2 Update `FxParamMatrixDumpTest.java` & Regenerate `expectations.json`
  - **Status:** applicability skipping was added to the matrix; active-primary operating-point and mode-switch cases are still pending.
- [ ] **File**: `app/src/test/java/com/takeone/studio/fx/FxParamMatrixDumpTest.java`
  - Update the single-parameter OAT harness so that:
    1. It uses a `2.2s` stereo (`ch = 2`, `L != R`) probe signal so long delays (`Echo`, `MultiDelay`) and stereo processors (`StereoImaging`, `MidSideMatrix`, `AutoPan`) are tested honestly without needing fake mono/short-buffer hacks.
    2. When testing secondary parameters of effects whose primary amount/gain defaults to `0` (`ParametricEq6BandProcessor`, `ShelfFilterProcessor`, `SpectralEditProcessor`, `ChorusFlangerProcessor`, `PhaserProcessor`, `DistortionWaveshaperProcessor`, `MultibandCompressorProcessor`, `ProCompressorProcessor`, `ProDeEsserProcessor`, `ProToneProcessor`, `TremoloProcessor`), it sets the primary amount/gain to an active operating point (e.g. `+6 dB` for EQ/shelf/spectral band gain, `50%` for mix/depth/drive/amount) rather than requiring fake `+3 dB` / `25%` injections inside production DSP code when the user sets gain/amount to `0`.
    3. When testing mode-specific parameters (`AudioGeneratorTool`, `TimelineUtilityProcessor`, `TruncateSilenceProcessor`, `ClassicFiltersProcessor`, `GraphicEqProcessor`), it switches the mode parameter to the mode where `proc.isParamApplicable(param.id)` is `true` before sweeping that parameter.

### 5.3 Run Full Verification Loop
  - **Note:** full unit suite is green via CI (latest run 41710757356, including the rack sync change). The all-52 interaction sweep below remains pending.
- [x] Run `./gradlew testDebugUnitTest --tests com.takeone.studio.fx.FxInteractionAndModeTest` and `./gradlew testDebugUnitTest --tests com.takeone.studio.fx.FxParamMatrixDumpTest`.
- [ ] Verify 0 failures across all 52 effects for:
  - Non-default context sensitivity (no `== defaultRaw` bugs),
  - Mode-gating (`isParamApplicable(id) == false` parameters are disabled in UI and 100% inert in DSP),
  - Two-way UI coupling (`ChangeTempo`, `ChangeSpeedAndPitch`, `Amplify`, `NotchFilter`),
  - Chunk-streaming continuity (`Vocoder`, `SpectralEdit`, `SpectralNoiseReduction`, `BrickwallLimiter`, `Echo`, `MultiDelay`).
